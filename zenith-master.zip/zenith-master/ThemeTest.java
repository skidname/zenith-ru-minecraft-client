// Simple test to verify all themes are properly configured
import zenith.zov.base.theme.Theme;
import zenith.zov.base.theme.ThemeManager;

public class ThemeTest {
    public static void main(String[] args) {
        System.out.println("🎨 Testing Zenith DLC Themes...");
        
        // Test all theme constants
        Theme[] themes = {
            Theme.DARK,
            Theme.LIGHT,
            Theme.NEON,
            Theme.OCEAN,
            Theme.SUNSET,
            Theme.FOREST,
            Theme.PURPLE,
            Theme.CYBERPUNK,
            Theme.RETRO,
            Theme.CUSTOM_THEME
        };
        
        System.out.println("\n📋 Available Themes:");
        for (int i = 0; i < themes.length; i++) {
            Theme theme = themes[i];
            System.out.printf("%d. %s (%s) - %s\n", 
                i + 1, 
                theme.getName(), 
                theme.getIcon(),
                theme.isGlow() ? "Glow" : "No Glow"
            );
        }
        
        System.out.println("\n✅ All themes loaded successfully!");
        System.out.println("🎮 You should now see all 10 themes in your client menu!");
    }
}
