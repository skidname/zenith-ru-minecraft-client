package by.saskkeee.user;

import net.minecraft.client.MinecraftClient;
import zenith.zov.Zenith;
import zenith.zov.utility.discord.DiscordManager;

public class UserInfo {

    // Configuration - You can change these values
    private static final String DEFAULT_USERNAME = "Player";
    private static final String DEFAULT_UID = "000000000000000000";
    private static final String DEFAULT_ROLE = "User";
    
    // Role-based user IDs - Add your Discord IDs here
    private static final String[] DEVELOPER_IDS = {
        "1391890033555935274", // Replace with actual developer Discord IDs
        "987654321098765432"
    };
    
    private static final String[] PREMIUM_IDS = {
        "111111111111111111", // Replace with actual premium user Discord IDs
        "222222222222222222"
    };
    
    private static final String[] OWNER_IDS = {
        "333333333333333333", // Replace with actual owner Discord IDs
        "444444444444444444"
    };

    public static String getUsername() {
        // Try to get Discord username first
        try {
            if (Zenith.INSTANCE.getDiscordManager() != null && 
                Zenith.INSTANCE.getDiscordManager().isRunning() &&
                Zenith.INSTANCE.getDiscordManager().getInfo() != null) {
                
                DiscordManager.DiscordInfo info = Zenith.INSTANCE.getDiscordManager().getInfo();
                if (info != null && info.userName() != null && 
                    !info.userName().isEmpty() && !info.userName().equals("Unknown")) {
                    return info.userName(); // Use actual Discord username
                }
            }
        } catch (Exception e) {
            // DiscordRPC not working, fall back to Minecraft username
        }
        
        // Fallback to Minecraft username when DiscordRPC isn't working
        return getMinecraftUsername();
    }

    public static String getUID() {
        // Try to get Discord user ID first
        try {
            if (Zenith.INSTANCE.getDiscordManager() != null && 
                Zenith.INSTANCE.getDiscordManager().isRunning() &&
                Zenith.INSTANCE.getDiscordManager().getInfo() != null) {
                
                DiscordManager.DiscordInfo info = Zenith.INSTANCE.getDiscordManager().getInfo();
                if (info != null && info.userId() != null && 
                    !info.userId().isEmpty() && !info.userId().equals("Unknown")) {
                    return info.userId(); // Use actual Discord user ID
                }
            }
        } catch (Exception e) {
            // DiscordRPC not working, fall back to Minecraft username hash
        }
        
        // Fallback to hash of Minecraft username as pseudo-UID
        String minecraftUsername = getMinecraftUsername();
        return String.valueOf(Math.abs(minecraftUsername.hashCode()));
    }

    public static String getRole() {
        // Use username-based role system
        String username = getUsername();
        
        // Check if username matches any special users
        if (isSpecialUser(username)) {
            return "Developer";
        }
        
        return DEFAULT_ROLE;
    }
    
    private static boolean isSpecialUser(String username) {
        // Add special usernames here (Discord or Minecraft usernames)
        String[] specialUsers = {
            "admin",
            "developer",
            "owner"
        };
        
        for (String specialUser : specialUsers) {
            if (specialUser.equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }
    
    private static boolean isDeveloper(String userId) {
        for (String devId : DEVELOPER_IDS) {
            if (devId.equals(userId)) {
                return true;
            }
        }
        return false;
    }
    
    private static boolean isPremium(String userId) {
        for (String premiumId : PREMIUM_IDS) {
            if (premiumId.equals(userId)) {
                return true;
            }
        }
        return false;
    }
    
    private static boolean isOwner(String userId) {
        for (String ownerId : OWNER_IDS) {
            if (ownerId.equals(userId)) {
                return true;
            }
        }
        return false;
    }
    
    public static String getDisplayName() {
        return getUsername();
    }
    
    public static String getAvatarUrl() {
        // Try to get Discord avatar URL first
        try {
            if (Zenith.INSTANCE.getDiscordManager() != null && 
                Zenith.INSTANCE.getDiscordManager().isRunning() &&
                Zenith.INSTANCE.getDiscordManager().getInfo() != null) {
                
                DiscordManager.DiscordInfo info = Zenith.INSTANCE.getDiscordManager().getInfo();
                if (info != null && info.avatarUrl() != null && 
                    !info.avatarUrl().isEmpty() && !info.avatarUrl().equals("Unknown")) {
                    return info.avatarUrl(); // Use actual Discord avatar URL
                }
            }
        } catch (Exception e) {
            // DiscordRPC not working, fall back to null
        }
        
        // Fallback to null when DiscordRPC isn't working
        return null;
    }
    
    public static boolean isDiscordConnected() {
        try {
            return Zenith.INSTANCE.getDiscordManager() != null && 
                   Zenith.INSTANCE.getDiscordManager().isRunning() &&
                   Zenith.INSTANCE.getDiscordManager().getInfo() != null &&
                   Zenith.INSTANCE.getDiscordManager().getInfo().userName() != null &&
                   !Zenith.INSTANCE.getDiscordManager().getInfo().userName().equals("Unknown");
        } catch (Exception e) {
            return false;
        }
    }
    
    public static String getDiscordStatus() {
        if (isDiscordConnected()) {
            return "Connected to Discord";
        } else {
            return "Discord RPC not available";
        }
    }
    
    // Additional utility methods
    
    public static String getMinecraftUsername() {
        if (MinecraftClient.getInstance().player != null) {
            return MinecraftClient.getInstance().player.getName().getString();
        }
        return "Unknown";
    }
    
    public static String getServerInfo() {
        if (MinecraftClient.getInstance().getNetworkHandler() != null && 
            MinecraftClient.getInstance().getNetworkHandler().getServerInfo() != null) {
            return MinecraftClient.getInstance().getNetworkHandler().getServerInfo().address;
        }
        return "Singleplayer";
    }
    
    public static boolean isOnline() {
        return MinecraftClient.getInstance().player != null;
    }
}