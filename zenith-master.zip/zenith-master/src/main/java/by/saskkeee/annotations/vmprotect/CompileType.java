package by.saskkeee.annotations.vmprotect;

public enum CompileType {
    VIRTUALIZATION,
    MUTATION,
    ULTRA
}
