package zenith.zov.client.screens.menu.settings.impl.popup;

import lombok.Getter;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.Vector2f;
import net.minecraft.entity.EntityType;
import net.minecraft.util.Identifier;
import zenith.zov.Zenith;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.modules.api.setting.impl.EntitySelectSetting;
import zenith.zov.client.screens.menu.settings.api.MenuPopupSetting;
import zenith.zov.utility.game.other.MouseButton;
import zenith.zov.utility.interfaces.IMinecraft;
import zenith.zov.utility.math.MathUtil;
import zenith.zov.utility.render.display.ScrollHandler;
import zenith.zov.utility.render.display.TextBox;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.ChangeRect;
import zenith.zov.utility.render.display.base.Rect;
import zenith.zov.utility.render.display.base.UIContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;

import java.util.*;
import java.util.stream.Stream;

public class MenuEntityPopupSetting extends MenuPopupSetting implements IMinecraft {
    @Getter
    private final EntitySelectSetting setting;
    private final TextBox searchBox;
    private final ScrollHandler scrollHandler = new ScrollHandler();
    private boolean rebornSort = false;
    private final Map<EntityType<?>, Rect> entityBounds = new HashMap<>();

    public MenuEntityPopupSetting(EntitySelectSetting setting, ChangeRect bounds) {
        super(bounds);
        searchBox = new TextBox(new Vector2f(0, 0), Fonts.MEDIUM.getFont(7), "Search...", 78);
        animationScale.update(1);
        this.setting = setting;
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float alphas, Theme theme) {
        animationScale.update();
        alphas = 1;
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight() - 20 - 4;

        ctx.pushMatrix();
        ctx.getMatrices().translate(bounds.getX(), bounds.getY() + bounds.getHeight() / 2, 0);
        ctx.getMatrices().scale(animationScale.getValue(), animationScale.getValue(), 1);
        ctx.getMatrices().translate(-bounds.getX(), -(bounds.getY() + bounds.getHeight() / 2), 0);

        ctx.drawRoundedRect(bounds.getX(), bounds.getY(), bounds.getWidth(), height, BorderRadius.all(4), theme.getForegroundColor().mulAlpha(alphas));
        ctx.drawRoundedRect(bounds.getX(), bounds.getY(), bounds.getWidth(), 18, BorderRadius.top(4, 4), theme.getForegroundLight().mulAlpha(alphas));
        Font entityFont = Fonts.MEDIUM.getFont(7);
        Font iconFont = Fonts.ICONS.getFont(7);

        ctx.drawText(entityFont, setting.getName(), x + 8 + 11.2f + 3, y + 7.55f, theme.getWhite());
        ctx.drawText(Fonts.ICONS.getFont(8), "E", x + 8, y + 6, theme.getWhiteGray());
        float sortSize = 14;
        ctx.drawRoundedRect(x + width - sortSize - 8, y + 3, sortSize, sortSize, BorderRadius.all(2), theme.getForegroundGray().mulAlpha(alphas));
        ctx.drawText(iconFont, "W", x + width - 8 - sortSize + (sortSize - iconFont.width("W")) / 2 + 1, y + 6.6f, theme.getColor());

        List<EntityType<?>> sortedList = searchBox.isEmpty() && rebornSort ? getAllEntities().toList() : getAllEntities()
                .sorted((o1, o2) -> {
                    if (searchBox.isEmpty()) {
                        boolean containsInSetting1 = this.setting.contains(o1);
                        boolean containsInSetting2 = this.setting.contains(o2);
                        return Boolean.compare(!containsInSetting1, !containsInSetting2);
                    }
                    String query = searchBox.getText().toLowerCase().trim();
                    String name1 = o1.getTranslationKey()
                            .replaceFirst("^entity\\.minecraft\\.", "")
                            .replaceAll("_", " ");
                    String name2 = o2.getTranslationKey()
                            .replaceFirst("^entity\\.minecraft\\.", "")
                            .replaceAll("_", " ");
                    boolean matchesSearch1 = name1
                            .toLowerCase()
                            .contains(query);
                    boolean matchesSearch2 = name2
                            .toLowerCase()
                            .contains(query);

                    return Boolean.compare(!matchesSearch1, !matchesSearch2);
                })
                .toList();

        float contentHeight = sortedList.size() * 20f;
        scrollHandler.setMax(Math.max(0, contentHeight - height));
        scrollHandler.update();

        int padding = 4;
        float itemY = padding + 18 + y - (float) scrollHandler.getValue();
        float itemX = x;
        float itemWidth = width;

        ColorRGBA textColor = theme.getWhite().mulAlpha(alphas);
        ColorRGBA bgColor = theme.getColor().mulAlpha(alphas);
        entityBounds.clear();
        ColorRGBA graySlotColor = theme.getForegroundColor();
        ColorRGBA themeSlotColor = theme.getForegroundLight();
        ctx.enableScissor((int) x, (int) y + 18 + padding, (int) (x + width), (int) (y + height - padding));
        int i = 0;
        for (EntityType<?> entity : sortedList) {
            i++;
            if (itemY < y) {
                itemY += 20;
                continue;
            }
            boolean selected = setting.contains(entity);
            Rect rect = new Rect(itemX, itemY, itemWidth, 20);
            ctx.drawRoundedRect(rect.x(), rect.y(), rect.width(), rect.height(), BorderRadius.ZERO, selected ? bgColor : i % 2 == 0 ? graySlotColor : themeSlotColor);

            entityBounds.put(entity, rect);
            String name = entity.getTranslationKey()
                    .replaceFirst("^entity\\.minecraft\\.", "")
                    .replaceAll("_", " ");
            name = name.substring(0, 1).toUpperCase() + name.substring(1);

            // Draw entity icon
            ctx.pushMatrix();
            ctx.getMatrices().translate(itemX + 8, itemY + (20 - 11.2f) / 2f, 0);
            ctx.getMatrices().scale(0.7f, 0.7f, 1);
            
            // Try to render entity head/face first, then fallback to icon
            try {
                if (entity == EntityType.PLAYER) {
                    // For players, we can render a player head
                    ctx.drawItem(net.minecraft.item.Items.PLAYER_HEAD.getDefaultStack(), 0, 0);
                } else {
                    // For other entities, use their spawn egg if available
                    net.minecraft.item.Item spawnEgg = getEntitySpawnEgg(entity);
                    if (spawnEgg != null) {
                        ctx.drawItem(spawnEgg.getDefaultStack(), 0, 0);
                    } else {
                        // Fallback to text icon
                        String icon = getEntityIcon(entity);
                        ctx.drawText(Fonts.ICONS.getFont(8), icon, 0, 0, theme.getWhiteGray());
                    }
                }
            } catch (Exception e) {
                // Final fallback to text icon
                String icon = getEntityIcon(entity);
                ctx.drawText(Fonts.ICONS.getFont(8), icon, 0, 0, theme.getWhiteGray());
            }
            ctx.popMatrix();
            ctx.drawText(Fonts.BOLD.getFont(8), ".", itemX + 8 + 11.2f + 3, itemY + 5, theme.getWhiteGray());

            ctx.drawText(entityFont, name, itemX + 8 + 11.2f + 8, itemY + 7.55f, selected ? textColor : theme.getGrayLight());

            itemY += 20;

            if (itemY > y + height) {
                break;
            }
        }

        ctx.disableScissor();
        ctx.enableScissor((int) x, (int) (y + height + 4), (int) (x + width), (int) (y + height + 24));
        ctx.drawRoundedRect(x, y + height + 4, width, 20, BorderRadius.all(4), theme.getForegroundColor().mulAlpha(alphas));

        searchBox.setWidth(width - 20);
        searchBox.render(ctx, x + 8, y + height + 4 + 8, theme.getWhite().mulAlpha(alphas), theme.getGray().mulAlpha(alphas));
        searchBox.setMaxLength(35);
        ctx.disableScissor();
        ctx.popMatrix();
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        searchBox.onMouseClicked(mouseX, mouseY, button);
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();
        if (mouseY > y + 18) {
            for (Map.Entry<EntityType<?>, Rect> entry : entityBounds.entrySet()) {
                if (entry.getValue().contains(mouseX, mouseY)) {
                    if (setting.contains(entry.getKey())) {
                        setting.remove(entry.getKey());
                    } else {
                        setting.add(entry.getKey());
                    }
                    return;
                }
            }
        }

        if (MathUtil.isHovered(mouseX, mouseY, x + width - 8 - 16, y + 3, 16, 16)) {
            rebornSort = !rebornSort;
            scrollHandler.setTargetValue(0);
        }
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        return searchBox.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return searchBox.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollHandler.scroll(verticalAmount);
        return true;
    }

    @Override
    public boolean isVisible() {
        return true;
    }

    @Override
    public float getHeight() {
        return 0;
    }

    @Override
    public float getWidth() {
        return 0;
    }

    private Identifier getEntityTexture(EntityType<?> entity) {
        // Return texture identifiers for different entity types
        if (entity == EntityType.PLAYER) return Identifier.of("textures/entity/steve.png");
        if (entity == EntityType.ZOMBIE) return Identifier.of("textures/entity/zombie/zombie.png");
        if (entity == EntityType.HUSK) return Identifier.of("textures/entity/zombie/husk.png");
        if (entity == EntityType.DROWNED) return Identifier.of("textures/entity/zombie/drowned.png");
        if (entity == EntityType.SKELETON) return Identifier.of("textures/entity/skeleton/skeleton.png");
        if (entity == EntityType.STRAY) return Identifier.of("textures/entity/skeleton/stray.png");
        if (entity == EntityType.CREEPER) return Identifier.of("textures/entity/creeper/creeper.png");
        if (entity == EntityType.ENDERMAN) return Identifier.of("textures/entity/enderman/enderman.png");
        if (entity == EntityType.SPIDER) return Identifier.of("textures/entity/spider/spider.png");
        if (entity == EntityType.CAVE_SPIDER) return Identifier.of("textures/entity/spider/cave_spider.png");
        if (entity == EntityType.WITCH) return Identifier.of("textures/entity/witch.png");
        if (entity == EntityType.PILLAGER) return Identifier.of("textures/entity/illager/pillager.png");
        if (entity == EntityType.VINDICATOR) return Identifier.of("textures/entity/illager/vindicator.png");
        if (entity == EntityType.EVOKER) return Identifier.of("textures/entity/illager/evoker.png");
        if (entity == EntityType.ENDER_DRAGON) return Identifier.of("textures/entity/enderdragon/dragon.png");
        if (entity == EntityType.WITHER) return Identifier.of("textures/entity/wither/wither.png");
        if (entity == EntityType.GHAST) return Identifier.of("textures/entity/ghast/ghast.png");
        if (entity == EntityType.BLAZE) return Identifier.of("textures/entity/blaze.png");
        if (entity == EntityType.SLIME) return Identifier.of("textures/entity/slime/slime.png");
        if (entity == EntityType.MAGMA_CUBE) return Identifier.of("textures/entity/slime/magma_cube.png");
        if (entity == EntityType.IRON_GOLEM) return Identifier.of("textures/entity/iron_golem.png");
        if (entity == EntityType.SNOW_GOLEM) return Identifier.of("textures/entity/snow_golem.png");
        if (entity == EntityType.VILLAGER) return Identifier.of("textures/entity/villager/villager.png");
        if (entity == EntityType.WANDERING_TRADER) return Identifier.of("textures/entity/wandering_trader.png");
        if (entity == EntityType.PIG) return Identifier.of("textures/entity/pig/pig.png");
        if (entity == EntityType.COW) return Identifier.of("textures/entity/cow/cow.png");
        if (entity == EntityType.SHEEP) return Identifier.of("textures/entity/sheep/sheep.png");
        if (entity == EntityType.CHICKEN) return Identifier.of("textures/entity/chicken.png");
        if (entity == EntityType.HORSE) return Identifier.of("textures/entity/horse/horse_white.png");
        if (entity == EntityType.DONKEY) return Identifier.of("textures/entity/horse/donkey.png");
        if (entity == EntityType.MULE) return Identifier.of("textures/entity/horse/mule.png");
        if (entity == EntityType.LLAMA) return Identifier.of("textures/entity/llama/llama_creamy.png");
        if (entity == EntityType.WOLF) return Identifier.of("textures/entity/wolf/wolf.png");
        if (entity == EntityType.CAT) return Identifier.of("textures/entity/cat/cat_black.png");
        if (entity == EntityType.OCELOT) return Identifier.of("textures/entity/cat/ocelot.png");
        if (entity == EntityType.BAT) return Identifier.of("textures/entity/bat.png");
        if (entity == EntityType.SQUID) return Identifier.of("textures/entity/squid.png");
        if (entity == EntityType.GLOW_SQUID) return Identifier.of("textures/entity/squid/glow_squid.png");
        if (entity == EntityType.DOLPHIN) return Identifier.of("textures/entity/dolphin.png");
        if (entity == EntityType.TURTLE) return Identifier.of("textures/entity/turtle/big_sea_turtle.png");
        if (entity == EntityType.COD) return Identifier.of("textures/entity/fish/cod.png");
        if (entity == EntityType.SALMON) return Identifier.of("textures/entity/fish/salmon.png");
        if (entity == EntityType.PUFFERFISH) return Identifier.of("textures/entity/fish/pufferfish.png");
        if (entity == EntityType.TROPICAL_FISH) return Identifier.of("textures/entity/fish/tropical_fish.png");
        
        // Return null for entities without specific textures
        return null;
    }

    private net.minecraft.item.Item getEntitySpawnEgg(EntityType<?> entityType) {
        // Map entity types to their spawn eggs
        if (entityType == EntityType.ZOMBIE) return net.minecraft.item.Items.ZOMBIE_SPAWN_EGG;
        if (entityType == EntityType.SKELETON) return net.minecraft.item.Items.SKELETON_SPAWN_EGG;
        if (entityType == EntityType.CREEPER) return net.minecraft.item.Items.CREEPER_SPAWN_EGG;
        if (entityType == EntityType.ENDERMAN) return net.minecraft.item.Items.ENDERMAN_SPAWN_EGG;
        if (entityType == EntityType.SPIDER) return net.minecraft.item.Items.SPIDER_SPAWN_EGG;
        if (entityType == EntityType.CAVE_SPIDER) return net.minecraft.item.Items.CAVE_SPIDER_SPAWN_EGG;
        if (entityType == EntityType.WITCH) return net.minecraft.item.Items.WITCH_SPAWN_EGG;
        if (entityType == EntityType.PILLAGER) return net.minecraft.item.Items.PILLAGER_SPAWN_EGG;
        if (entityType == EntityType.VINDICATOR) return net.minecraft.item.Items.VINDICATOR_SPAWN_EGG;
        if (entityType == EntityType.EVOKER) return net.minecraft.item.Items.EVOKER_SPAWN_EGG;
        if (entityType == EntityType.GHAST) return net.minecraft.item.Items.GHAST_SPAWN_EGG;
        if (entityType == EntityType.BLAZE) return net.minecraft.item.Items.BLAZE_SPAWN_EGG;
        if (entityType == EntityType.SLIME) return net.minecraft.item.Items.SLIME_SPAWN_EGG;
        if (entityType == EntityType.MAGMA_CUBE) return net.minecraft.item.Items.MAGMA_CUBE_SPAWN_EGG;
        if (entityType == EntityType.VILLAGER) return net.minecraft.item.Items.VILLAGER_SPAWN_EGG;
        if (entityType == EntityType.WANDERING_TRADER) return net.minecraft.item.Items.WANDERING_TRADER_SPAWN_EGG;
        if (entityType == EntityType.PIG) return net.minecraft.item.Items.PIG_SPAWN_EGG;
        if (entityType == EntityType.COW) return net.minecraft.item.Items.COW_SPAWN_EGG;
        if (entityType == EntityType.SHEEP) return net.minecraft.item.Items.SHEEP_SPAWN_EGG;
        if (entityType == EntityType.CHICKEN) return net.minecraft.item.Items.CHICKEN_SPAWN_EGG;
        if (entityType == EntityType.HORSE) return net.minecraft.item.Items.HORSE_SPAWN_EGG;
        if (entityType == EntityType.DONKEY) return net.minecraft.item.Items.DONKEY_SPAWN_EGG;
        if (entityType == EntityType.MULE) return net.minecraft.item.Items.MULE_SPAWN_EGG;
        if (entityType == EntityType.LLAMA) return net.minecraft.item.Items.LLAMA_SPAWN_EGG;
        if (entityType == EntityType.WOLF) return net.minecraft.item.Items.WOLF_SPAWN_EGG;
        if (entityType == EntityType.CAT) return net.minecraft.item.Items.CAT_SPAWN_EGG;
        if (entityType == EntityType.OCELOT) return net.minecraft.item.Items.OCELOT_SPAWN_EGG;
        if (entityType == EntityType.BAT) return net.minecraft.item.Items.BAT_SPAWN_EGG;
        if (entityType == EntityType.SQUID) return net.minecraft.item.Items.SQUID_SPAWN_EGG;
        if (entityType == EntityType.GLOW_SQUID) return net.minecraft.item.Items.GLOW_SQUID_SPAWN_EGG;
        if (entityType == EntityType.DOLPHIN) return net.minecraft.item.Items.DOLPHIN_SPAWN_EGG;
        if (entityType == EntityType.TURTLE) return net.minecraft.item.Items.TURTLE_SPAWN_EGG;
        if (entityType == EntityType.COD) return net.minecraft.item.Items.COD_SPAWN_EGG;
        if (entityType == EntityType.SALMON) return net.minecraft.item.Items.SALMON_SPAWN_EGG;
        if (entityType == EntityType.PUFFERFISH) return net.minecraft.item.Items.PUFFERFISH_SPAWN_EGG;
        if (entityType == EntityType.TROPICAL_FISH) return net.minecraft.item.Items.TROPICAL_FISH_SPAWN_EGG;
        if (entityType == EntityType.HUSK) return net.minecraft.item.Items.HUSK_SPAWN_EGG;
        if (entityType == EntityType.DROWNED) return net.minecraft.item.Items.DROWNED_SPAWN_EGG;
        if (entityType == EntityType.STRAY) return net.minecraft.item.Items.STRAY_SPAWN_EGG;
        
        // Return null if no spawn egg exists
        return null;
    }

    private String getEntityIcon(EntityType<?> entity) {
        // Return different icons based on entity type
        if (entity == EntityType.PLAYER) return "P";
        if (entity == EntityType.ZOMBIE || entity == EntityType.HUSK || entity == EntityType.DROWNED) return "Z";
        if (entity == EntityType.SKELETON || entity == EntityType.STRAY) return "S";
        if (entity == EntityType.CREEPER) return "C";
        if (entity == EntityType.ENDERMAN) return "E";
        if (entity == EntityType.SPIDER || entity == EntityType.CAVE_SPIDER) return "A";
        if (entity == EntityType.WITCH) return "W";
        if (entity == EntityType.PILLAGER || entity == EntityType.VINDICATOR || entity == EntityType.EVOKER) return "V";
        if (entity == EntityType.ENDER_DRAGON) return "D";
        if (entity == EntityType.WITHER) return "B";
        if (entity == EntityType.GHAST) return "G";
        if (entity == EntityType.BLAZE) return "F";
        if (entity == EntityType.SLIME || entity == EntityType.MAGMA_CUBE) return "M";
        if (entity == EntityType.IRON_GOLEM || entity == EntityType.SNOW_GOLEM) return "I";
        if (entity == EntityType.VILLAGER || entity == EntityType.WANDERING_TRADER) return "N";
        if (entity == EntityType.PIG || entity == EntityType.COW || entity == EntityType.SHEEP || entity == EntityType.CHICKEN) return "O";
        if (entity == EntityType.HORSE || entity == EntityType.DONKEY || entity == EntityType.MULE || entity == EntityType.LLAMA) return "H";
        if (entity == EntityType.WOLF || entity == EntityType.CAT || entity == EntityType.OCELOT) return "L";
        if (entity == EntityType.BAT) return "T";
        if (entity == EntityType.SQUID || entity == EntityType.GLOW_SQUID || entity == EntityType.DOLPHIN) return "U";
        if (entity == EntityType.TURTLE) return "R";
        if (entity == EntityType.COD || entity == EntityType.SALMON || entity == EntityType.PUFFERFISH || entity == EntityType.TROPICAL_FISH) return "Q";
        if (entity == EntityType.ITEM || entity == EntityType.EXPERIENCE_ORB) return "J";
        if (entity == EntityType.ARROW || entity == EntityType.SPECTRAL_ARROW || entity == EntityType.TRIDENT) return "K";
        if (entity == EntityType.SNOWBALL || entity == EntityType.EGG || entity == EntityType.ENDER_PEARL) return "Y";
        if (entity == EntityType.EXPERIENCE_BOTTLE || entity == EntityType.POTION) return "X";
        if (entity == EntityType.FIREBALL || entity == EntityType.SMALL_FIREBALL || entity == EntityType.DRAGON_FIREBALL) return "F";
        if (entity == EntityType.WITHER_SKULL) return "B";
        if (entity == EntityType.SHULKER_BULLET) return "S";
        if (entity == EntityType.LLAMA_SPIT) return "L";
        if (entity == EntityType.EVOKER_FANGS) return "V";
        if (entity == EntityType.AREA_EFFECT_CLOUD) return "A";
        if (entity == EntityType.LIGHTNING_BOLT) return "L";
        if (entity == EntityType.MINECART || entity == EntityType.CHEST_MINECART || entity == EntityType.FURNACE_MINECART || 
            entity == EntityType.TNT_MINECART || entity == EntityType.HOPPER_MINECART || entity == EntityType.SPAWNER_MINECART || 
            entity == EntityType.COMMAND_BLOCK_MINECART) return "M";
        if (entity == EntityType.ITEM_FRAME || entity == EntityType.GLOW_ITEM_FRAME) return "I";
        if (entity == EntityType.PAINTING) return "P";
        if (entity == EntityType.ARMOR_STAND) return "A";
        if (entity == EntityType.LEASH_KNOT) return "L";
        
        // Default icon for unknown entities
        return "E";
    }

    public static Stream<EntityType<?>> getAllEntities() {
        return Stream.of(
            EntityType.PLAYER,
            EntityType.ZOMBIE,
            EntityType.SKELETON,
            EntityType.CREEPER,
            EntityType.ENDERMAN,
            EntityType.SPIDER,
            EntityType.CAVE_SPIDER,
            EntityType.ENDERMITE,
            EntityType.SILVERFISH,
            EntityType.WITCH,
            EntityType.PILLAGER,
            EntityType.VINDICATOR,
            EntityType.EVOKER,
            EntityType.VEX,
            EntityType.RAVAGER,
            EntityType.HUSK,
            EntityType.STRAY,
            EntityType.DROWNED,
            EntityType.PHANTOM,
            EntityType.GHAST,
            EntityType.BLAZE,
            EntityType.MAGMA_CUBE,
            EntityType.SLIME,
            EntityType.ENDER_DRAGON,
            EntityType.WITHER,
            EntityType.IRON_GOLEM,
            EntityType.SNOW_GOLEM,
            EntityType.VILLAGER,
            EntityType.WANDERING_TRADER,
            EntityType.VILLAGER,
            EntityType.PIG,
            EntityType.COW,
            EntityType.SHEEP,
            EntityType.CHICKEN,
            EntityType.HORSE,
            EntityType.DONKEY,
            EntityType.MULE,
            EntityType.LLAMA,
            EntityType.WOLF,
            EntityType.CAT,
            EntityType.OCELOT,
            EntityType.PARROT,
            EntityType.BAT,
            EntityType.SQUID,
            EntityType.GLOW_SQUID,
            EntityType.DOLPHIN,
            EntityType.TURTLE,
            EntityType.COD,
            EntityType.SALMON,
            EntityType.PUFFERFISH,
            EntityType.TROPICAL_FISH,
            EntityType.ITEM,
            EntityType.EXPERIENCE_ORB,
            EntityType.ARROW,
            EntityType.SPECTRAL_ARROW,
            EntityType.TRIDENT,
            EntityType.SNOWBALL,
            EntityType.EGG,
            EntityType.ENDER_PEARL,
            EntityType.EXPERIENCE_BOTTLE,
            EntityType.POTION,
            EntityType.FIREBALL,
            EntityType.SMALL_FIREBALL,
            EntityType.DRAGON_FIREBALL,
            EntityType.WITHER_SKULL,
            EntityType.SHULKER_BULLET,
            EntityType.LLAMA_SPIT,
            EntityType.EVOKER_FANGS,
            EntityType.AREA_EFFECT_CLOUD,
            EntityType.LIGHTNING_BOLT,
            EntityType.MINECART,
            EntityType.CHEST_MINECART,
            EntityType.FURNACE_MINECART,
            EntityType.TNT_MINECART,
            EntityType.HOPPER_MINECART,
            EntityType.SPAWNER_MINECART,
            EntityType.COMMAND_BLOCK_MINECART,
            EntityType.ITEM_FRAME,
            EntityType.GLOW_ITEM_FRAME,
            EntityType.PAINTING,
            EntityType.ARMOR_STAND,
            EntityType.LEASH_KNOT
        );
    }
}
