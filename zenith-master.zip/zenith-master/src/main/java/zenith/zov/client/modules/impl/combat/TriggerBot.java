package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.MultiBooleanSetting;
import zenith.zov.utility.interfaces.IClient;
import zenith.zov.utility.game.player.RaytracingUtil;
import zenith.zov.utility.game.player.rotation.Rotation;
import zenith.zov.Zenith;

import java.util.Arrays;

@ModuleAnnotation(name = "TriggerBot", category = Category.COMBAT, description = "Automatically attacks entities you're looking at")
public class TriggerBot extends Module implements IClient {
    
    public static final TriggerBot INSTANCE = new TriggerBot();
    
    private LivingEntity target = null;
    
    private final MultiBooleanSetting attackSetting = MultiBooleanSetting.create("Attack setting", 
            Arrays.asList("Only Critical", "Dynamic Cooldown", "Break Shield", "UnPress Shield", "No Attack When Eat"));

    private TriggerBot() {
        // Constructor - settings are automatically discovered by reflection
    }

    @Override
    public void onDisable() {
        target = null;
        super.onDisable();
    }

    @EventTarget
    public void onTick(EventUpdate event) {
        EntityHitResult result = RaytracingUtil.raytraceEntity(3, Zenith.getInstance().getRotationManager().getCurrentRotation(), s -> !Zenith.getInstance().getFriendManager().isFriend(s.getName().getString()));
        if (result instanceof EntityHitResult r && r.getEntity() instanceof LivingEntity entity) {
            target = entity;
            
            // Check if we should attack
            if (shouldAttack(entity)) {
                performAttack(entity);
            }
        } else {
            target = null;
        }
    }
    
    private boolean shouldAttack(LivingEntity entity) {
        if (entity == null || entity == mc.player) return false;
        if (!entity.isAlive()) return false;
        
        // Check distance
        double distance = mc.player.distanceTo(entity);
        if (distance > 3.0) return false;
        
        // Check if player is eating and "No Attack When Eat" is enabled
        if (attackSetting.isEnable("No Attack When Eat") && mc.player.isUsingItem()) {
            return false;
        }
        
        // Check if only critical attacks are enabled
        if (attackSetting.isEnable("Only Critical")) {
            return isInCriticalState();
        }
        
        return true;
    }
    
    private boolean isInCriticalState() {
        return mc.player.fallDistance > 0 && !mc.player.isOnGround();
    }
    
    private void performAttack(LivingEntity entity) {
        // Check cooldown if "Dynamic Cooldown" is enabled
        if (attackSetting.isEnable("Dynamic Cooldown")) {
            if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) {
                return;
            }
        }
        
        // Handle shield breaking if "Break Shield" is enabled
        if (attackSetting.isEnable("Break Shield") && entity.isBlocking()) {
            // Use axe to break shield
            if (mc.player.getMainHandStack().getItem().toString().contains("axe")) {
                attackEntity(entity);
                return;
            }
        }
        
        // Handle shield unpressing if "UnPress Shield" is enabled
        if (attackSetting.isEnable("UnPress Shield") && entity.isBlocking()) {
            // Wait for shield to be lowered
            return;
        }
        
        // Perform normal attack
        attackEntity(entity);
    }
    
    private void attackEntity(LivingEntity entity) {
        if (mc.interactionManager != null && entity != null) {
            mc.interactionManager.attackEntity(mc.player, entity);
            mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        }
    }
}
