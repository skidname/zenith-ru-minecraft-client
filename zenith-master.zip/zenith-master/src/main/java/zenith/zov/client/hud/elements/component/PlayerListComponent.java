package zenith.zov.client.hud.elements.component;

import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.*;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Colors;
import net.minecraft.world.GameMode;
import org.jetbrains.annotations.Nullable;
import zenith.zov.Zenith;
import zenith.zov.base.animations.base.Animation;
import zenith.zov.base.animations.base.Easing;
import zenith.zov.client.hud.elements.draggable.DraggableHudElement;
import zenith.zov.client.modules.impl.render.Interface;
import zenith.zov.utility.game.other.TextUtil;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.CustomDrawContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;
import zenith.zov.utility.render.display.shader.DrawUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

public class PlayerListComponent extends DraggableHudElement {
    private final Animation animation = new Animation(250, Easing.BAKEK_SIZE);

    public PlayerListComponent(String name) {
        super(name, 0, 0, 0, 0, 0, 0, null);
    }


    @Override
    protected void renderXLine(CustomDrawContext ctx, SheetCode nearest) {

    }

    @Override
    protected void renderYLine(CustomDrawContext ctx, SheetCode nearest) {

    }

    @Override
    public void set(float x, float y) {

    }

    @Override
    public void update(float widthScreen, float heightScreen) {

    }

    @Override
    public void release() {

    }

    @Override
    public void windowResized(float newWindowWidth, float newWindowHeight) {

    }

    @Override
    public void set(CustomDrawContext ctx, float x, float y, Interface dragManager, float widthScreen, float heightScreen) {
    }

    @Override
    public JsonObject save() {
        return new JsonObject();
    }

    @Override
    public void load(JsonObject obj) {

    }

    @Override
    public void render(CustomDrawContext ctx) {

        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective scoreboardObjective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.LIST);

        animation.update(!(!mc.options.playerListKey.isPressed() || mc.isInSingleplayer() && mc.player.networkHandler.getListedPlayerListEntries().size() <= 1 && scoreboardObjective == null));
        if (animation.getValue() != 0) {
            render(ctx, ctx.getScaledWindowWidth(), scoreboard, scoreboardObjective);
        }
        animation.setDuration(250);
        animation.setEasing(Easing.BAKEK_SIZE);
    }


    //deobfuscation by Chatgpt
    public void render(
            DrawContext context,
            int scaledWindowWidth,
            Scoreboard scoreboard,
            @Nullable ScoreboardObjective objective
    ) {
        float delta = animation.getValue();
        // Collect players and prepare container for score/display rows
        List<PlayerListEntry> players = mc.inGameHud.getPlayerListHud().collectPlayerEntries();
        List<PlayerListHud.ScoreDisplayEntry> scoreEntries = new ArrayList<>(players.size());

        // Basic text measurements
        final int spaceWidth = mc.textRenderer.getWidth(" ");
        int nameColumnWidth = 0;   // maximum player name width
        int scoreColumnWidth = 0;  // additional width for score/format

        // Fill data for each table row
        for (PlayerListEntry entry : players) {
            Text nameText = mc.inGameHud.getPlayerListHud().getPlayerName(entry);
            nameColumnWidth = Math.max(nameColumnWidth, mc.textRenderer.getWidth(nameText));

            int rawScore = 0;
            Text formattedScoreText = null;
            int formattedScoreWidth = 0;

            if (objective != null) {
                // Get score for current objective
                ScoreHolder holder = ScoreHolder.fromProfile(entry.getProfile());
                ReadableScoreboardScore readableScore = scoreboard.getScore(holder, objective);

                if (readableScore != null) {
                    rawScore = readableScore.getScore();
                }

                // For non-heart renders format number and account for column width
                if (objective.getRenderType() != ScoreboardCriterion.RenderType.HEARTS) {
                    NumberFormat fmt = objective.getNumberFormatOr(StyledNumberFormat.YELLOW);
                    formattedScoreText = ReadableScoreboardScore.getFormattedScore(readableScore, fmt);
                    formattedScoreWidth = mc.textRenderer.getWidth(formattedScoreText);

                    // if there is something to draw — add padding + width
                    scoreColumnWidth = Math.max(scoreColumnWidth, formattedScoreWidth > 0 ? spaceWidth + formattedScoreWidth : 0);
                }
            }

            scoreEntries.add(new PlayerListHud.ScoreDisplayEntry(nameText, rawScore, formattedScoreText, formattedScoreWidth));
        }

        // Clear heart cache from players no longer in list
        if (!mc.inGameHud.getPlayerListHud().hearts.isEmpty()) {
            Set<UUID> visibleIds = players.stream()
                    .map(p -> p.getProfile().getId())
                    .collect(Collectors.toSet());
            mc.inGameHud.getPlayerListHud().hearts.keySet().removeIf(id -> !visibleIds.contains(id));
        }

        // Count columns and rows (limit: maximum 20 rows per column)
        final int total = players.size();
        int rowsPerColumn = total;
        int columns = 1;
        while (rowsPerColumn > 20) {
            columns++;
            rowsPerColumn = (total + columns - 1) / columns;
        }

        // In single player or encrypted connection show mini-skin
        final boolean showHead = true||mc.isInSingleplayer() || mc.getNetworkHandler().getConnection().isEncrypted();

        // Width of additional column for score/hearts
        final int extraColumnWidth;
        if (objective != null) {
            extraColumnWidth = (objective.getRenderType() == ScoreboardCriterion.RenderType.HEARTS) ? 90 : scoreColumnWidth;
        } else {
            extraColumnWidth = 0;
        }

        // Width of one column accounting for padding and window limits
        int columnWidth = Math.min(
                columns * ((showHead ? 9 : 0) + nameColumnWidth + extraColumnWidth + 13),
                scaledWindowWidth - 50
        ) / columns;

        // Horizontal and vertical coordinates for table rendering start
        int leftX = scaledWindowWidth / 2 - (columnWidth * columns + (columns - 1) * 5) / 2;
        int yCursor = 10; // start Y
        int contentWidth = columnWidth * columns + (columns - 1) * 5;

        // Header, wrap to lines and expand contentWidth if needed
        List<OrderedText> headerLines = null;
        if (mc.inGameHud.getPlayerListHud().header != null) {
            headerLines = mc.textRenderer.wrapLines(mc.inGameHud.getPlayerListHud().header, scaledWindowWidth - 50);
            for (OrderedText line : headerLines) {
                contentWidth = Math.max(contentWidth, mc.textRenderer.getWidth(line));
            }
        }

        // Footer, wrap to lines and expand contentWidth if needed
        List<OrderedText> footerLines = null;
        if (mc.inGameHud.getPlayerListHud().footer != null) {
            footerLines = mc.textRenderer.wrapLines(mc.inGameHud.getPlayerListHud().footer, scaledWindowWidth - 50);
            for (OrderedText line : footerLines) {
                contentWidth = Math.max(contentWidth, mc.textRenderer.getWidth(line));
            }
        }

        final int headerHeight = (headerLines != null) ? (headerLines.size() * 9) : 0;
        final int headerGap = (headerLines != null) ? 1 : 0;  // after header you do yCursor++
        final int tableHeight = rowsPerColumn * 9;
        final int footerGap = (footerLines != null) ? 1 : 0;  // before footer you do +1
        final int footerHeight = (footerLines != null) ? (footerLines.size() * 9) : 0;

        final int totalHeight = headerHeight + headerGap + tableHeight + footerGap + footerHeight;

// SCALE CENTER: by X — center of real box (leftX + width/2),
// by Y — from start Y (10) + half of total height
        final float centerX =scaledWindowWidth / 2 - 1 ;
        final float centerY = 10 + totalHeight / 2.0f;

// scale from delta (0..1). slightly clamp to avoid 0
        final float scale = Math.max(0.0001f, delta);

// apply matrix
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(centerX, centerY, 0.0f);
        matrices.scale(scale, scale, 1.0f);
        matrices.translate(-centerX, -centerY, 0.0f);


        // ⬆⬆ SCALE

        // Render header (if exists)
        if (headerLines != null) {
            context.fill(
                    scaledWindowWidth / 2 - contentWidth / 2 - 1,
                    yCursor - 1,
                    scaledWindowWidth / 2 + contentWidth / 2 + 1,
                    yCursor + headerLines.size() * 9,
                    Integer.MIN_VALUE
            );

                for (OrderedText line : headerLines) {
                int lineWidth = mc.textRenderer.getWidth(line);
                context.drawTextWithShadow(mc.textRenderer, line, scaledWindowWidth / 2 - lineWidth / 2, yCursor, 0xFFFFFFFF);
                yCursor += 9;
            }
            yCursor++; // gap after header
        }

        // Background under player table
        context.fill(
                scaledWindowWidth / 2 - contentWidth / 2 - 1,
                yCursor - 1,
                scaledWindowWidth / 2 + contentWidth / 2 + 1,
                yCursor + rowsPerColumn * 9,
                Integer.MIN_VALUE
        );

        final int rowBgColor =this.mc.options.getTextBackgroundColor(553648127);

        // Render rows
        for (int index = 0; index < total; index++) {
            int col = index / rowsPerColumn;
            int row = index % rowsPerColumn;

            int cellLeft = leftX + col * columnWidth + col * 5;
            int cellTop = yCursor + row * 9;

           context.fill(cellLeft, cellTop, cellLeft + columnWidth, cellTop + 8, rowBgColor);
            if (index >= players.size()) continue;

            PlayerListEntry ple = players.get(index);
            PlayerListHud.ScoreDisplayEntry sde = scoreEntries.get(index);
            GameProfile profile = ple.getProfile();

            int textX = cellLeft;

            if (showHead) {
                PlayerEntity playerEntity = mc.world.getPlayerByUuid(profile.getId());
                boolean flip = playerEntity != null && LivingEntityRenderer.shouldFlipUpsideDown(playerEntity);
                PlayerSkinDrawer.draw(
                        context,
                        ple.getSkinTextures().texture(),
                        cellLeft, cellTop, 8,
                        ple.shouldShowHat(),
                        flip,
                        -1
                );
                textX += 9;
            }

            int nameColor = (ple.getGameMode() == GameMode.SPECTATOR) ? 0x912D2D2F : Colors.WHITE;
            context.drawTextWithShadow(mc.textRenderer, sde.name(), textX, cellTop, nameColor);

            if (objective != null && ple.getGameMode() != GameMode.SPECTATOR) {
                int scoreLeft = textX + nameColumnWidth + 1;
                int scoreRight = scoreLeft + extraColumnWidth;
                if (scoreRight - scoreLeft > 5) {
                    mc.inGameHud.getPlayerListHud().renderScoreboardObjective(
                            objective, cellTop, sde, scoreLeft, scoreRight, profile.getId(), context
                    );
                }
            }

            mc.inGameHud.getPlayerListHud().renderLatencyIcon(
                    context, columnWidth, textX - (showHead ? 9 : 0), cellTop, ple
            );
        }

        // Footer
        if (footerLines != null) {
            yCursor += rowsPerColumn * 9 + 1;
            context.fill(
                    scaledWindowWidth / 2 - contentWidth / 2 - 1,
                    yCursor - 1,
                    scaledWindowWidth / 2 + contentWidth / 2 + 1,
                    yCursor + footerLines.size() * 9,
                    Integer.MIN_VALUE
            );
            for (OrderedText line : footerLines) {
                int lineWidth = mc.textRenderer.getWidth(line);
                context.drawTextWithShadow(mc.textRenderer, line, scaledWindowWidth / 2 - lineWidth / 2, yCursor, 0xFFFFFFFF);
                yCursor += 9;
            }
        }

        // Close scaling
        matrices.pop();
    }


}
