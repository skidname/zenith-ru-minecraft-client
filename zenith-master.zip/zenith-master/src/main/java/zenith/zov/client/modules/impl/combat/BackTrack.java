package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.util.math.Vec3d;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.render.EventRender3D;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.utility.entity.FakePlayerEntity;
import zenith.zov.utility.animation.PositionAnimation;

import java.awt.*;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

@ModuleAnnotation(name = "BackTrack", category = Category.COMBAT, description = "Abuses lag compensation to gain additional reach")
public class BackTrack extends Module {
    
    public static final BackTrack INSTANCE = new BackTrack();
    
    // Settings
    private final ModeSetting mode = new ModeSetting("Mode", "Dynamic", "Dynamic", "Static", "Sandevistan");
    private final NumberSetting delay = new NumberSetting("Delay", 50, 0, 2000, 1, () -> !mode.get().equals("Sandevistan"));
    private final ModeSetting clearMode = new ModeSetting("Clear Mode", () -> mode.get().equals("Sandevistan"), "Distance", "Time");
    private final NumberSetting clearLength = new NumberSetting("History Timeout", 300, 100, 2000, 1, () -> clearMode.get().equals("Time") && mode.get().equals("Sandevistan"));
    private final NumberSetting distanceLength = new NumberSetting("Distance Threshold", 6.0f, 1.0f, 10.0f, 0.1f, () -> clearMode.get().equals("Distance") && mode.get().equals("Sandevistan"));
    private final BooleanSetting render = new BooleanSetting("Render", true);
    private final BooleanSetting alpha = new BooleanSetting("Alpha", true, () -> mode.get().equals("Sandevistan"));

    // Data structures
    private final Queue<PacketData> packets = new LinkedBlockingQueue<>();
    private final LinkedBlockingQueue<PositionRecord> positionHistory = new LinkedBlockingQueue<>();

    // State variables
    private PlayerEntity trackedEntity;
    private Vec3d currentPos = Vec3d.ZERO;
    private Frustum frustum;
    private final PositionAnimation positionAnimation;
    
    private Vec3d lastPos = Vec3d.ZERO;
    private double distance;
    private int approachingTicks = 0;

    public BackTrack() {
        this.positionAnimation = new PositionAnimation(300.0f);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        cleanUp();
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (!event.isReceive() || mc.world == null || mc.player == null || trackedEntity == null) return;

        boolean cancel = false;
        Vec3d newPos = null;

        if (event.getPacket() instanceof EntityS2CPacket entityPacket) {
            Entity entity = entityPacket.getEntity(mc.world);
            if (entity == trackedEntity) {
                switch (entityPacket) {
                    case EntityS2CPacket.MoveRelative moveRelativePacket -> {
                        newPos = currentPos.add(moveRelativePacket.getDeltaX() / 4096.0, moveRelativePacket.getDeltaY() / 4096.0, moveRelativePacket.getDeltaZ() / 4096.0);
                        cancel = true;
                    }
                    case EntityS2CPacket.RotateAndMoveRelative rotateAndMoveRelativePacket -> {
                        newPos = currentPos.add(rotateAndMoveRelativePacket.getDeltaX() / 4096.0, rotateAndMoveRelativePacket.getDeltaY() / 4096.0, rotateAndMoveRelativePacket.getDeltaZ() / 4096.0);
                        cancel = true;
                    }
                    case EntityS2CPacket.Rotate ignored -> {
                        cancel = true;
                        newPos = currentPos;
                    }
                    default -> {
                    }
                }
            }
        } else if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket packet && packet.getEntityId() == trackedEntity.getId()) {
            cancel = true;
        }

        if (cancel && newPos != null) {
            currentPos = newPos;
            positionAnimation.animate(newPos);
                if (mode.get().equals("Sandevistan")) {
                    FakePlayerEntity sandevistanClone = new FakePlayerEntity(trackedEntity, "", true);
                    PositionRecord record = new PositionRecord(sandevistanClone, System.currentTimeMillis());
                    positionHistory.add(record);
                    record.entity().spawnPlayer();
                } else {
                packets.add(new PacketData(event.getPacket(), System.currentTimeMillis()));
                event.cancel();
            }
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (mc.player.age > 10 && trackedEntity != null && !mode.get().equals("Sandevistan")) {
            if (lastPos.equals(Vec3d.ZERO)) {
                lastPos = currentPos;
            }

            Vec3d targetVelocity = currentPos.subtract(lastPos);
            Vec3d toTarget = currentPos.subtract(mc.player.getPos());
            boolean isApproaching = !targetVelocity.equals(Vec3d.ZERO) && toTarget.lengthSquared() > 0.001 &&
                    targetVelocity.normalize().dotProduct(toTarget.normalize()) < -0.01;

            distance = mc.player.squaredDistanceTo(currentPos);

            switch (mode.get()) {
                case "Static" -> applyPackets(false);
                case "Dynamic" -> {
                    if (isApproaching) {
                        approachingTicks++;
                    } else {
                        approachingTicks = Math.max(0, approachingTicks - 1);
                    }

                    if (approachingTicks > 1 || distance > 36) {
                        applyPackets(true);
                        approachingTicks = 0;
                    } else {
                        applyPackets(false);
                    }
                }
            }
            lastPos = currentPos;
        }
    }

    @EventTarget
    public void onPacketSend(EventPacket event) {
        if (!event.isSent() || !(event.getPacket() instanceof PlayerInteractEntityC2SPacket packet)) return;
        
        // Simplified packet handling - just track when we attack entities
        // Note: This is a simplified version due to API limitations
        if (trackedEntity != null) {
            // Basic tracking logic without complex packet analysis
            currentPos = trackedEntity.getPos();
            positionAnimation.setInstant(currentPos);
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mode.get().equals("Sandevistan")) {
            if (clearMode.get().equals("Distance")) {
                Iterator<PositionRecord> iterator = positionHistory.iterator();
                while (iterator.hasNext()) {
                    PositionRecord p = iterator.next();
                    if (trackedEntity != null && p.entity().getPos().distanceTo(trackedEntity.getPos()) > distanceLength.getCurrent()) {
                        p.entity().despawnPlayer();
                        iterator.remove();
                    }
                }
            } else {
                long cutoff = System.currentTimeMillis() - (long) clearLength.getCurrent();
                Iterator<PositionRecord> iterator = positionHistory.iterator();
                while (iterator.hasNext()) {
                    PositionRecord p = iterator.next();
                    if (p.timestamp() < cutoff) {
                        p.entity().despawnPlayer();
                        iterator.remove();
                    }
                }
            }
        }

        if (!render.isEnabled() || trackedEntity == null) return;

        if (frustum != null && !frustum.isVisible(trackedEntity.getBoundingBox())) return;

        MatrixStack matrixStack = event.getMatrix();
        matrixStack.push();

        float halfWidth = trackedEntity.getWidth() / 2.0f;
        float height = trackedEntity.getHeight();

        if (!mode.get().equals("Sandevistan")) {
            Vec3d pos = positionAnimation.getCurrentPos();

            // Simple rendering - just draw a basic box outline
            // Note: This is a simplified version since we don't have access to the full rendering context
            // In a real implementation, you'd use the proper rendering utilities
        }
        matrixStack.pop();
    }

    public static Vec3d interpolate(Vec3d from, Vec3d to, float tickDelta) {
        double x = from.x + (to.x - from.x) * tickDelta;
        double y = from.y + (to.y - from.y) * tickDelta;
        double z = from.z + (to.z - from.z) * tickDelta;
        return new Vec3d(x, y, z);
    }

    @SuppressWarnings("unchecked")
    private void applyPackets(boolean force) {
        float val = delay.getCurrent();
        packets.removeIf(packetData -> {
            if (System.currentTimeMillis() - packetData.time() > val || force) {
                try {
                    if (packetData.packet() instanceof Packet<?> clientPacket) {
                        ((Packet<ClientPlayPacketListener>) clientPacket).apply(mc.getNetworkHandler());
                    }
                } catch (ClassCastException ignored) {
                }
                return true;
            }
            return false;
        });
    }

    @Override
    public void onDisable() {
        super.onDisable();
        cleanUp();
    }

    private void cleanUp() {
        applyPackets(true);
        packets.clear();
        positionHistory.forEach(p -> p.entity().despawnPlayer());
        positionHistory.clear();
        trackedEntity = null;
        currentPos = Vec3d.ZERO;
        positionAnimation.setInstant(Vec3d.ZERO);
        lastPos = Vec3d.ZERO;
        approachingTicks = 0;
    }

    private record PacketData(Packet<?> packet, long time) {
    }

    private record PositionRecord(FakePlayerEntity entity, long timestamp) {
    }
}
