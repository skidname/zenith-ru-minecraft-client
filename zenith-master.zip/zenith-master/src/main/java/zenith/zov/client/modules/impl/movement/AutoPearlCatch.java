package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "AutoPearlCatch", description = "Throws ender pearl high and uses wind charges to catch it", category = Category.MOVEMENT)
public class AutoPearlCatch extends Module {
    
    private final NumberSetting throwHeight = new NumberSetting("Throw Height", 50, 10, 100, 1);
    private final NumberSetting windChargeDelay = new NumberSetting("Wind Charge Delay", 20, 5, 60, 1);
    private final BooleanSetting silent = new BooleanSetting("Silent", false);
    private final BooleanSetting autoThrow = new BooleanSetting("Auto Throw", true);
    
    private boolean hasThrownPearl = false;
    private int windChargeSlot = -1;
    private int pearlSlot = -1;
    private int originalSlot = -1;
    private int delayTicks = 0;

    public AutoPearlCatch() {
        EventManager.register(this);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        
        if (isEnabled()) {
            if (!hasThrownPearl) {
                throwBothSimultaneously();
            } else {
                // Reset after a short delay to allow continuous use
                delayTicks++;
                if (delayTicks >= 10) { // 10 tick delay between uses
                    hasThrownPearl = false;
                    delayTicks = 0;
                }
            }
        } else {
            // Reset when disabled
            hasThrownPearl = false;
            delayTicks = 0;
            if (silent.isEnabled() && originalSlot != -1) {
                mc.player.getInventory().setSelectedSlot(originalSlot);
            }
        }
    }
    
    private void throwBothSimultaneously() {
        // Find both items in inventory
        pearlSlot = findPearlSlot();
        windChargeSlot = findWindChargeSlot();
        
        if (pearlSlot == -1) {
            System.out.println("No ender pearl found in inventory");
            return;
        }
        
        if (windChargeSlot == -1) {
            System.out.println("No wind charge found in inventory");
            return;
        }
        
        // Save original slot if silent mode
        if (silent.isEnabled()) {
            originalSlot = mc.player.getInventory().selectedSlot;
        }
        
        // Throw ender pearl first (look up at 45 degrees)
        mc.player.getInventory().setSelectedSlot(pearlSlot);
        mc.player.setPitch(-45.0f);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        
        // Immediately throw wind charge (look straight up)
        mc.player.getInventory().setSelectedSlot(windChargeSlot);
        mc.player.setPitch(-90.0f);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        
        // Return to original slot if silent mode
        if (silent.isEnabled() && originalSlot != -1) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        
        hasThrownPearl = true;
        delayTicks = 0;
        System.out.println("Thrown both ender pearl and wind charge simultaneously");
    }
    
    private int findPearlSlot() {
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) {
                if (mc.player.getInventory().getStack(i).getItem() == Items.ENDER_PEARL) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    private int findWindChargeSlot() {
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) {
                if (mc.player.getInventory().getStack(i).getItem() == Items.WIND_CHARGE) {
                    return i;
                }
            }
        }
        return -1;
    }
}
