package zenith.zov.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.AirBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.render.EventRender3D;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.interfaces.IMinecraft;

import java.awt.*;
import java.util.HashMap;
import java.util.concurrent.CopyOnWriteArrayList;

@ModuleAnnotation(
        name = "HitParticles",
        category = Category.RENDER,
        description = "Shows visual particles when entities take damage"
)
public final class HitParticles extends Module implements IMinecraft {
    public static final HitParticles INSTANCE = new HitParticles();

    private final ModeSetting mode = new ModeSetting("Mode", "Stars", "Orbiz", "Stars", "Hearts", "Bloom", "Text");
    private final ModeSetting physics = new ModeSetting("Physics", "Fall", "Fall", "Fly");
    private final NumberSetting colorRed = new NumberSetting("Color Red", 0, 0, 255, 1);
    private final NumberSetting colorGreen = new NumberSetting("Color Green", 255, 0, 255, 1);
    private final NumberSetting colorBlue = new NumberSetting("Color Blue", 0, 0, 255, 1);
    private final NumberSetting colorAlpha = new NumberSetting("Color Alpha", 255, 0, 255, 1);
    private final BooleanSetting onlySelf = new BooleanSetting("Self", false);
    private final NumberSetting amount = new NumberSetting("Amount", 2, 1, 5, 1);
    private final NumberSetting lifeTime = new NumberSetting("LifeTime", 2, 1, 10, 1);
    private final NumberSetting speed = new NumberSetting("Speed", 2, 1, 20, 1);
    private final NumberSetting starsScale = new NumberSetting("Scale", 3.0f, 1.0f, 10.0f, 0.1f);
    private final ModeSetting colorMode = new ModeSetting("ColorMode", "Custom", "Custom", "Sync");
    private final NumberSetting healColorRed = new NumberSetting("Heal Color Red", 48, 0, 255, 1);
    private final NumberSetting healColorGreen = new NumberSetting("Heal Color Green", 64, 0, 255, 1);
    private final NumberSetting healColorBlue = new NumberSetting("Heal Color Blue", 16, 0, 255, 1);
    private final NumberSetting damageColorRed = new NumberSetting("Damage Color Red", 241, 0, 255, 1);
    private final NumberSetting damageColorGreen = new NumberSetting("Damage Color Green", 98, 0, 255, 1);
    private final NumberSetting damageColorBlue = new NumberSetting("Damage Color Blue", 51, 0, 255, 1);

    private final HashMap<Integer, Float> healthMap = new HashMap<>();
    private final CopyOnWriteArrayList<Particle> particles = new CopyOnWriteArrayList<>();

    private HitParticles() {
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        particles.removeIf(Particle::update);

        if (mode.get().equals("Text")) {
            for (Entity entity : mc.world.getEntities()) {
                if (entity == null || mc.player.squaredDistanceTo(entity) > 256f || !entity.isAlive() || !(entity instanceof LivingEntity lent))
                    continue;

                Color c = colorMode.get().equals("Sync") ? getRandomColor() : new Color((int) colorRed.getCurrent(), (int) colorGreen.getCurrent(), (int) colorBlue.getCurrent(), (int) colorAlpha.getCurrent());
                float health = lent.getHealth() + lent.getAbsorptionAmount();
                float lastHealth = healthMap.getOrDefault(entity.getId(), health);
                healthMap.put(entity.getId(), health);
                if (lastHealth == health)
                    continue;

                particles.add(new Particle((float) lent.getX(), random((float) (lent.getY() + lent.getHeight()), (float) lent.getY()), (float) lent.getZ(), c,
                        random(0, 180), random(10f, 60f), health - lastHealth));
            }
            return;
        }

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (onlySelf.isEnabled() && player != mc.player)
                continue;
            if (player.hurtTime > 0) {
                Color c = colorMode.get().equals("Sync") ? getRandomColor() : new Color((int) colorRed.getCurrent(), (int) colorGreen.getCurrent(), (int) colorBlue.getCurrent(), (int) colorAlpha.getCurrent());
                for (int i = 0; i < (int) amount.getCurrent(); i++) {
                    particles.add(new Particle((float) player.getX(), random((float) (player.getY() + player.getHeight()), (float) player.getY()), (float) player.getZ(), c, random(0, 180), random(10f, 60f), 0));
                }
            }
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.player == null || mc.world == null) return;

        RenderSystem.disableDepthTest();
        for (Particle particle : particles) {
            particle.render(event.getMatrix(), event.getPartialTicks());
        }
        RenderSystem.enableDepthTest();
    }

    private Color getRandomColor() {
        return new Color((int) (Math.random() * 255), (int) (Math.random() * 255), (int) (Math.random() * 255), 255);
    }

    private float random(float min, float max) {
        return (float) (Math.random() * (max - min) + min);
    }

    private int random(int min, int max) {
        return (int) (Math.random() * (max - min) + min);
    }

    public class Particle {
        float x;
        float y;
        float z;

        float px;
        float py;
        float pz;

        float motionX;
        float motionY;
        float motionZ;

        float rotationAngle;
        float rotationSpeed;
        float health;

        long time;
        Color color;

        public Particle(float x, float y, float z, Color color, float rotationAngle, float rotationSpeed, float health) {
            this.x = x;
            this.y = y;
            this.z = z;
            px = x;
            py = y;
            pz = z;
            motionX = random(-(float) speed.getCurrent() / 50f, (float) speed.getCurrent() / 50f);
            motionY = random(-(float) speed.getCurrent() / 50f, (float) speed.getCurrent() / 50f);
            motionZ = random(-(float) speed.getCurrent() / 50f, (float) speed.getCurrent() / 50f);
            time = System.currentTimeMillis();
            this.color = color;
            this.rotationAngle = rotationAngle;
            this.rotationSpeed = rotationSpeed;
            this.health = health;
        }

        public long getTime() {
            return time;
        }

        public boolean update() {
            double sp = Math.sqrt(motionX * motionX + motionZ * motionZ);
            px = x;
            py = y;
            pz = z;

            x += motionX;
            y += motionY;
            z += motionZ;

            if (posBlock(x, y - (float) starsScale.getCurrent() / 10f, z)) {
                motionY = -motionY / 1.1f;
                motionX = motionX / 1.1f;
                motionZ = motionZ / 1.1f;
            } else {
                if (posBlock(x - sp, y, z - sp)
                        || posBlock(x + sp, y, z + sp)
                        || posBlock(x + sp, y, z - sp)
                        || posBlock(x - sp, y, z + sp)
                        || posBlock(x + sp, y, z)
                        || posBlock(x - sp, y, z)
                        || posBlock(x, y, z + sp)
                        || posBlock(x, y, z - sp)
                ) {
                    motionX = -motionX;
                    motionZ = -motionZ;
                }
            }

            if (physics.get().equals("Fall"))
                motionY -= 0.035f;

            motionX /= 1.005f;
            motionZ /= 1.005f;
            motionY /= 1.005f;

            return System.currentTimeMillis() - getTime() > (long) lifeTime.getCurrent() * 1000;
        }

        public void render(MatrixStack matrixStack, float partialTicks) {
            float size = (float) starsScale.getCurrent();
            float scale = mode.get().equals("Text") ? 0.025f * size : 0.07f;

            final double posX = interpolate(px, x, partialTicks) - mc.getEntityRenderDispatcher().camera.getPos().getX();
            final double posY = interpolate(py, y, partialTicks) + 0.1 - mc.getEntityRenderDispatcher().camera.getPos().getY();
            final double posZ = interpolate(pz, z, partialTicks) - mc.getEntityRenderDispatcher().camera.getPos().getZ();

            matrixStack.push();
            matrixStack.translate(posX, posY, posZ);

            matrixStack.scale(scale, scale, scale);

            matrixStack.translate(size / 2, size / 2, size / 2);
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-mc.gameRenderer.getCamera().getYaw()));
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(mc.gameRenderer.getCamera().getPitch()));

            if (mode.get().equals("Text"))
                matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180));
            else
                matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotationAngle += (float) (partialTicks * rotationSpeed)));

            matrixStack.translate(-size / 2, -size / 2, -size / 2);

            switch (mode.get()) {
                case "Orbiz" -> {
                    drawOrbiz(matrixStack, 0.0f, 0.3, color);
                    drawOrbiz(matrixStack, -0.1f, 0.5, color);
                    drawOrbiz(matrixStack, -0.2f, 0.7, color);
                }
                case "Stars" -> drawStar(matrixStack, color, size);
                case "Hearts" -> drawHeart(matrixStack, color, size);
                case "Bloom" -> drawBloom(matrixStack, color, size);
                case "Text" -> {
                    Color textColor = health > 0 ? 
                        new Color((int) healColorRed.getCurrent(), (int) healColorGreen.getCurrent(), (int) healColorBlue.getCurrent()) :
                        new Color((int) damageColorRed.getCurrent(), (int) damageColorGreen.getCurrent(), (int) damageColorBlue.getCurrent());
                    // Text rendering would need proper font renderer implementation
                }
            }

            matrixStack.scale(0.8f, 0.8f, 0.8f);
            matrixStack.pop();
        }

        private boolean posBlock(double x, double y, double z) {
            Block b = mc.world.getBlockState(BlockPos.ofFloored(x, y, z)).getBlock();
            return (!(b instanceof AirBlock) && b != Blocks.WATER && b != Blocks.LAVA);
        }

        private float interpolate(float prev, float current, float delta) {
            return prev + (current - prev) * delta;
        }
    }

    // Placeholder rendering methods - these would need proper implementation
    private void drawOrbiz(MatrixStack matrixStack, float offset, double alpha, Color color) {
        // Implementation needed
    }

    private void drawStar(MatrixStack matrixStack, Color color, float size) {
        // Implementation needed
    }

    private void drawHeart(MatrixStack matrixStack, Color color, float size) {
        // Implementation needed
    }

    private void drawBloom(MatrixStack matrixStack, Color color, float size) {
        // Implementation needed
    }

}
