package zenith.zov.client.modules.impl.crystal;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.interfaces.IMinecraft;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.item.Items;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Vec3d;
import java.util.HashSet;
import java.util.Set;

@ModuleAnnotation(name = "SafeAnchor", category = Category.CRYSTAL, description = "Places a block in front of you before popping a respawn anchor")
public final class SafeAnchor extends Module implements IMinecraft {
    public static final SafeAnchor INSTANCE = new SafeAnchor();

    private BlockPos lastPlacedAnchor = null;
    private long lastPlaceTime = 0;
    private BlockPos currentlyCharging = null;
    private long chargeStartTime = 0;
    private long protectionDelay = 100; // Wait 100ms after charging before exploding
    private boolean protectionPlaced = false;
    private Set<BlockPos> myAnchors = new HashSet<>(); // Track anchors I placed

    private SafeAnchor() {
    }

    @EventTarget
    private void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        // Check for newly placed anchors to explode
        checkForAnchorsToExplode();

        // Track when player places an anchor
        if (mc.crosshairTarget instanceof BlockHitResult blockHit) {
            if (mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) {
                // Player is placing an anchor, track it
                BlockPos targetPos = blockHit.getBlockPos();
                Direction side = blockHit.getSide();
                
                if (!mc.world.getBlockState(targetPos).isReplaceable()) {
                    // Placing against a solid block
                    switch (side) {
                        case UP -> myAnchors.add(targetPos.up());
                        case DOWN -> myAnchors.add(targetPos.down());
                        case EAST -> myAnchors.add(targetPos.east());
                        case WEST -> myAnchors.add(targetPos.west());
                        case NORTH -> myAnchors.add(targetPos.north());
                        case SOUTH -> myAnchors.add(targetPos.south());
                    }
                } else {
                    // Replacing the block at target position
                    myAnchors.add(targetPos);
                }
            }
            
            // Only protect anchors that I placed
            if (mc.world.getBlockState(blockHit.getBlockPos()).getBlock() == Blocks.RESPAWN_ANCHOR) {
                BlockPos anchorPos = blockHit.getBlockPos();
                if (myAnchors.contains(anchorPos)) {
                    BlockPos posInFront = mc.player.getBlockPos().offset(mc.player.getHorizontalFacing());

                    // Check if the block space in front is empty
                    if (mc.world.isAir(posInFront)) {
                        // Check if position is within reach (max 4.5 blocks)
                        double distance = mc.player.getPos().distanceTo(Vec3d.ofCenter(posInFront));
                        if (distance <= 4.5) {
                            // Try to use glowstone first, then fallback to other blocks
                            int glowstoneSlot = findGlowstoneSlot();
                            int slot = glowstoneSlot != -1 ? glowstoneSlot : findBlockSlot();
                            
                            if (slot != -1) {
                                // Switch to block slot
                                mc.player.getInventory().selectedSlot = slot;

                                // Place block
                                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                                    new BlockHitResult(Vec3d.ofCenter(posInFront), Direction.UP, posInFront.down(), false));
                            }
                        }
                    }
                }
            }
        }
    }

    private void checkForAnchorsToExplode() {
        // Check if we're currently charging an anchor and if it's been charged
        if (currentlyCharging != null) {
            if (System.currentTimeMillis() - chargeStartTime > 2000) {
                // Timeout - reset if taking too long
                currentlyCharging = null;
                chargeStartTime = 0;
                protectionPlaced = false;
            } else if (mc.world.getBlockState(currentlyCharging).getBlock() == Blocks.RESPAWN_ANCHOR) {
                int charges = mc.world.getBlockState(currentlyCharging).get(RespawnAnchorBlock.CHARGES);
                if (charges > 0) {
                    // Anchor is now charged, but wait for protection and delay
                    if (!protectionPlaced) {
                        // Try to place protection around the player
                        placeProtectionBlocks();
                        protectionPlaced = true;
                    }
                    
                    // Wait for the protection delay before exploding
                    if (System.currentTimeMillis() - chargeStartTime > protectionDelay) {
                        mc.player.getInventory().selectedSlot = 0;
                    explodeAnchor(currentlyCharging);
                    myAnchors.remove(currentlyCharging); // Remove from tracking after explosion
                    currentlyCharging = null;
                    chargeStartTime = 0;
                    protectionPlaced = false;
                    return;
                    }
                }
            } else {
                // Anchor no longer exists
                currentlyCharging = null;
                chargeStartTime = 0;
                protectionPlaced = false;
            }
        }
        
        // Only look for new anchors if we're not currently charging one
        if (currentlyCharging != null) return;
        
        // Look for MY respawn anchors nearby
        BlockPos playerPos = mc.player.getBlockPos();
        
        for (int x = -5; x <= 5; x++) {
            for (int y = -3; y <= 3; y++) {
                for (int z = -5; z <= 5; z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    
                    if (mc.world.getBlockState(pos).getBlock() == Blocks.RESPAWN_ANCHOR && myAnchors.contains(pos)) {
                        int charges = mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES);
                        
                        // If MY anchor is not charged and we haven't tried this one recently
                        if (charges == 0 && (lastPlacedAnchor == null || !lastPlacedAnchor.equals(pos) || 
                            System.currentTimeMillis() - lastPlaceTime > 2000)) {
                            
                            chargeAnchor(pos);
                            currentlyCharging = pos;
                            chargeStartTime = System.currentTimeMillis();
                            lastPlacedAnchor = pos;
                            lastPlaceTime = System.currentTimeMillis();
                            return; // Only charge one at a time
                        }
                    }
                }
            }
        }
    }

    private void chargeAnchor(BlockPos anchorPos) {
        // Find glowstone in hotbar
        int glowstoneSlot = findGlowstoneSlot();
        if (glowstoneSlot == -1) return;
        
        // Check if anchor is within reach
        double distance = mc.player.getPos().distanceTo(Vec3d.ofCenter(anchorPos));
        if (distance > 4.5) return; // Too far to interact
        
        mc.player.getInventory().selectedSlot = glowstoneSlot;
        
        // Right-click the anchor to charge it with glowstone
        BlockHitResult hitResult = new BlockHitResult(
            Vec3d.ofCenter(anchorPos), 
            Direction.UP, 
            anchorPos, 
            false
        );
        
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
    }

    private void placeProtectionBlocks() {
        BlockPos playerPos = mc.player.getBlockPos();
        // Try to use glowstone first, then fallback to other blocks
        int glowstoneSlot = findGlowstoneSlot();
        int blockSlot = glowstoneSlot != -1 ? glowstoneSlot : findBlockSlot();
        
        if (blockSlot == -1) return; // No blocks available
        
        // Place one block in front of the player for protection
        BlockPos posInFront = playerPos.offset(mc.player.getHorizontalFacing());
        
        // Check if position is within reach (max 4.5 blocks)
        double distance = mc.player.getPos().distanceTo(Vec3d.ofCenter(posInFront));
        if (distance > 4.5) return; // Too far to place
        
        if (mc.world.isAir(posInFront) && mc.world.getWorldBorder().contains(posInFront)) {
            int originalSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = blockSlot;
            
            // Use player's exact position for more accurate placement
            Vec3d playerEyePos = mc.player.getEyePos();
            Vec3d targetPos = Vec3d.ofCenter(posInFront);
            
            // Place block in front of player with proper hit position
            BlockHitResult hitResult = new BlockHitResult(
                Vec3d.ofCenter(posInFront), 
                Direction.UP, 
                posInFront.down(), 
                false
            );
            
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
            mc.player.getInventory().selectedSlot = originalSlot;
        }
    }

    private void explodeAnchor(BlockPos anchorPos) {
        // Check if anchor is within reach
        double distance = mc.player.getPos().distanceTo(Vec3d.ofCenter(anchorPos));
        if (distance > 4.5) return; // Too far to interact
        
        // Right-click the anchor to explode it
        BlockHitResult hitResult = new BlockHitResult(
            Vec3d.ofCenter(anchorPos), 
            Direction.UP, 
            anchorPos, 
            false
        );
        
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
    }

    // Finds a block in hotbar (e.g., obsidian or stone)
    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.OBSIDIAN
             || mc.player.getInventory().getStack(i).getItem() == Items.GLOWSTONE
             || mc.player.getInventory().getStack(i).getItem() == Items.COBBLESTONE) {
                return i;
            }
        }
        return -1;
    }

    // Finds glowstone in hotbar
    private int findGlowstoneSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.GLOWSTONE) {
                return i;
            }
        }
        return -1;
    }
}