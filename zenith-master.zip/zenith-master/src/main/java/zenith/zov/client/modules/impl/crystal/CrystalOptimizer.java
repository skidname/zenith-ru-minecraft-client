package zenith.zov.client.modules.impl.crystal;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.interfaces.IMinecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "CrystalOptimizer", category = Category.CRYSTAL, description = "Makes your crystals disappear faster client-side so you can place crystals faster")
public final class CrystalOptimizer extends Module implements IMinecraft {
    public static final CrystalOptimizer INSTANCE = new CrystalOptimizer();

    private CrystalOptimizer() {
        // Settings are automatically managed by the module system
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventTarget
    public void onPacketSend(EventPacket event) {
        if (event.isSent() && event.getPacket() instanceof PlayerInteractEntityC2SPacket interactPacket) {
            interactPacket.handle(new PlayerInteractEntityC2SPacket.Handler() {
                @Override
                public void interact(Hand hand) {
                    // Empty implementation
                }

                @Override
                public void interactAt(Hand hand, Vec3d pos) {
                    // Empty implementation
                }

                @Override
                public void attack() {
                    if (mc.crosshairTarget == null) return;

                    if (mc.crosshairTarget.getType() == HitResult.Type.ENTITY && 
                        mc.crosshairTarget instanceof EntityHitResult hit) {
                        
                        if (hit.getEntity() instanceof EndCrystalEntity) {
                            StatusEffectInstance weakness = mc.player.getStatusEffect(StatusEffects.WEAKNESS);
                            StatusEffectInstance strength = mc.player.getStatusEffect(StatusEffects.STRENGTH);
                            
                            if (!(weakness == null || 
                                  (strength != null && strength.getAmplifier() > weakness.getAmplifier()) || 
                                  isTool(mc.player.getMainHandStack()))) {
                                return;
                            }

                            // Remove the crystal client-side for faster removal
                            if (mc.world != null) {
                                hit.getEntity().setRemoved(Entity.RemovalReason.KILLED);
                                hit.getEntity().onRemoved();
                                mc.world.removeEntity(hit.getEntity().getId(), Entity.RemovalReason.KILLED);
                            }
                        }
                    }
                }
            });
        }
    }

    private boolean isTool(ItemStack stack) {
        // Check if the item is a tool (sword, axe, pickaxe, etc.)
        Item item = stack.getItem();
        return item == Items.DIAMOND_PICKAXE || item == Items.NETHERITE_PICKAXE ||
               item == Items.DIAMOND_AXE || item == Items.NETHERITE_AXE ||
               item == Items.DIAMOND_SHOVEL || item == Items.NETHERITE_SHOVEL ||
               item == Items.DIAMOND_SWORD || item == Items.NETHERITE_SWORD ||
               item == Items.DIAMOND_HOE || item == Items.NETHERITE_HOE ||
               item == Items.IRON_PICKAXE || item == Items.IRON_AXE ||
               item == Items.IRON_SHOVEL || item == Items.IRON_SWORD ||
               item == Items.IRON_HOE || item == Items.STONE_PICKAXE ||
               item == Items.STONE_AXE || item == Items.STONE_SHOVEL ||
               item == Items.STONE_SWORD || item == Items.STONE_HOE ||
               item == Items.WOODEN_PICKAXE || item == Items.WOODEN_AXE ||
               item == Items.WOODEN_SHOVEL || item == Items.WOODEN_SWORD ||
               item == Items.WOODEN_HOE || item == Items.GOLDEN_PICKAXE ||
               item == Items.GOLDEN_AXE || item == Items.GOLDEN_SHOVEL ||
               item == Items.GOLDEN_SWORD || item == Items.GOLDEN_HOE ||
               item == Items.MACE;
    }
}
