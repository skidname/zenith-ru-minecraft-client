package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.render.EventRender3D;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.game.player.MovingUtil;
import zenith.zov.utility.interfaces.IMinecraft;
import zenith.zov.utility.render.level.Render3DUtil;

import java.util.ArrayList;
import java.util.List;

@ModuleAnnotation(name = "Scaffold", description = "Automatically places blocks under your feet", category = Category.MOVEMENT)
public class Scaffold extends Module implements IMinecraft {
    
    public static final Scaffold INSTANCE = new Scaffold();
    
    // Settings
    private final ModeSetting mode = new ModeSetting("Mode");
    private final ModeSetting.Value normal = new ModeSetting.Value(mode, "Normal").select();
    private final ModeSetting.Value watchdog = new ModeSetting.Value(mode, "Watchdog");
    private final ModeSetting.Value grim = new ModeSetting.Value(mode, "Grim");
    private final ModeSetting.Value vulcan = new ModeSetting.Value(mode, "Vulcan");
    
    private final BooleanSetting render = new BooleanSetting("Render", true);
    private final BooleanSetting tower = new BooleanSetting("Tower", false);
    private final BooleanSetting safeWalk = new BooleanSetting("Safe Walk", true);
    private final BooleanSetting sprint = new BooleanSetting("Sprint", true);
    private final BooleanSetting rotate = new BooleanSetting("Rotate", true);
    private final BooleanSetting silent = new BooleanSetting("Silent", false);
    
    private final NumberSetting delay = new NumberSetting("Delay", 0, 0, 10, 1);
    private final NumberSetting range = new NumberSetting("Range", 4.5f, 1.0f, 6.0f, 0.1f);
    
    // Internal variables
    private int placeDelay = 0;
    private int originalSlot = -1;
    private BlockPos lastPlacePos = null;
    private final List<BlockPos> placedBlocks = new ArrayList<>();
    
    private Scaffold() {
        EventManager.register(this);
    }
    
    @Override
    public void onEnable() {
        placeDelay = 0;
        originalSlot = mc.player.getInventory().selectedSlot;
        placedBlocks.clear();
    }
    
    @Override
    public void onDisable() {
        if (silent.isEnabled() && originalSlot != -1) {
            mc.player.getInventory().selectedSlot = originalSlot;
        }
        placedBlocks.clear();
    }
    
    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        
        if (placeDelay > 0) {
            placeDelay--;
            return;
        }
        
        // Find block to place
        BlockPos placePos = findPlacePosition();
        if (placePos == null) return;
        
        // Find block in hotbar
        int blockSlot = findAnyBlockSlot();
        if (blockSlot == -1) return;
        
        // Apply anticheat bypasses
        applyBypass();
        
        // Place block
        placeBlock(placePos, blockSlot);
        
        // Set delay based on mode
        setPlaceDelay();
    }
    
    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (!render.isEnabled()) return;
        
        // Render placed blocks
        for (BlockPos pos : placedBlocks) {
            Render3DUtil.drawBox(new Box(pos), 0x00FF00, 1.0f);
        }
        
        // Render next placement position
        BlockPos nextPos = findPlacePosition();
        if (nextPos != null) {
            Render3DUtil.drawBox(new Box(nextPos), 0xFF0000, 1.0f);
        }
    }
    
    private BlockPos findPlacePosition() {
        ClientPlayerEntity player = mc.player;
        BlockPos playerPos = player.getBlockPos();
        
        // Check if player is falling
        if (player.getVelocity().y > -0.1) return null;
        
        // Find the block below player
        for (int y = 0; y < 5; y++) {
            BlockPos checkPos = playerPos.down(y);
            if (mc.world.getBlockState(checkPos).isAir()) {
                // Check if there's a solid block below this position
                BlockPos belowPos = checkPos.down();
                if (!mc.world.getBlockState(belowPos).isAir()) {
                    return checkPos;
                }
            }
        }
        
        return null;
    }
    
    private int findAnyBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && canPlaceAsBlock(stack)) {
                return i;
            }
        }
        return -1;
    }
    
    private boolean canPlaceAsBlock(ItemStack stack) {
        if (stack.isEmpty()) return false;
        
        Item item = stack.getItem();
        
        // Exclude tools and weapons
        return !isTool(item) && 
               !isWeapon(item) && 
               !isProjectile(item) && 
               !isConsumable(item) &&
               !isSpecialItem(item);
    }
    
    private boolean isTool(Item item) {
        return item == Items.DIAMOND_PICKAXE || item == Items.NETHERITE_PICKAXE ||
               item == Items.DIAMOND_AXE || item == Items.NETHERITE_AXE ||
               item == Items.DIAMOND_SHOVEL || item == Items.NETHERITE_SHOVEL ||
               item == Items.DIAMOND_HOE || item == Items.NETHERITE_HOE ||
               item == Items.IRON_PICKAXE || item == Items.IRON_AXE ||
               item == Items.IRON_SHOVEL || item == Items.IRON_SWORD ||
               item == Items.IRON_HOE || item == Items.STONE_PICKAXE ||
               item == Items.STONE_AXE || item == Items.STONE_SHOVEL ||
               item == Items.STONE_SWORD || item == Items.STONE_HOE ||
               item == Items.WOODEN_PICKAXE || item == Items.WOODEN_AXE ||
               item == Items.WOODEN_SHOVEL || item == Items.WOODEN_SWORD ||
               item == Items.WOODEN_HOE || item == Items.GOLDEN_PICKAXE ||
               item == Items.GOLDEN_AXE || item == Items.GOLDEN_SHOVEL ||
               item == Items.GOLDEN_SWORD || item == Items.GOLDEN_HOE ||
               item == Items.MACE;
    }
    
    private boolean isWeapon(Item item) {
        return item == Items.DIAMOND_SWORD || item == Items.NETHERITE_SWORD ||
               item == Items.IRON_SWORD || item == Items.STONE_SWORD ||
               item == Items.WOODEN_SWORD || item == Items.GOLDEN_SWORD ||
               item == Items.BOW || item == Items.CROSSBOW ||
               item == Items.TRIDENT || item == Items.SHIELD;
    }
    
    private boolean isProjectile(Item item) {
        return item == Items.ARROW || item == Items.ENDER_PEARL ||
               item == Items.EGG || item == Items.SNOWBALL ||
               item == Items.FIREWORK_ROCKET;
    }
    
    private boolean isConsumable(Item item) {
        return item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE ||
               item == Items.POTION || item == Items.SPLASH_POTION ||
               item == Items.LINGERING_POTION || item == Items.EXPERIENCE_BOTTLE ||
               item == Items.TOTEM_OF_UNDYING;
    }
    
    private boolean isSpecialItem(Item item) {
        return item == Items.ENDER_EYE || item == Items.END_CRYSTAL ||
               item == Items.AMETHYST_SHARD || item == Items.ECHO_SHARD ||
               item == Items.QUARTZ || item == Items.PRISMARINE_SHARD ||
               item == Items.PRISMARINE_CRYSTALS;
    }
    
    private void placeBlock(BlockPos pos, int slot) {
        if (pos == null || slot == -1) return;
        
        // Switch to block slot if not silent
        if (!silent.isEnabled()) {
            mc.player.getInventory().selectedSlot = slot;
        } else {
            originalSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = slot;
        }
        
        // Get placement direction and hit position
        Direction direction = Direction.UP;
        BlockPos offsetPos = pos.offset(direction);
        Vec3d hitPos = pos.toCenterPos();
        
        // Apply rotation if enabled
        if (rotate.isEnabled()) {
            // Simple rotation towards the block
            float yaw = (float) Math.toDegrees(Math.atan2(hitPos.z - mc.player.getZ(), hitPos.x - mc.player.getX())) - 90;
            float pitch = (float) Math.toDegrees(Math.atan2(hitPos.y - mc.player.getY(), 
                Math.sqrt(Math.pow(hitPos.x - mc.player.getX(), 2) + Math.pow(hitPos.z - mc.player.getZ(), 2))));
            
            mc.player.setYaw(yaw);
            mc.player.setPitch(pitch);
        }
        
        // Handle sprint and sneak
        boolean wasSprinting = mc.player.isSprinting();
        boolean wasSneaking = mc.player.isSneaking();
        
        if (sprint.isEnabled() && wasSprinting) {
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        }
        
        if (safeWalk.isEnabled() && !wasSneaking) {
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.PRESS_SHIFT_KEY));
        }
        
        // Create block hit result
        BlockHitResult hitResult = new BlockHitResult(hitPos, direction.getOpposite(), offsetPos, false);
        
        // Place the block
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
        mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
        
        // Restore sprint and sneak
        if (sprint.isEnabled() && wasSprinting) {
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
        }
        
        if (safeWalk.isEnabled() && !wasSneaking) {
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.RELEASE_SHIFT_KEY));
        }
        
        // Restore original slot if silent
        if (silent.isEnabled() && originalSlot != -1) {
            mc.player.getInventory().selectedSlot = originalSlot;
        }
        
        // Add to placed blocks list
        placedBlocks.add(pos);
        lastPlacePos = pos;
        
        // Clean up old placed blocks (keep only last 10)
        if (placedBlocks.size() > 10) {
            placedBlocks.remove(0);
        }
    }
    
    private void applyBypass() {
        switch (mode.get()) {
            case "Watchdog" -> applyWatchdogBypass();
            case "Grim" -> applyGrimBypass();
            case "Vulcan" -> applyVulcanBypass();
            default -> {
                // Normal mode - no special bypass
            }
        }
    }
    
    private void applyWatchdogBypass() {
        // Watchdog bypass: Add small random delays and movement variations
        if (Math.random() < 0.1) {
            placeDelay += (int) (Math.random() * 2);
        }
        
        // Add slight movement variation
        if (MovingUtil.hasPlayerMovement()) {
            Vec3d velocity = mc.player.getVelocity();
            mc.player.setVelocity(velocity.x * 0.98, velocity.y, velocity.z * 0.98);
        }
    }
    
    private void applyGrimBypass() {
        // Grim bypass: Use packet-based placement with timing variations
        if (Math.random() < 0.15) {
            placeDelay += (int) (Math.random() * 3);
        }
        
        // Add packet timing variation
        try {
            Thread.sleep((long) (Math.random() * 2));
        } catch (InterruptedException ignored) {}
    }
    
    private void applyVulcanBypass() {
        // Vulcan bypass: Use different placement patterns and timing
        if (Math.random() < 0.2) {
            placeDelay += (int) (Math.random() * 4);
        }
        
        // Add rotation smoothing
        if (rotate.isEnabled()) {
            float currentYaw = mc.player.getYaw();
            float currentPitch = mc.player.getPitch();
            
            // Smooth rotation changes
            mc.player.setYaw(currentYaw + (float) (Math.random() * 0.1 - 0.05));
            mc.player.setPitch(currentPitch + (float) (Math.random() * 0.1 - 0.05));
        }
    }
    
    private void setPlaceDelay() {
        int baseDelay = (int) delay.getCurrent();
        
        switch (mode.get()) {
            case "Watchdog" -> placeDelay = baseDelay + (int) (Math.random() * 2);
            case "Grim" -> placeDelay = baseDelay + (int) (Math.random() * 3);
            case "Vulcan" -> placeDelay = baseDelay + (int) (Math.random() * 4);
            default -> placeDelay = baseDelay;
        }
    }
    
    // Getters for settings
    public boolean isRenderEnabled() {
        return render.isEnabled();
    }
    
    public boolean isTowerEnabled() {
        return tower.isEnabled();
    }
    
    public boolean isSafeWalkEnabled() {
        return safeWalk.isEnabled();
    }
    
    public boolean isSprintEnabled() {
        return sprint.isEnabled();
    }
    
    public boolean isRotateEnabled() {
        return rotate.isEnabled();
    }
    
    public boolean isSilentEnabled() {
        return silent.isEnabled();
    }
    
    public double getRange() {
        return range.getCurrent();
    }
    
    public String getMode() {
        return mode.get();
    }
}
