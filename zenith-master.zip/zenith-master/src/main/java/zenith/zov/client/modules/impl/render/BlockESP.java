package zenith.zov.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.AirBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import zenith.zov.base.events.impl.render.EventRender3D;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ItemSelectSetting;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.math.Timer;
import zenith.zov.utility.render.level.Render3DUtil;

import java.awt.Color;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@ModuleAnnotation(name = "BlockESP", category = Category.RENDER, description = "Highlights blocks and block entities like chests")
public final class BlockESP extends Module {


    private volatile List<BlockPos> blockPos = new ArrayList<>();
    private volatile List<BlockEntity> blockEntityPos = new ArrayList<>();
    private final ItemSelectSetting itemSelectSetting = new ItemSelectSetting("Blocks", new ArrayList<>());
    private ModeSetting mode = new ModeSetting("Mode");
    private ModeSetting.Value onlyUpdate = new ModeSetting.Value(mode,"Update").select();
    private ModeSetting.Value all = new ModeSetting.Value(mode,"Scan");

    private final NumberSetting range = new NumberSetting("Radius", 80, 1, 128, 2,all::isSelected);
    private final NumberSetting time = new NumberSetting("Timer", 4, 0, 100, 5,all::isSelected);

    private final Timer timerUtil = new Timer();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean isStarted = true;

    public static BlockESP INSTANCE = new BlockESP();
    private BlockESP() {
        // Add common blocks to detect
        itemSelectSetting.add(Blocks.DIAMOND_ORE);
        itemSelectSetting.add(Blocks.CHEST);
        itemSelectSetting.add(Blocks.ENDER_CHEST);
        itemSelectSetting.add(Blocks.TRAPPED_CHEST);
        itemSelectSetting.add(Blocks.BARREL);
        itemSelectSetting.add(Blocks.SHULKER_BOX);
        itemSelectSetting.add(Blocks.WHITE_SHULKER_BOX);
        itemSelectSetting.add(Blocks.ORANGE_SHULKER_BOX);
        itemSelectSetting.add(Blocks.MAGENTA_SHULKER_BOX);
        itemSelectSetting.add(Blocks.LIGHT_BLUE_SHULKER_BOX);
        itemSelectSetting.add(Blocks.YELLOW_SHULKER_BOX);
        itemSelectSetting.add(Blocks.LIME_SHULKER_BOX);
        itemSelectSetting.add(Blocks.PINK_SHULKER_BOX);
        itemSelectSetting.add(Blocks.GRAY_SHULKER_BOX);
        itemSelectSetting.add(Blocks.LIGHT_GRAY_SHULKER_BOX);
        itemSelectSetting.add(Blocks.CYAN_SHULKER_BOX);
        itemSelectSetting.add(Blocks.PURPLE_SHULKER_BOX);
        itemSelectSetting.add(Blocks.BLUE_SHULKER_BOX);
        itemSelectSetting.add(Blocks.BROWN_SHULKER_BOX);
        itemSelectSetting.add(Blocks.GREEN_SHULKER_BOX);
        itemSelectSetting.add(Blocks.RED_SHULKER_BOX);
        itemSelectSetting.add(Blocks.BLACK_SHULKER_BOX);
    }
    @Override
    public void onEnable() {

        timerUtil.setMillis(0);
        isStarted = true;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        isStarted = false;
        super.onDisable();
    }

    @EventTarget
    public void render(EventRender3D eventRender3D) {

        if (timerUtil.finished(time.getCurrent() * 1000) && !onlyUpdate.isSelected() && isStarted) {
            executor.submit(this::scan);
            executor.submit(this::scanBlockEntities);
            timerUtil.reset();
        }

        // Render blocks
        for (BlockPos pos : blockPos) {
            Block block = mc.world.getBlockState(pos).getBlock();

            if (itemSelectSetting.contains(block)) {
                if ((block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE)) {
                    drawBox(pos, Color.cyan.getRGB());
                } else if ((block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE)) {
                    drawBox(pos, 0xFFFFD700);
                } else if (block == Blocks.NETHER_GOLD_ORE) {
                    drawBox(pos, 0xFFFFD700);
                } else if ((block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE)) {
                    drawBox(pos, 0xFF00FF4D);
                } else if ((block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE)) {
                    drawBox(pos, 0xFFD5D5D5);
                } else if ((block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE)) {
                    drawBox(pos, 0xFFFF0000);
                } else if (block == Blocks.ANCIENT_DEBRIS) {
                    drawBox(pos, 0xFFFFFFFF);
                } else if (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST) {
                    drawBox(pos, 0xFF8B4513); // Brown for chests
                } else if (block == Blocks.ENDER_CHEST) {
                    drawBox(pos, 0xFF4B0082); // Indigo for ender chests
                } else if (block == Blocks.BARREL) {
                    drawBox(pos, 0xFF8B4513); // Brown for barrels
                } else if (block.toString().contains("SHULKER_BOX")) {
                    drawBox(pos, 0xFF9370DB); // Purple for shulker boxes
                } else {
                    MapColor color = block.getDefaultMapColor();
                    int rgb = new Color(color.color).getRGB();
                    drawBox(pos, rgb);
                }
            }
        }

        // Render block entities
        for (BlockEntity blockEntity : blockEntityPos) {
            BlockPos pos = blockEntity.getPos();
            Block block = mc.world.getBlockState(pos).getBlock();
            
            // Only render if the block is in our selection
            if (itemSelectSetting.contains(block)) {
                int color = getBlockEntityColor(block);
                drawBox(pos, color);
            }
        }
    }

    @EventTarget
    public void packer(EventPacket eventPacket) {
        if (eventPacket.isReceive()) {
            if (eventPacket.getPacket() instanceof ChunkDeltaUpdateS2CPacket chunkDelta)
                chunkDelta.visitUpdates((pos, state) -> {
                    if(itemSelectSetting.contains(state.getBlock())) {
                        blockPos.add(pos);
                    }
                });
            if (eventPacket.getPacket() instanceof BlockUpdateS2CPacket chunkDelta) {
                if (itemSelectSetting.contains(chunkDelta.getState ().getBlock())){
                    blockPos.add(chunkDelta.getPos());
                }
            }
        }
    }


    public void drawBox(BlockPos blockPos, int start) {
        Render3DUtil.drawBox(new Box(blockPos), start, 1);
    }

    private int getBlockEntityColor(Block block) {
        if (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST) {
            return 0xFF8B4513; // Brown for chests
        } else if (block == Blocks.ENDER_CHEST) {
            return 0xFF4B0082; // Indigo for ender chests
        } else if (block == Blocks.BARREL) {
            return 0xFF8B4513; // Brown for barrels
        } else if (block.toString().contains("SHULKER_BOX")) {
            return 0xFF9370DB; // Purple for shulker boxes
        } else if (block == Blocks.FURNACE || block == Blocks.BLAST_FURNACE || block == Blocks.SMOKER) {
            return 0xFF696969; // Dim gray for furnaces
        }
        return 0xFFFFFFFF; // White for other block entities
    }


    private void scan() {

        ArrayList<BlockPos> blocks = new ArrayList<>();
        int startX = (int) Math.floor(mc.player.getX() - range.getCurrent());
        int endX = (int) Math.ceil(mc.player.getX() + range.getCurrent());
        int startY = mc.world.getBottomY() + 1;
        int endY = mc.world.getTopYInclusive();
        int startZ = (int) Math.floor(mc.player.getZ() - range.getCurrent());
        int endZ = (int) Math.ceil(mc.player.getZ() + range.getCurrent());

        for (int x = startX; x <= endX; x++) {

            for (int y = startY; y <= endY; y++) {

                for (int z = startZ; z <= endZ; z++) {
                    if (!isStarted) return;
                    BlockPos pos = new BlockPos(x, y, z);
                    Block block = mc.world.getBlockState(pos).getBlock();

                    if (!(block instanceof AirBlock) && itemSelectSetting.contains(block)) {
                        blocks.add(pos);
                    }


                }
            }
        }
        this.blockPos = blocks;
        isStarted = true;
    }

    private void scanBlockEntities() {
        if (mc.world == null || mc.player == null) return;
        
        ArrayList<BlockEntity> blockEntities = new ArrayList<>();
        double range = this.range.getCurrent();
        
        // Iterate through chunks to find block entities
        int startX = (int) Math.floor(mc.player.getX() - range) >> 4;
        int endX = (int) Math.ceil(mc.player.getX() + range) >> 4;
        int startZ = (int) Math.floor(mc.player.getZ() - range) >> 4;
        int endZ = (int) Math.ceil(mc.player.getZ() + range) >> 4;
        
        for (int chunkX = startX; chunkX <= endX; chunkX++) {
            for (int chunkZ = startZ; chunkZ <= endZ; chunkZ++) {
                if (!isStarted) return;
                
                var chunk = mc.world.getChunk(chunkX, chunkZ);
                if (chunk != null) {
                    for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
                        if (!isStarted) return;
                        
                        // Check if block entity is within range
                        BlockPos blockPos = blockEntity.getPos();
                        Vec3d blockCenter = new Vec3d(blockPos.getX() + 0.5, blockPos.getY() + 0.5, blockPos.getZ() + 0.5);
                        double distance = mc.player.getPos().distanceTo(blockCenter);
                        if (distance <= range) {
                            // Check if this block entity's block type is in our selection
                            Block block = mc.world.getBlockState(blockPos).getBlock();
                            if (itemSelectSetting.contains(block)) {
                                blockEntities.add(blockEntity);
                            }
                        }
                    }
                }
            }
        }
        
        this.blockEntityPos = blockEntities;
    }

}
