package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.input.EventMouse;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "WindHop", description = "Use wind charges to boost yourself up by throwing them at the ground", category = Category.MOVEMENT)
public class WindHop extends Module {
    
    private final BooleanSetting autoLookDown = new BooleanSetting("Auto Look Down", true);
    private final BooleanSetting autoThrow = new BooleanSetting("Auto Throw", true);
    private final NumberSetting lookDownAngle = new NumberSetting("Look Down Angle", 80, 0, 90, 1);
    private final BooleanSetting silent = new BooleanSetting("Silent", false);
    private final BooleanSetting noRotate = new BooleanSetting("No Rotate", false);
    
    private boolean isActivated = false;
    private int windChargeSlot = -1;
    private int originalSlot = -1;

    public WindHop() {
        EventManager.register(this);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        
        // Handle wind hop when module is enabled
        if (isEnabled()) {
            if (!isActivated) {
                activateWindHop();
            }
            handleWindHop();
        } else {
            // Return to original slot when disabling
            if (isActivated && silent.isEnabled() && originalSlot != -1) {
                mc.player.getInventory().setSelectedSlot(originalSlot);
            }
            isActivated = false;
        }
    }
    
    
    private void activateWindHop() {
        // Find wind charge in inventory
        windChargeSlot = findWindChargeSlot();
        if (windChargeSlot == -1) {
            return; // Always require wind charge
        }
        
        isActivated = true;
        
        // Save original slot if silent mode
        if (silent.isEnabled()) {
            originalSlot = mc.player.getInventory().selectedSlot;
        } else {
            // Switch to wind charge slot only if not silent
            mc.player.getInventory().setSelectedSlot(windChargeSlot);
        }
    }
    
    private void handleWindHop() {
        // Auto look down
        if (autoLookDown.isEnabled() && !noRotate.isEnabled()) {
            mc.player.setPitch(lookDownAngle.getCurrent());
        }
        
        // Auto throw wind charge
        if (autoThrow.isEnabled()) {
            throwWindChargeAtGround();
        }
    }
    
    private void throwWindChargeAtGround() {
        BlockPos targetBlock;
        
        if (noRotate.isEnabled()) {
            // Find the block directly below the player
            BlockPos playerPos = mc.player.getBlockPos();
            targetBlock = findGroundBelow(playerPos);
        } else {
            // Use current rotation
            HitResult hitResult = mc.player.raycast(10.0, 0.0f, true);
            if (hitResult.getType() == HitResult.Type.BLOCK) {
                targetBlock = ((BlockHitResult) hitResult).getBlockPos();
            } else {
                return; // No block found
            }
        }
        
        if (targetBlock != null) {
            // Switch to wind charge slot if silent mode
            if (silent.isEnabled()) {
                mc.player.getInventory().setSelectedSlot(windChargeSlot);
            }
            
            // Use wind charge
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            
            // Swing hand (unless silent)
            if (!silent.isEnabled()) {
                mc.player.swingHand(Hand.MAIN_HAND);
            }
            
            // Return to original slot if silent mode
            if (silent.isEnabled() && originalSlot != -1) {
                mc.player.getInventory().setSelectedSlot(originalSlot);
            }
        }
    }
    
    private BlockPos findGroundBelow(BlockPos startPos) {
        // Look for a solid block below the player
        for (int y = startPos.getY() - 1; y >= startPos.getY() - 10; y--) {
            BlockPos checkPos = new BlockPos(startPos.getX(), y, startPos.getZ());
            if (!mc.world.getBlockState(checkPos).isAir()) {
                return checkPos;
            }
        }
        return null; // No ground found
    }
    
    private int findWindChargeSlot() {
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) {
                if (mc.player.getInventory().getStack(i).getItem() == Items.WIND_CHARGE) {
                    return i;
                }
            }
        }
        return -1;
    }
}
