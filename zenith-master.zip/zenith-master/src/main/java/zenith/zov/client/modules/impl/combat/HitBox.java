package zenith.zov.client.modules.impl.combat;

import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.interfaces.IClient;

@ModuleAnnotation(name = "HitBox", category = Category.COMBAT, description = "Expands hitboxes of entities")
public class HitBox extends Module implements IClient {
    
    public static final HitBox INSTANCE = new HitBox();
    
    private final NumberSetting xzExpandSetting = new NumberSetting("XZ Expand", 0.2f, 0.0f, 3.0f, 0.1f, "Allows the box to be extended in the XZ axis");
    private final NumberSetting yExpandSetting = new NumberSetting("Y Expand", 0.0f, 0.0f, 3.0f, 0.1f, "Allows the box to be extended in the Y axis");

    private HitBox() {
        // Constructor - settings are automatically discovered by reflection
    }

    public NumberSetting getXzExpandSetting() {
        return xzExpandSetting;
    }

    public NumberSetting getYExpandSetting() {
        return yExpandSetting;
    }
}
