package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

@ModuleAnnotation(name = "MaceAura", description = "Attack targets with mace only when falling in air", category = Category.COMBAT)
public class MaceAura extends Module {
    
    private final NumberSetting range = new NumberSetting("Range", 4.5f, 1.0f, 6.0f, 0.1f);
    private final NumberSetting fallDistance = new NumberSetting("Min Fall Distance", 1.0f, 0.0f, 10.0f, 0.1f);
    private final NumberSetting attackSpeed = new NumberSetting("Attack Speed", 20, 1, 50, 1);
    private final BooleanSetting targetPlayers = new BooleanSetting("Target Players", true);
    private final BooleanSetting targetMobs = new BooleanSetting("Target Mobs", true);
    private final BooleanSetting requireMace = new BooleanSetting("Require Mace", true);
    private final BooleanSetting autoSwitch = new BooleanSetting("Auto Switch to Mace", true);
    
    private long lastAttackTime = 0;

    public MaceAura() {
        EventManager.register(this);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        
        // Only attack when falling and not on ground
        if (mc.player.isOnGround() || mc.player.fallDistance < fallDistance.getCurrent()) {
            return;
        }
        
        // Check if we have a mace in hand or inventory
        if (requireMace.isEnabled() && !hasMaceInHand() && !hasMaceInInventory()) {
            return;
        }
        
        // Auto switch to mace if needed
        if (autoSwitch.isEnabled() && !hasMaceInHand() && hasMaceInInventory()) {
            switchToMace();
        }
        
        // Attack speed check
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastAttackTime < (1000 / attackSpeed.getCurrent())) {
            return;
        }
        
        // Find target
        Entity target = findTarget();
        if (target == null) return;
        
        // Attack target
        attackTarget(target);
        lastAttackTime = currentTime;
    }
    
    private boolean hasMaceInHand() {
        if (mc.player.getMainHandStack().isEmpty()) return false;
        String itemName = mc.player.getMainHandStack().getItem().toString().toLowerCase();
        return itemName.contains("mace");
    }
    
    private boolean hasMaceInInventory() {
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) {
                String itemName = mc.player.getInventory().getStack(i).getItem().toString().toLowerCase();
                if (itemName.contains("mace")) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private void switchToMace() {
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getStack(i).isEmpty()) {
                String itemName = mc.player.getInventory().getStack(i).getItem().toString().toLowerCase();
                if (itemName.contains("mace")) {
                    mc.player.getInventory().setSelectedSlot(i);
                    break;
                }
            }
        }
    }
    
    private Entity findTarget() {
        Iterable<Entity> entities = mc.world.getEntities();
        Entity closestTarget = null;
        double closestDistance = range.getCurrent();
        
        for (Entity entity : entities) {
            if (entity == mc.player || !entity.isAlive()) continue;
            
            // Check if entity is a valid target
            if (!isValidTarget(entity)) continue;
            
            // Check distance
            double distance = mc.player.distanceTo(entity);
            if (distance > range.getCurrent()) continue;
            
            // Check if target is below player (for mace effectiveness)
            if (entity.getY() >= mc.player.getY()) continue;
            
            if (distance < closestDistance) {
                closestDistance = distance;
                closestTarget = entity;
            }
        }
        
        return closestTarget;
    }
    
    private boolean isValidTarget(Entity entity) {
        if (entity instanceof PlayerEntity) {
            return targetPlayers.isEnabled();
        } else if (entity instanceof MobEntity) {
            return targetMobs.isEnabled();
        }
        return false;
    }
    
    private void attackTarget(Entity target) {
        // Calculate rotation to look at target
        Vec3d targetPos = target.getEyePos();
        Vec3d playerPos = mc.player.getEyePos();
        Vec3d direction = targetPos.subtract(playerPos).normalize();
        
        float yaw = (float) Math.toDegrees(Math.atan2(-direction.x, direction.z));
        float pitch = (float) Math.toDegrees(Math.asin(-direction.y));
        
        // Set player rotation
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
        
        // Attack
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
