package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

@ModuleAnnotation(name = "StunMace", description = "Break shield with axe mid-air, hit with mace, then return to original slot", category = Category.COMBAT)
public class StunMace extends Module {
    
    private final NumberSetting axeSlot = new NumberSetting("Axe Slot", 1, 0, 8, 1);
    private final NumberSetting maceSlot = new NumberSetting("Mace Slot", 2, 0, 8, 1);
    private final NumberSetting fallDistance = new NumberSetting("Fall Distance", 2, 1, 10, 1);
    private final NumberSetting returnSlot = new NumberSetting("Return Slot", 0, 0, 8, 1);
    
    private boolean hasTriggered = false;

    public StunMace() {
        EventManager.register(this);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (mc.player.isOnGround()) {
            hasTriggered = false;
            return;
        }

        if (mc.player.fallDistance < fallDistance.getCurrent() || hasTriggered) return;

        PlayerEntity target = getTarget();
        if (target == null || !target.isAlive()) return;

        hasTriggered = true;

        // Axe hit
        mc.player.getInventory().setSelectedSlot((int) axeSlot.getCurrent());
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);

        // Mace hit
        mc.player.getInventory().setSelectedSlot((int) maceSlot.getCurrent());
        mc.player.setCurrentHand(Hand.MAIN_HAND);
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);

        // Return to original slot
        mc.player.getInventory().setSelectedSlot((int) returnSlot.getCurrent());
    }

    private PlayerEntity getTarget() {
        if (mc.targetedEntity instanceof PlayerEntity target) {
            // Note: You may need to implement friend system check here
            // if (Friends.get().isFriend(target)) return null;
            return target;
        }
        return null;
    }
}
