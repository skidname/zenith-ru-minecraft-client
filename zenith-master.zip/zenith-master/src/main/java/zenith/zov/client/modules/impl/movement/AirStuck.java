package zenith.zov.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import zenith.zov.base.events.impl.player.EventMove;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.utility.interfaces.IClient;
import zenith.zov.utility.game.server.ServerHandler;
import zenith.zov.utility.math.Timer;

@ModuleAnnotation(name = "AirStuck", category = Category.MOVEMENT, description = "Air Stuck")
public class AirStuck extends Module implements IClient {
    
    public static final AirStuck INSTANCE = new AirStuck();
    
    public Vec3d pos, prevPos;
    private World lastWorld;
    
    private final Timer freezeTimer = new Timer();
    private boolean prevReallyWorld = false;
    private boolean prevGliding = false;

    private AirStuck() {
        // Constructor - settings are automatically discovered by reflection
    }

    @Override
    public void onEnable() {
        prevPos = pos = new Vec3d(mc.getEntityRenderDispatcher().camera.getPos().toVector3f());
        lastWorld = mc.player.getWorld();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        lastWorld = null;
        super.onDisable();
    }

    @EventTarget
    public void onMove(EventMove event) {
        boolean isReallyWorld = zenith.getServerHandler().getServer().equals("ReallyWorld");

        if (!isReallyWorld) {
            event.setMovePos(Vec3d.ZERO);
            return;
        }

        boolean isGliding = mc.player.isGliding();
        int freezeTicks = isGliding ? 250 : 10;

        if (freezeTimer.getElapsedTime() < freezeTicks * 50) { // Convert ticks to milliseconds (50ms per tick)
            event.setMovePos(Vec3d.ZERO);
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.world == null || mc.player == null || mc.player.getWorld() != lastWorld) {
            this.setEnabled(false);
            return;
        }

        boolean currReallyWorld = zenith.getServerHandler().getServer().equals("ReallyWorld") || 
                                 zenith.getServerHandler().getServer().equals("FunTime");
        boolean currGliding = mc.player.isGliding();

        if (currReallyWorld != prevReallyWorld || currGliding != prevGliding) {
            freezeTimer.reset();
            prevReallyWorld = currReallyWorld;
            prevGliding = currGliding;
        }

        if (currReallyWorld) {
            int freezeTicks = currGliding ? 250 : 10;
            int resetTicks = currGliding ? 40 : 10;
            if (freezeTimer.getElapsedTime() >= (freezeTicks + resetTicks) * 50) { // Convert ticks to milliseconds
                freezeTimer.reset();
            }
        }
    }
}
