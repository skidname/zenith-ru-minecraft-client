package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;



import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.events.impl.server.EventPacket;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.utility.math.Timer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ModuleAnnotation(name = "AutoDuels", category = Category.MISC,description = "Throws duel on RW")
public final class AutoDuels extends Module {

    public static final AutoDuels INSTANCE = new AutoDuels();
    private AutoDuels() {
    }
    private final ModeSetting mode = new ModeSetting( "Kit");
    private final ModeSetting.Value shield = new ModeSetting.Value(mode, "Shields");
    private final ModeSetting.Value shipi = new ModeSetting.Value(mode, "Thorns");
    private final ModeSetting.Value bow = new ModeSetting.Value(mode, "Bow");
    private final ModeSetting.Value totem = new ModeSetting.Value(mode, "Totems");
    private final ModeSetting.Value noDebuff = new ModeSetting.Value(mode, "NoDebuff");
    private final ModeSetting.Value balls = new ModeSetting.Value(mode, "Balls");
    private final ModeSetting.Value classik = new ModeSetting.Value(mode, "Classic");
    private final ModeSetting.Value cheats = new ModeSetting.Value(mode, "Cheater Paradise");
    private final ModeSetting.Value nezer = new ModeSetting.Value(mode, "Nether");
    {
        mode.setValue(classik);
    }
    private final Timer timer = new Timer();
    private final List<String> sent = new ArrayList<>();

    @EventTarget
    public void onUpdate(EventUpdate event) {
        List<String> playerNames = new ArrayList<>();

        Collections.shuffle(playerNames);

        for (PlayerListEntry entry : mc.player.networkHandler.getPlayerList()) {
            playerNames.add(entry.getProfile().getName());
        }

        for (String name : playerNames) {
            if (timer.finished(750) && !sent.contains(name) && !name.equals(mc.player.getNameForScoreboard())) {
                mc.player.networkHandler.sendChatCommand("duel " + name);
                sent.add(name);
                timer.reset();
            }
        }

        if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
            String title = mc.currentScreen.getTitle().getString();

            if (title.contains("Kit Selection")) {
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, mode.getValues().indexOf(mode.getRandomEnabledElement()), 0, SlotActionType.PICKUP, mc.player);
            } else if (title.contains("Duel Setup")) {
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 0, 0, SlotActionType.PICKUP, mc.player);
            }
        }
    }

    @EventTarget
    public void onReceivePacket(EventPacket event) {
        if(!event.isReceive())return;
        if (event.getPacket() instanceof GameMessageS2CPacket packet) {
            String msg = packet.content().getString();

            if (msg.contains("Accepted") && !msg.contains("not accepted")) {
                sent.clear();
                this.toggle();
            }
            
            if (msg.contains("duel") && (msg.contains("found") || msg.contains("started") || msg.contains("start"))) {
                sent.clear();
                this.toggle();
            }
            
            if (msg.contains("won") || msg.contains("lost") || msg.contains("draw")) {
                sent.clear();
                this.toggle();
            }

            if (msg.contains("Balance") || msg.contains("disabled requests")) {
                event.cancel();
            }
        }
    }

    @Override
    public void onEnable() {
        if(mc.player==null){
            this.setEnabled(false);
            return;
        }
        timer.reset();
        super.onEnable();
    }
}
