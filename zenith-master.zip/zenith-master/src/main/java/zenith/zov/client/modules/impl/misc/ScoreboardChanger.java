package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

@ModuleAnnotation(name = "ScoreboardChanger", description = "Modify scoreboard display", category = Category.MISC)
public class ScoreboardChanger extends Module {
    
    public static final ScoreboardChanger INSTANCE = new ScoreboardChanger();
    
    private final BooleanSetting hideScoreboard = new BooleanSetting("Hide Scoreboard", false);
    private final BooleanSetting customTitle = new BooleanSetting("Custom Title", false);
    private final BooleanSetting customScores = new BooleanSetting("Custom Scores", false);
    private final BooleanSetting usePluginConfig = new BooleanSetting("Use Plugin Config", true);
    private final NumberSetting maxScores = new NumberSetting("Max Scores", 7, 1, 15, 1);
    
    // Plugin config values (loaded from file)
    private String titleText = "Example5HP";
    private String moneyValue = "0";
    private String shardsValue = "0";
    private String killsValue = "0";
    private String deathsValue = "0";
    private String keyallValue = "59m 56s";
    private String playtimeValue = "5s";
    private String teamInfo = "Europe (25)";
    
    // Resource asset paths for config files
    private final String[] resourcePaths = {
        "config/scoreboard.yml",
        "assets/zenith/config/scoreboard.yml",
        "assets/zenith/scoreboard.yml"
    };
    
    // Config file paths (common scoreboard plugin locations) - fallback
    private final String[] configPaths = {
        "plugins/TAB/config.yml",
        "config/scoreboard.yml",
        "plugins/Scoreboard/config.yml",
        "plugins/AnimatedScoreboard/config.yml",
        "plugins/SimpleScoreboard/config.yml",
        "plugins/ScoreboardPlus/config.yml"
    };
    
    private Scoreboard originalScoreboard = null;
    private ScoreboardObjective originalObjective = null;

    public ScoreboardChanger() {
        EventManager.register(this);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        
        if (isEnabled()) {
            // Load config values if using plugin config
            if (usePluginConfig.isEnabled()) {
                loadPluginConfig();
            }
            
            if (hideScoreboard.isEnabled()) {
                hideScoreboard();
            } else if (customTitle.isEnabled() || customScores.isEnabled()) {
                modifyScoreboard();
            }
        } else {
            restoreScoreboard();
        }
    }
    
    private void hideScoreboard() {
        // The actual hiding is handled by the InGameHudMixin
        // This method is called to trigger the hiding logic
    }
    
    public boolean isHideScoreboard() {
        return hideScoreboard.isEnabled();
    }
    
    public boolean isCustomTitle() {
        return customTitle.isEnabled();
    }
    
    public boolean isCustomScores() {
        return customScores.isEnabled();
    }
    
    public String getTitleText() {
        return titleText;
    }
    
    public String getMoneyValue() {
        return moneyValue;
    }
    
    public String getShardsValue() {
        return shardsValue;
    }
    
    public String getKillsValue() {
        return killsValue;
    }
    
    public String getDeathsValue() {
        return deathsValue;
    }
    
    public String getKeyallValue() {
        return keyallValue;
    }
    
    public String getPlaytimeValue() {
        return playtimeValue;
    }
    
    public String getTeamInfo() {
        return teamInfo;
    }
    
    private void modifyScoreboard() {
        if (mc.world == null || mc.world.getScoreboard() == null) return;
        
        Scoreboard scoreboard = mc.world.getScoreboard();
        ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        
        if (objective == null) return;
        
        // Store original if not already stored
        if (originalScoreboard == null) {
            originalScoreboard = scoreboard;
            originalObjective = objective;
        }
        
        if (customTitle.isEnabled()) {
            // Custom title would be applied through mixins
            // For now, we just ensure the config is loaded
            loadPluginConfig();
        }
        
        if (customScores.isEnabled()) {
            // Custom scores would be applied through mixins
            // For now, we just ensure the config is loaded
            loadPluginConfig();
        }
    }
    
    private void restoreScoreboard() {
        // Reset to original state
        originalScoreboard = null;
        originalObjective = null;
    }
    
    private void loadPluginConfig() {
        // First try to load from resource assets
        if (loadFromResources()) {
            return;
        }
        
        // Fallback to file system
        for (String configPath : configPaths) {
            Path path = Paths.get(configPath);
            if (Files.exists(path)) {
                loadConfigFile(path);
                break;
            }
        }
    }
    
    private boolean loadFromResources() {
        if (mc.getResourceManager() == null) {
            return false;
        }
        
        for (String resourcePath : resourcePaths) {
            try {
                Identifier identifier = Identifier.of("zenith", resourcePath);
                Resource resource = mc.getResourceManager().getResource(identifier).orElse(null);
                
                if (resource != null) {
                    try (InputStream inputStream = resource.getInputStream()) {
                        loadConfigFromStream(inputStream, resourcePath);
                        return true;
                    }
                }
            } catch (Exception e) {
                // Try next resource path
                continue;
            }
        }
        
        return false;
    }
    
    private void loadConfigFromStream(InputStream inputStream, String resourcePath) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            parseConfigLines(lines, resourcePath);
        } catch (IOException e) {
            // Failed to load config from resource
        }
    }
    
    private void loadConfigFile(Path configPath) {
        try {
            List<String> lines = Files.readAllLines(configPath);
            parseConfigLines(lines, configPath.toString());
        } catch (IOException e) {
            // Failed to load config file
        }
    }
    
    private void parseConfigLines(List<String> lines, String source) {
        boolean inScoreboardSection = false;
        boolean inLinesSection = false;
        int lineIndex = 0;
        
        for (String line : lines) {
            line = line.trim();
            
            // Skip comments and empty lines
            if (line.startsWith("#") || line.isEmpty()) continue;
            
            // Check if we're in the scoreboard section
            if (line.equals("scoreboard:")) {
                inScoreboardSection = true;
                continue;
            }
            
            // Check if we're in the lines section
            if (inScoreboardSection && line.equals("lines:")) {
                inLinesSection = true;
                lineIndex = 0;
                continue;
            }
            
            // Reset if we leave scoreboard section
            if (inScoreboardSection && !line.startsWith(" ") && !line.startsWith("-") && line.contains(":")) {
                inScoreboardSection = false;
                inLinesSection = false;
            }
            
            // Parse scoreboard lines
            if (inLinesSection && line.startsWith("- ")) {
                String value = line.substring(2).trim();
                
                switch (lineIndex) {
                    case 0: // Empty line
                        break;
                    case 1: // Money line
                        if (value.contains("Money")) {
                            // Extract placeholder value
                            if (value.contains("%coinsengine_balance_short_money%")) {
                                moneyValue = "0"; // Default value
                            }
                        }
                        break;
                    case 2: // Shards line
                        if (value.contains("Shards")) {
                            if (value.contains("%coinsengine_balance_short_shards%")) {
                                shardsValue = "0";
                            }
                        }
                        break;
                    case 3: // Kills line
                        if (value.contains("Kills")) {
                            if (value.contains("%skstatistics_kills%")) {
                                killsValue = "0";
                            }
                        }
                        break;
                    case 4: // Deaths line
                        if (value.contains("Deaths")) {
                            if (value.contains("%skstatistics_deaths%")) {
                                deathsValue = "0";
                            }
                        }
                        break;
                    case 5: // Keyall line
                        if (value.contains("Keyall")) {
                            if (value.contains("%zschedulers_time_keyall%")) {
                                keyallValue = "59m 56s";
                            }
                        }
                        break;
                    case 6: // Playtime line
                        if (value.contains("Playtime")) {
                            if (value.contains("%playtime_timed%")) {
                                playtimeValue = "5s";
                            }
                        }
                        break;
                    case 7: // Team line (if in team)
                        if (value.contains("Team")) {
                            if (value.contains("%skteams_name%")) {
                                teamInfo = "Europe (25)";
                            }
                        }
                        break;
                    case 8: // Empty line
                        break;
                    case 9: // Ping line
                        if (value.contains("Europe")) {
                            if (value.contains("%ping%")) {
                                teamInfo = "Europe (25)";
                            }
                        }
                        break;
                }
                lineIndex++;
            }
            
            // Parse title
            if (inScoreboardSection && line.startsWith("title:")) {
                String value = line.substring(6).trim().replace("'", "").replace("\"", "");
                titleText = value;
            }
        }
        
        // Config loaded successfully
    }
    
    private void savePluginConfig() {
        // Save modified values back to config file
        for (String configPath : configPaths) {
            Path path = Paths.get(configPath);
            if (Files.exists(path)) {
                saveConfigFile(path);
                break;
            }
        }
    }
    
    private void saveConfigFile(Path configPath) {
        try {
            List<String> lines = Files.readAllLines(configPath);
            List<String> newLines = new ArrayList<>();
            
            for (String line : lines) {
                String newLine = line;
                
                // Update config values
                if (line.contains(":")) {
                    String[] parts = line.split(":", 2);
                    if (parts.length == 2) {
                        String key = parts[0].trim();
                        
                        switch (key.toLowerCase()) {
                            case "title":
                            case "scoreboard.title":
                                newLine = key + ": \"" + titleText + "\"";
                                break;
                            case "money":
                            case "scoreboard.money":
                                newLine = key + ": \"" + moneyValue + "\"";
                                break;
                            case "shards":
                            case "scoreboard.shards":
                                newLine = key + ": \"" + shardsValue + "\"";
                                break;
                            case "kills":
                            case "scoreboard.kills":
                                newLine = key + ": \"" + killsValue + "\"";
                                break;
                            case "deaths":
                            case "scoreboard.deaths":
                                newLine = key + ": \"" + deathsValue + "\"";
                                break;
                            case "keyall":
                            case "scoreboard.keyall":
                                newLine = key + ": \"" + keyallValue + "\"";
                                break;
                            case "playtime":
                            case "scoreboard.playtime":
                                newLine = key + ": \"" + playtimeValue + "\"";
                                break;
                            case "team":
                            case "scoreboard.team":
                                newLine = key + ": \"" + teamInfo + "\"";
                                break;
                        }
                    }
                }
                
                newLines.add(newLine);
            }
            
            Files.write(configPath, newLines);
            
        } catch (IOException e) {
            // Failed to save config file
        }
    }
}
