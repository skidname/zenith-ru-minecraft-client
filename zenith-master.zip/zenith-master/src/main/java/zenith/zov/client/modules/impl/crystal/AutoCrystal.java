package zenith.zov.client.modules.impl.crystal;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.interfaces.IMinecraft;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Direction;
import org.lwjgl.glfw.GLFW;


@ModuleAnnotation(name = "AutoCrystal", category = Category.CRYSTAL, description = "Automatically crystals fast for you")
public final class AutoCrystal extends Module implements IMinecraft {
    public static final AutoCrystal INSTANCE = new AutoCrystal();

    private final NumberSetting placeDelay = new NumberSetting("Place Delay", 0, 0, 20, 1);
    private final NumberSetting breakDelay = new NumberSetting("Break Delay", 0, 0, 20, 1);
    private final BooleanSetting stopOnKill = new BooleanSetting("Stop on Kill", false);
    private final BooleanSetting damageTick = new BooleanSetting("Damage Tick", false);
    private final BooleanSetting antiWeakness = new BooleanSetting("Anti-Weakness", false);

    private int placeClock;
    private int breakClock;
    public boolean crystalling;

    private AutoCrystal() {
    }

    @Override
    public void onEnable() {
        placeClock = 0;
        breakClock = 0;
        crystalling = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.currentScreen != null) return;

        boolean dontPlace = (placeClock != 0);
        boolean dontBreak = (breakClock != 0);

        if (stopOnKill.isEnabled() && isDeadBodyNearby()) return;

        if (dontPlace) placeClock--;
        if (dontBreak) breakClock--;

        if (mc.player.isUsingItem()) return;

        if (damageTick.isEnabled() && damageTickCheck()) return;

        // Check if right mouse button is pressed
        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) != GLFW.GLFW_PRESS) {
            placeClock = 0;
            breakClock = 0;
            crystalling = false;
            return;
        } else {
            crystalling = true;
        }

        if (!mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) return;

        if (mc.crosshairTarget instanceof BlockHitResult hit) {
            if (mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
                handleBlockHit(hit, dontPlace, dontBreak);
            }

            if (mc.crosshairTarget.getType() == HitResult.Type.MISS) {
                handleMissHit(dontPlace, dontBreak);
            }
        }

        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            handleEntityHit(hit, dontBreak);
        }
    }

    private void handleBlockHit(BlockHitResult hit, boolean dontPlace, boolean dontBreak) {
        if (!dontPlace) {
            if (isObsidianOrBedrock(hit.getBlockPos()) && canPlaceCrystal(hit.getBlockPos())) {
                placeBlock(hit);
                placeClock = (int) placeDelay.getCurrent();
            }
        }
        // Removed the block breaking logic that was causing floor breaking
    }

    private void handleMissHit(boolean dontPlace, boolean dontBreak) {
        // Removed unnecessary block breaking logic
    }

    private void handleEntityHit(EntityHitResult hit, boolean dontBreak) {
        if (!dontBreak) {
            Entity entity = hit.getEntity();

            int previousSlot = mc.player.getInventory().selectedSlot;

            if (entity instanceof EndCrystalEntity || entity instanceof SlimeEntity) {
                if (antiWeakness.isEnabled() && cantBreakCrystal()) {
                    selectSword();
                }
            }

            attackEntity(entity);
            breakClock = (int) breakDelay.getCurrent();

            if (antiWeakness.isEnabled()) {
                mc.player.getInventory().selectedSlot = previousSlot;
            }
        }
    }

    private boolean isDeadBodyNearby() {
        if (mc.world == null || mc.player == null) return false;
        
        // Check for dead players within a certain radius
        double radius = 10.0; // 10 block radius
        return mc.world.getPlayers().stream()
                .filter(player -> player != mc.player)
                .filter(player -> player.isDead() || player.getHealth() <= 0)
                .anyMatch(player -> mc.player.squaredDistanceTo(player) <= radius * radius);
    }

    private boolean isObsidianOrBedrock(net.minecraft.util.math.BlockPos pos) {
        return mc.world.getBlockState(pos).getBlock() == Blocks.OBSIDIAN || 
               mc.world.getBlockState(pos).getBlock() == Blocks.BEDROCK;
    }

    private boolean canPlaceCrystal(net.minecraft.util.math.BlockPos pos) {
        if (mc.world == null) return false;
        
        // Check if there's space above the block for a crystal
        net.minecraft.util.math.BlockPos crystalPos = pos.up();
        
        // Check if the space above is air
        if (!mc.world.getBlockState(crystalPos).isAir()) return false;
        
        // Check if there's space above that too (crystal needs 2 blocks of height)
        if (!mc.world.getBlockState(crystalPos.up()).isAir()) return false;
        
        // Check if there are no entities in the way
        return mc.world.getEntitiesByClass(net.minecraft.entity.Entity.class, 
                new net.minecraft.util.math.Box(crystalPos), 
                entity -> !entity.isSpectator()).isEmpty();
    }

    private void placeBlock(BlockHitResult hit) {
        if (mc.interactionManager != null) {
            mc.interactionManager.interactBlock(mc.player, mc.player.getActiveHand(), hit);
        }
    }


    private void attackEntity(Entity entity) {
        if (mc.interactionManager != null) {
            mc.interactionManager.attackEntity(mc.player, entity);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private void selectSword() {
        // Find a sword in the hotbar
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem().toString().contains("sword")) {
                mc.player.getInventory().selectedSlot = i;
                break;
            }
        }
    }

    private boolean cantBreakCrystal() {
        if (mc.player == null) return false;
        
        StatusEffectInstance weakness = mc.player.getStatusEffect(StatusEffects.WEAKNESS);
        StatusEffectInstance strength = mc.player.getStatusEffect(StatusEffects.STRENGTH);
        
        return !(weakness == null || 
                (strength != null && strength.getAmplifier() > weakness.getAmplifier()) || 
                isTool(mc.player.getMainHandStack()));
    }

    private boolean isTool(net.minecraft.item.ItemStack stack) {
        // Check if the item is a tool (sword, axe, etc.)
        return stack.getItem().toString().contains("sword") || 
               stack.getItem().toString().contains("axe") ||
               stack.getItem().toString().contains("pickaxe");
    }

    private boolean damageTickCheck() {
        return mc.world.getPlayers().parallelStream()
                .filter(e -> e != mc.player)
                .filter(e -> e.squaredDistanceTo(mc.player) < 36)
                .filter(e -> e.getLastAttacker() == null)
                .filter(e -> !e.isOnGround())
                .anyMatch(e -> e.hurtTime >= 2)
                && !(mc.player.getAttacking() instanceof PlayerEntity);
    }
}
