package zenith.zov.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventAttack;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.ModeSetting;
import zenith.zov.utility.interfaces.IClient;
import zenith.zov.utility.game.player.PlayerIntersectionUtil;
import zenith.zov.utility.math.MathUtil;

@ModuleAnnotation(name = "Criticals", category = Category.COMBAT, description = "Criticals bypass")
public class Criticals extends Module implements IClient {
    
    public static final Criticals INSTANCE = new Criticals();
    
    private final ModeSetting mode = new ModeSetting("Mode", "Grim", "Grim");

    private Criticals() {
        // Constructor - settings are automatically discovered by reflection
    }

    @EventTarget
    public void onAttack(EventAttack event) {
        if (mc.player.isTouchingWater()) return;
        if (mode.get().equals("Grim")) {
            if (!mc.player.isOnGround() && mc.player.fallDistance == 0) {
                // Grim bypass - set a small fall distance to trigger critical hit
                mc.player.fallDistance = (float) MathUtil.getRandom(1e-5f, 1e-4f);
            }
        }
    }
}
