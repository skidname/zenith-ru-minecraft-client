package zenith.zov.client.modules.impl.crystal;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.client.modules.api.setting.impl.ToolSelectSetting;
import zenith.zov.utility.interfaces.IMinecraft;
import zenith.zov.Zenith;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;

@ModuleAnnotation(name = "AutoHitCrystal", category = Category.CRYSTAL, description = "Automatically hit-crystals for you")
public final class AutoHitCrystal extends Module implements IMinecraft {
    public static final AutoHitCrystal INSTANCE = new AutoHitCrystal();

    private final BooleanSetting checkPlace = new BooleanSetting("Check Place", false);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0, 0, 20, 1);
    private final NumberSetting placeDelay = new NumberSetting("Place Delay", 0, 0, 20, 1);
    private final ToolSelectSetting workWith = new ToolSelectSetting("Work With", new ArrayList<>());
    private final BooleanSetting swordSwap = new BooleanSetting("Sword Swap", true);

    private int placeClock = 0;
    private int switchClock = 0;
    private boolean active;
    private boolean crystalling;
    private boolean crystalSelected;

    private AutoHitCrystal() {
        // Add some default tools and useful items
        workWith.add(Items.DIAMOND_SWORD);
        workWith.add(Items.NETHERITE_SWORD);
        workWith.add(Items.IRON_SWORD);
        workWith.add(Items.DIAMOND_AXE);
        workWith.add(Items.NETHERITE_AXE);
        workWith.add(Items.MACE);
        workWith.add(Items.TOTEM_OF_UNDYING);
        workWith.add(Items.GOLDEN_APPLE);
        workWith.add(Items.ENCHANTED_GOLDEN_APPLE);
        workWith.add(Items.ENDER_PEARL);
        workWith.add(Items.SHIELD);
        workWith.add(Items.END_CRYSTAL);
        workWith.add(Items.AMETHYST_SHARD);
        workWith.add(Items.ECHO_SHARD);
        workWith.add(Items.QUARTZ);
    }

    @Override
    public void onEnable() {
        reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.currentScreen != null) return;

        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) {
            if (mc.crosshairTarget instanceof BlockHitResult hitResult && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
                if (!active && !canPlaceBlockClient(hitResult.getBlockPos()) && checkPlace.isEnabled()) {
                    return;
                }
            }

            ItemStack mainHandStack = mc.player.getMainHandStack();

            if (!isValidItem(mainHandStack) && !active) {
                return;
            } else if (mc.crosshairTarget instanceof BlockHitResult hitResult && !active) {
                if (swordSwap.isEnabled()) {
                    if (mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
                        Block block = mc.world.getBlockState(hitResult.getBlockPos()).getBlock();
                        crystalling = block == Blocks.OBSIDIAN || block == Blocks.BEDROCK;
                    }
                }
            }

            active = true;

            if (!crystalling) {
                handleObsidianPlacement();
            }

            if (crystalling) {
                handleCrystalBreaking();
            }
        } else {
            reset();
        }
    }

    private boolean isValidItem(ItemStack stack) {
        return stack.getItem() instanceof SwordItem || 
               workWith.contains(stack.getItem());
    }

    private void handleObsidianPlacement() {
        if (mc.crosshairTarget instanceof BlockHitResult hit) {
            if (hit.getType() == HitResult.Type.MISS) return;

            if (!isObsidian(hit.getBlockPos())) {
                if (isChargedAnchor(hit.getBlockPos())) return;

                mc.options.useKey.setPressed(false);

                if (!mc.player.isHolding(Items.OBSIDIAN)) {
                    if (switchClock > 0) {
                        switchClock--;
                        return;
                    }

                    switchClock = (int) switchDelay.getCurrent();
                    selectItemFromHotbar(Items.OBSIDIAN);
                }

                if (mc.player.isHolding(Items.OBSIDIAN)) {
                    if (placeClock > 0) {
                        placeClock--;
                        return;
                    }

                    placeBlock(hit);
                    placeClock = (int) placeDelay.getCurrent();
                    crystalling = true;
                }
            }
        }
    }

    private void handleCrystalBreaking() {
        if (!mc.player.isHolding(Items.END_CRYSTAL) && !crystalSelected) {
            if (switchClock > 0) {
                switchClock--;
                return;
            }

            crystalSelected = selectItemFromHotbar(Items.END_CRYSTAL);
            switchClock = (int) switchDelay.getCurrent();
        }

        if (mc.player.isHolding(Items.END_CRYSTAL)) {
            AutoCrystal autoCrystal = (AutoCrystal) Zenith.getInstance().getModuleManager().getModule("AutoCrystal");
            if (autoCrystal != null && !autoCrystal.isEnabled()) {
                // Trigger AutoCrystal logic
                autoCrystal.onUpdate(new zenith.zov.base.events.impl.player.EventUpdate());
            }
        }
    }

    private boolean canPlaceBlockClient(net.minecraft.util.math.BlockPos pos) {
        if (mc.world == null || mc.player == null) return false;
        
        // Check if the block at the position is replaceable
        return mc.world.getBlockState(pos).isReplaceable();
    }

    private boolean isObsidian(net.minecraft.util.math.BlockPos pos) {
        if (mc.world == null) return false;
        return mc.world.getBlockState(pos).getBlock() == Blocks.OBSIDIAN;
    }

    private boolean isChargedAnchor(net.minecraft.util.math.BlockPos pos) {
        if (mc.world == null) return false;
        
        // Check if it's a respawn anchor and if it has charges
        if (mc.world.getBlockState(pos).getBlock() == Blocks.RESPAWN_ANCHOR) {
            return mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES) > 0;
        }
        return false;
    }

    private boolean selectItemFromHotbar(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) {
                mc.player.getInventory().selectedSlot = i;
                return true;
            }
        }
        return false;
    }

    private void placeBlock(BlockHitResult hit) {
        if (mc.interactionManager != null) {
            mc.interactionManager.interactBlock(mc.player, mc.player.getActiveHand(), hit);
        }
    }

    public void reset() {
        placeClock = (int) placeDelay.getCurrent();
        switchClock = (int) switchDelay.getCurrent();
        active = false;
        crystalling = false;
        crystalSelected = false;
    }
}
