package zenith.zov.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import zenith.zov.base.events.impl.input.EventKey;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.base.request.ScriptManager;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.KeySetting;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.utility.interfaces.IClient;
import zenith.zov.utility.game.player.PlayerIntersectionUtil;
import zenith.zov.utility.game.player.PlayerInventoryUtil;
import zenith.zov.Zenith;

import java.util.List;
import java.util.Objects;

@ModuleAnnotation(name = "ElytraHelper", category = Category.MISC, description = "Elytra Helper")
public class ElytraHelper extends Module implements IClient {
    
    public static final ElytraHelper INSTANCE = new ElytraHelper();
    
    private final KeySetting elytraSetting = new KeySetting("Elytra Swap");
    private final KeySetting fireworkSetting = new KeySetting("Use FireWork");
    private final BooleanSetting startSetting = new BooleanSetting("Quick Start", "When swapping to elytra, it takes off and uses fireworks", false);
    private final ScriptManager.ScriptTask script = new ScriptManager.ScriptTask();

    private ElytraHelper() {
        // Constructor - settings are automatically discovered by reflection
    }

    @EventTarget
    public void onKey(EventKey event) {
        if (!script.isCompleted()) return;

        if (event.getKeyCode() == elytraSetting.getKeyCode() && event.getAction() == 1) { // Key pressed
            Slot slot = chestPlate();
            if (slot != null) {
                Slot fireWork = PlayerInventoryUtil.getSlot(Items.FIREWORK_ROCKET);
                boolean elytra = slot.getStack().getItem().equals(Items.ELYTRA);
                PlayerInventoryUtil.moveItem(slot, 6, true, true);
                if (startSetting.isEnabled() && fireWork != null && elytra) {
                    script.schedule(EventUpdate.class, eventUpdate -> {
                        if (mc.player.isOnGround()) mc.player.jump();
                        return true;
                    }).schedule(EventUpdate.class, eventUpdate -> {
                        PlayerIntersectionUtil.startFallFlying();
                        PlayerInventoryUtil.swapAndUse(Items.FIREWORK_ROCKET);
                        return true;
                    });
                    Zenith.INSTANCE.getScriptManager().addTask(script);
                }
            }
        } else if (event.getKeyCode() == fireworkSetting.getKeyCode() && event.getAction() == 1 && mc.player.isGliding()) {
            PlayerInventoryUtil.swapAndUse(Items.FIREWORK_ROCKET);
        }
    }

    private Slot chestPlate() {
        if (Objects.requireNonNull(mc.player).getEquippedStack(EquipmentSlot.CHEST).getItem().equals(Items.ELYTRA))
            return PlayerInventoryUtil.getSlot(List.of(Items.NETHERITE_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.CHAINMAIL_CHESTPLATE, Items.IRON_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.LEATHER_CHESTPLATE));
        else return PlayerInventoryUtil.getSlot(Items.ELYTRA);
    }
}