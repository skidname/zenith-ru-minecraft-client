package zenith.zov.client.modules.api.setting.impl;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import zenith.zov.client.modules.api.setting.Setting;

import java.lang.reflect.Type;
import java.util.List;
import java.util.function.Supplier;

/**
 * A setting that allows users to select multiple tools from a list.
 * Similar to ItemSelectSetting but specifically designed for tools (ToolItem instances).
 * 
 * Usage example:
 * <pre>
 * // Create a new tool select setting
 * private final ToolSelectSetting toolSelectSetting = new ToolSelectSetting("Tools", new ArrayList<>());
 * 
 * // Add some default tools
 * toolSelectSetting.add(Items.DIAMOND_PICKAXE);
 * toolSelectSetting.add(Items.DIAMOND_AXE);
 * 
 * // Check if a tool is selected
 * if (toolSelectSetting.contains(Items.DIAMOND_PICKAXE)) {
 *     // Tool is selected
 * }
 * 
 * // Get all selected tools
 * List<String> selectedTools = toolSelectSetting.getToolsById();
 * </pre>
 * 
 * The setting automatically filters to only include ToolItem instances and provides
 * a user-friendly interface for selecting multiple tools.
 */
public class ToolSelectSetting extends Setting {
    public void setToolsById(List<String> toolsById) {
        this.toolsById = toolsById;
    }

    private List<String> toolsById;
    
    public ToolSelectSetting(String name, List<String> toolsById) {
        this(name, toolsById, () -> true);
    }
    
    public ToolSelectSetting(String name, List<String> toolsById, Supplier<Boolean> visible) {
        super(name);
        this.toolsById = toolsById;
        setVisible(visible);
    }

    public List<String> getToolsById() {
        return toolsById;
    }

    public void add(String s) {
        if (!toolsById.contains(s)) {
            toolsById.add(s);
        }
    }

    public void remove(String s) {
        toolsById.remove(s);
    }

    public boolean contains(String s) {
        return toolsById.contains(s);
    }

    public void add(Item item) {
        if (isTool(item)) {
            add(item.getTranslationKey().replace("item.minecraft.", ""));
        }
    }

    public void remove(Item item) {
        if (isTool(item)) {
            remove(item.getTranslationKey().replace("item.minecraft.", ""));
        }
    }

    public boolean contains(Item item) {
        if (isTool(item)) {
            return contains(item.getTranslationKey().replace("item.minecraft.", ""));
        }
        return false;
    }
    
    /**
     * Checks if an item is a tool or useful item by comparing it to known items
     */
    private boolean isTool(Item item) {
        return item == Items.DIAMOND_PICKAXE || item == Items.NETHERITE_PICKAXE ||
               item == Items.DIAMOND_AXE || item == Items.NETHERITE_AXE ||
               item == Items.DIAMOND_SHOVEL || item == Items.NETHERITE_SHOVEL ||
               item == Items.DIAMOND_SWORD || item == Items.NETHERITE_SWORD ||
               item == Items.DIAMOND_HOE || item == Items.NETHERITE_HOE ||
               item == Items.IRON_PICKAXE || item == Items.IRON_AXE ||
               item == Items.IRON_SHOVEL || item == Items.IRON_SWORD ||
               item == Items.IRON_HOE || item == Items.STONE_PICKAXE ||
               item == Items.STONE_AXE || item == Items.STONE_SHOVEL ||
               item == Items.STONE_SWORD || item == Items.STONE_HOE ||
               item == Items.WOODEN_PICKAXE || item == Items.WOODEN_AXE ||
               item == Items.WOODEN_SHOVEL || item == Items.WOODEN_SWORD ||
               item == Items.WOODEN_HOE || item == Items.GOLDEN_PICKAXE ||
               item == Items.GOLDEN_AXE || item == Items.GOLDEN_SHOVEL ||
               item == Items.GOLDEN_SWORD || item == Items.GOLDEN_HOE ||
               item == Items.MACE ||
               // Additional useful items
               item == Items.TOTEM_OF_UNDYING ||
               item == Items.GOLDEN_APPLE ||
               item == Items.ENCHANTED_GOLDEN_APPLE ||
               item == Items.ENDER_PEARL ||
               item == Items.ENDER_EYE ||
               item == Items.END_CRYSTAL ||
               item == Items.OBSIDIAN ||
               item == Items.RESPAWN_ANCHOR ||
               item == Items.GLOWSTONE ||
               item == Items.SHIELD ||
               item == Items.BOW ||
               item == Items.CROSSBOW ||
               item == Items.TRIDENT ||
               // Crystal-related items
               item == Items.AMETHYST_SHARD ||
               item == Items.ECHO_SHARD ||
               item == Items.QUARTZ ||
               item == Items.PRISMARINE_SHARD ||
               item == Items.PRISMARINE_CRYSTALS;
    }

    public void clear() {
        toolsById.clear();
    }

    public boolean isEmpty() {
        return toolsById.isEmpty();
    }

    public int size() {
        return toolsById.size();
    }

    private final static Gson gson = new Gson();
    
    @Override
    public void safe(JsonObject propertiesObject) {
        propertiesObject.add(String.valueOf(name), gson.toJsonTree(this.getToolsById()));
    }

    @Override
    public void load(JsonObject propertiesObject) {
        Type listType = new TypeToken<List<String>>() {}.getType();
        JsonElement jsonElement = propertiesObject.get(String.valueOf(name));
        if (jsonElement != null && jsonElement.isJsonArray()) {
            List<String> list = gson.fromJson(jsonElement, listType);
            this.setToolsById(list);
        }
    }
}
