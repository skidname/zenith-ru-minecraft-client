package zenith.zov.client.modules.impl.crystal;

import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.interfaces.IMinecraft;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

@ModuleAnnotation(name = "AnchorMacro", category = Category.CRYSTAL, description = "Automatically blows up respawn anchors for you")
public final class AnchorMacro extends Module implements IMinecraft {
    public static final AnchorMacro INSTANCE = new AnchorMacro();

    private final BooleanSetting whileUse = new BooleanSetting("While Use", true);
    private final BooleanSetting stopOnKill = new BooleanSetting("Stop on Kill", false);
    private final BooleanSetting clickSimulation = new BooleanSetting("Click Simulation", false);
    private final NumberSetting switchDelay = new NumberSetting("Switch Delay", 0, 0, 20, 1);
    private final NumberSetting glowstoneDelay = new NumberSetting("Glowstone Delay", 0, 0, 20, 1);
    private final NumberSetting explodeDelay = new NumberSetting("Explode Delay", 0, 0, 20, 1);
    private final NumberSetting explodeSlot = new NumberSetting("Explode Slot", 1, 1, 9, 1);
    private final BooleanSetting onlyCharge = new BooleanSetting("Only Charge", false);

    private int switchClock = 0;
    private int glowstoneClock = 0;
    private int explodeClock = 0;
    private final Set<BlockPos> ownedAnchors = new HashSet<>();

    private AnchorMacro() {
        // Settings are automatically managed by the module system
    }

    @Override
    public void onEnable() {
        switchClock = 0;
        glowstoneClock = 0;
        explodeClock = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.currentScreen != null) return;

        // Check if using items and whileUse is disabled
        if (!whileUse.isEnabled() && isUsingItem()) {
            return;
        }

        if (stopOnKill.isEnabled() && isDeadBodyNearby()) {
            return;
        }

        if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS) {
            if (mc.crosshairTarget instanceof BlockHitResult hit) {
                if (isRespawnAnchor(hit.getBlockPos())) {
                    mc.options.useKey.setPressed(false);

                    if (isAnchorNotCharged(hit.getBlockPos())) {
                        handleGlowstonePlacement(hit);
                    }

                    if (isAnchorCharged(hit.getBlockPos())) {
                        handleAnchorExplosion(hit);
                    }
                }
            }
        }
    }

    private boolean isUsingItem() {
        return (mc.player.getMainHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD) ||
                mc.player.getMainHandStack().getItem() instanceof ShieldItem ||
                mc.player.getOffHandStack().getItem() instanceof ShieldItem ||
                mc.player.getOffHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD));
    }

    private boolean isDeadBodyNearby() {
        // Placeholder for WorldUtils.isDeadBodyNearby()
        // Implement actual logic to check for dead bodies nearby if needed
        return false;
    }

    private boolean isRespawnAnchor(BlockPos pos) {
        return mc.world.getBlockState(pos).getBlock() == Blocks.RESPAWN_ANCHOR;
    }

    private boolean isAnchorNotCharged(BlockPos pos) {
        return mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES) == 0;
    }

    private boolean isAnchorCharged(BlockPos pos) {
        return mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES) > 0;
    }

    private void handleGlowstonePlacement(BlockHitResult hit) {
        if (!mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
            if (switchClock < switchDelay.getCurrent()) {
                switchClock++;
                return;
            }

            switchClock = 0;
            selectItemFromHotbar(Items.GLOWSTONE);
        }

        if (mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
            if (glowstoneClock < glowstoneDelay.getCurrent()) {
                glowstoneClock++;
                return;
            }

            glowstoneClock = 0;

            if (clickSimulation.isEnabled()) {
                // Simulate mouse click for CPS hud
                // MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
            }

            placeBlock(hit);
        }
    }

    private void handleAnchorExplosion(BlockHitResult hit) {
        int slot = (int) explodeSlot.getCurrent() - 1;

        if (mc.player.getInventory().selectedSlot != slot) {
            if (switchClock < switchDelay.getCurrent()) {
                switchClock++;
                return;
            }

            switchClock = 0;
            mc.player.getInventory().selectedSlot = slot;
        }

        if (mc.player.getInventory().selectedSlot == slot) {
            if (explodeClock < explodeDelay.getCurrent()) {
                explodeClock++;
                return;
            }

            explodeClock = 0;

            if (!onlyCharge.isEnabled()) {
                if (clickSimulation.isEnabled()) {
                    // Simulate mouse click for CPS hud
                    // MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
                }

                placeBlock(hit);
                ownedAnchors.remove(hit.getBlockPos());
            }
        }
    }

    private void selectItemFromHotbar(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) {
                mc.player.getInventory().selectedSlot = i;
                break;
            }
        }
    }

    private void placeBlock(BlockHitResult hit) {
        if (mc.interactionManager != null) {
            mc.interactionManager.interactBlock(mc.player, mc.player.getActiveHand(), hit);
        }
    }

    // Handle item use events to track owned anchors
    @EventTarget
    public void onItemUse(EventUpdate event) {
        if (mc.crosshairTarget instanceof BlockHitResult hitResult && hitResult.getType() == HitResult.Type.BLOCK) {
            if (mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) {
                Direction dir = hitResult.getSide();
                BlockPos pos = hitResult.getBlockPos();

                if (!mc.world.getBlockState(pos).isReplaceable()) {
                    switch (dir) {
                        case UP -> ownedAnchors.add(pos.add(0, 1, 0));
                        case DOWN -> ownedAnchors.add(pos.add(0, -1, 0));
                        case EAST -> ownedAnchors.add(pos.add(1, 0, 0));
                        case WEST -> ownedAnchors.add(pos.add(-1, 0, 0));
                        case NORTH -> ownedAnchors.add(pos.add(0, 0, -1));
                        case SOUTH -> ownedAnchors.add(pos.add(0, 0, 1));
                    }
                } else {
                    ownedAnchors.add(pos);
                }
            }

            BlockPos bp = hitResult.getBlockPos();
            if (isAnchorCharged(bp)) {
                ownedAnchors.remove(bp);
            }
        }
    }
}
