package zenith.zov.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import zenith.zov.base.events.impl.render.EventRender3D;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import zenith.zov.utility.interfaces.IMinecraft;

import java.util.ArrayList;

@ModuleAnnotation(
        name = "HitBubbles",
        category = Category.RENDER,
        description = "Shows visual bubbles when hitting entities"
)
public final class HitBubbles extends Module implements IMinecraft {
    public static final HitBubbles INSTANCE = new HitBubbles();

    private final NumberSetting lifeTime = new NumberSetting("LifeTime", 30, 1, 150, 1);

    private final ArrayList<HitBubble> bubbles = new ArrayList<>();

    private HitBubbles() {
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.player == null || mc.world == null) return;

        RenderSystem.disableDepthTest();
        ArrayList<HitBubble> bubblesCopy = Lists.newArrayList(bubbles);
        
        bubblesCopy.forEach(b -> {
            MatrixStack matrixStack = event.getMatrix();
            matrixStack.push();
            matrixStack.translate(
                b.x - mc.getEntityRenderDispatcher().camera.getPos().getX(), 
                b.y - mc.getEntityRenderDispatcher().camera.getPos().getY(), 
                b.z - mc.getEntityRenderDispatcher().camera.getPos().getZ()
            );
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(b.yaw));
            matrixStack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(b.pitch));
            
            // Draw bubble effect
            drawBubble(matrixStack, -b.life / 4f, b.life / 1500f);
            
            matrixStack.pop();
        });
        
        RenderSystem.enableDepthTest();
        bubbles.removeIf(b -> b.life > lifeTime.getCurrent() * 50);
    }

    public void addHitBubble(Vec3d point, float yaw, float pitch) {
        if (point != null) {
            bubbles.add(new HitBubble(
                (float) point.x, 
                (float) point.y, 
                (float) point.z, 
                -yaw, 
                pitch, 
                0
            ));
        }
    }

    private void drawBubble(MatrixStack matrixStack, float size, float alpha) {
        // Simple bubble rendering - you can enhance this with proper bubble graphics
        // For now, this is a placeholder that would need proper rendering implementation
    }

    public record HitBubble(float x, float y, float z, float yaw, float pitch, long life) {
    }
}
