package zenith.zov.client.hud.elements.component;

import zenith.zov.Zenith;
import zenith.zov.base.animations.base.Animation;
import zenith.zov.base.animations.base.Easing;
import zenith.zov.base.font.Font;
import zenith.zov.base.font.Fonts;
import zenith.zov.base.theme.Theme;
import zenith.zov.client.hud.elements.draggable.DraggableHudElement;
import zenith.zov.client.modules.impl.render.ChunkFinder;
import zenith.zov.utility.render.display.base.BorderRadius;
import zenith.zov.utility.render.display.base.CustomDrawContext;
import zenith.zov.utility.render.display.base.color.ColorRGBA;
import zenith.zov.utility.render.display.shader.DrawUtil;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ChunkFinderComponent extends DraggableHudElement {

    private final Animation widthAnimation = new Animation(200, Easing.QUAD_IN_OUT);
    private final Animation heightAnimation = new Animation(200, Easing.QUAD_IN_OUT);

    public ChunkFinderComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        if (!ChunkFinder.INSTANCE.isEnabled()) {
            return; // Don't render if ChunkFinder is not enabled
        }

        float iconSize = 8f;
        float verticalPadding = 8f;
        float iconTextSpacing = 6f;
        float cellPadding = 8f;
        float borderRadius = 4f;
        float itemSpacing = 4f;
        
        Theme theme = Zenith.getInstance().getThemeManager().getCurrentTheme();
        Font font = Fonts.MEDIUM.getFont(7);
        Font iconFont = Fonts.ICONS.getFont(7);

        ColorRGBA mainBgColor = theme.getForegroundColor();
        ColorRGBA highlightBgColor = theme.getForegroundLight();
        ColorRGBA iconColor = theme.getColor();
        ColorRGBA textColor = theme.getWhite();
        ColorRGBA grayTextColor = theme.getGrayLight();
        ColorRGBA susChunkColor = new ColorRGBA(0, 255, 0, 255); // Green for sus chunks
        ColorRGBA traderChunkColor = new ColorRGBA(255, 165, 0, 255); // Orange for trader chunks

        // Get chunk finder data
        Set<net.minecraft.util.math.ChunkPos> flaggedChunks = ChunkFinder.INSTANCE.getFlaggedChunks();
        Set<net.minecraft.util.math.ChunkPos> traderChunks = ChunkFinder.INSTANCE.getTraderChunks();
        
        int susChunkCount = flaggedChunks.size();
        int traderChunkCount = traderChunks.size();

        // Build display text with coordinates
        String susChunkText;
        String traderChunkText;
        
        if (susChunkCount > 0) {
            // Show first chunk coordinates
            net.minecraft.util.math.ChunkPos firstSusChunk = flaggedChunks.iterator().next();
            int worldX = firstSusChunk.x * 16;
            int worldZ = firstSusChunk.z * 16;
            susChunkText = susChunkCount + " Sus (" + worldX + ", " + worldZ + ")";
        } else {
            susChunkText = "No Sus";
        }
        
        if (traderChunkCount > 0) {
            // Show first chunk coordinates
            net.minecraft.util.math.ChunkPos firstTraderChunk = traderChunks.iterator().next();
            int worldX = firstTraderChunk.x * 16;
            int worldZ = firstTraderChunk.z * 16;
            traderChunkText = traderChunkCount + " Trader (" + worldX + ", " + worldZ + ")";
        } else {
            traderChunkText = "No Trader";
        }
        
        // Calculate dimensions with extra padding for coordinates
        float susChunkWidth = cellPadding * 2 + iconSize + iconTextSpacing + font.width(susChunkText) + 10f;
        float traderChunkWidth = cellPadding * 2 + iconSize + iconTextSpacing + font.width(traderChunkText) + 10f;
        
        float maxWidth = Math.max(susChunkWidth, traderChunkWidth);
        float totalWidth = maxWidth;
        float totalHeight = (iconSize + verticalPadding * 2) * 2 + itemSpacing + 4f;

        // Animate dimensions
        totalWidth = widthAnimation.update(totalWidth);
        totalHeight = heightAnimation.update(totalHeight);

        this.width = totalWidth;
        this.height = totalHeight;

        // Draw background
        DrawUtil.drawBlurHud(ctx.getMatrices(), x, y, totalWidth, totalHeight, 21, BorderRadius.all(4), ColorRGBA.WHITE);
        ctx.drawRoundedRect(x, y, totalWidth, totalHeight, BorderRadius.all(borderRadius), mainBgColor);

        // Draw sus chunks info
        float currentY = y + verticalPadding;
        float iconY = currentY + (iconSize + verticalPadding * 2 - iconSize) / 2f;
        float textY = currentY + (iconSize + verticalPadding * 2 - font.height()) / 2f;
        float currentX = x + cellPadding;

        ctx.enableScissor((int) x, (int) currentY, (int) (x + totalWidth), (int) (currentY + iconSize + verticalPadding * 2));
        
        // Sus chunk icon and text
        ctx.drawText(iconFont, "C", currentX, iconY, susChunkColor);
        currentX += iconSize + iconTextSpacing;
        ColorRGBA susTextColor = susChunkCount > 0 ? susChunkColor : grayTextColor;
        ctx.drawText(font, susChunkText, currentX, textY, susTextColor);
        
        ctx.disableScissor();

        // Draw trader chunks info
        currentY += iconSize + verticalPadding * 2 + itemSpacing;
        iconY = currentY + (iconSize + verticalPadding * 2 - iconSize) / 2f;
        textY = currentY + (iconSize + verticalPadding * 2 - font.height()) / 2f;
        currentX = x + cellPadding;

        ctx.enableScissor((int) x, (int) currentY, (int) (x + totalWidth), (int) (currentY + iconSize + verticalPadding * 2));
        
        // Trader chunk icon and text
        ctx.drawText(iconFont, "D", currentX, iconY, traderChunkColor);
        currentX += iconSize + iconTextSpacing;
        ColorRGBA traderTextColor = traderChunkCount > 0 ? traderChunkColor : grayTextColor;
        ctx.drawText(font, traderChunkText, currentX, textY, traderTextColor);
        
        ctx.disableScissor();

        // Draw border and corner
        ctx.drawRoundedBorder(x, y, totalWidth, totalHeight, 0.1f, BorderRadius.all(4), theme.getForegroundStroke());
        DrawUtil.drawRoundedCorner(ctx.getMatrices(), x, y, totalWidth, totalHeight, 0.1f, 12, theme.getColor(), BorderRadius.all(4));
    }
}
