package zenith.zov.client.modules.api.setting.impl;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import zenith.zov.client.modules.api.setting.Setting;

import java.lang.reflect.Type;
import java.util.List;
import java.util.function.Supplier;

public class EntitySelectSetting extends Setting {
    public void setEntitiesById(List<String> entitiesById) {
        this.entitiesById = entitiesById;
    }

    private List<String> entitiesById;
    
    public EntitySelectSetting(String name, List<String> entitiesById) {
        this(name, entitiesById, () -> true);
    }
    
    public EntitySelectSetting(String name, List<String> entitiesById, Supplier<Boolean> visible) {
        super(name);
        this.entitiesById = entitiesById;
    }

    public List<String> getEntitiesById() {
        return entitiesById;
    }

    public void add(String s) {
        entitiesById.add(s);
    }

    public void remove(String s) {
        entitiesById.remove(s);
    }

    public boolean contains(String s) {
        return entitiesById.contains(s);
    }

    public void add(EntityType<?> entityType) {
        add(entityType.getTranslationKey().replace("entity.minecraft.", ""));
    }

    public void remove(EntityType<?> entityType) {
        remove(entityType.getTranslationKey().replace("entity.minecraft.", ""));
    }

    public boolean contains(EntityType<?> entityType) {
        return contains(entityType.getTranslationKey().replace("entity.minecraft.", ""));
    }

    public boolean contains(Entity entity) {
        return contains(entity.getType());
    }

    public void clear() {
        entitiesById.clear();
    }

    private final static Gson gson = new Gson();
    
    @Override
    public void safe(JsonObject propertiesObject) {
        propertiesObject.add(String.valueOf(name), gson.toJsonTree(this.getEntitiesById()));
    }

    @Override
    public void load(JsonObject propertiesObject) {
        Type listType = new TypeToken<List<String>>() {}.getType();
        JsonElement jsonElement = propertiesObject.get(String.valueOf(name));
        if (jsonElement != null && jsonElement.isJsonArray()) {
            List<String> list = gson.fromJson(jsonElement, listType);
            this.setEntitiesById(list);
        }
    }
}
