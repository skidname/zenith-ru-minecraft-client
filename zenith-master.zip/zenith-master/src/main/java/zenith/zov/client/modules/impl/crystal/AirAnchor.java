package zenith.zov.client.modules.impl.crystal;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import zenith.zov.base.events.impl.player.EventUpdate;
import zenith.zov.client.modules.api.Category;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.api.ModuleAnnotation;
import zenith.zov.client.modules.api.setting.impl.BooleanSetting;
import zenith.zov.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "AirAnchor", description = "Automatically explodes charged anchors in air", category = Category.CRYSTAL)
public class AirAnchor extends Module {
    
    private final NumberSetting maxCount = new NumberSetting("Max Count", 1, 1, 10, 1);
    private final NumberSetting explodeSlot = new NumberSetting("Explode Slot", 1, 1, 9, 1);
    
    private BlockPos currentBlockPos = null;
    private int count = 0;

    public AirAnchor() {
        EventManager.register(this);
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        
        if (isEnabled()) {
            handleAnchorExplosion();
        } else {
            // Reset when disabled
            currentBlockPos = null;
            count = 0;
        }
    }
    
    private void handleAnchorExplosion() {
        // Check if player is holding an anchor
        if (!mc.player.getMainHandStack().getItem().equals(Items.RESPAWN_ANCHOR)) {
            return;
        }
        
        // Check if crosshair target is a block hit result
        if (!(mc.crosshairTarget instanceof BlockHitResult)) {
            return;
        }
        
        BlockHitResult blockHitResult = (BlockHitResult) mc.crosshairTarget;
        
        // Check if the block is a charged anchor
        if (!isAnchorCharged(blockHitResult.getBlockPos())) {
            return;
        }
        
        // Handle count logic for same block
        if (blockHitResult.getBlockPos().equals(currentBlockPos)) {
            if (count >= maxCount.getCurrent()) {
                return;
            }
        } else {
            currentBlockPos = blockHitResult.getBlockPos();
            count = 0;
        }
        
        // Switch to explode slot
        int explodeSlotIndex = (int) explodeSlot.getCurrent() - 1;
        mc.player.getInventory().setSelectedSlot(explodeSlotIndex);
        
        // Send packet to interact with block (explode anchor)
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, blockHitResult);
        mc.player.swingHand(Hand.MAIN_HAND);
        
        count++;
    }
    
    private boolean isAnchorCharged(BlockPos pos) {
        if (mc.world == null) return false;
        
        // Check if block is a respawn anchor
        if (!mc.world.getBlockState(pos).getBlock().equals(Blocks.RESPAWN_ANCHOR)) {
            return false;
        }
        
        // Check if anchor has charges (is charged)
        return mc.world.getBlockState(pos).get(net.minecraft.block.RespawnAnchorBlock.CHARGES) > 0;
    }
}
