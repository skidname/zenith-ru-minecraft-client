package zenith.zov.utility.math;

public class TimerUtils {
    private long lastTime = 0;

    public TimerUtils() {
        reset();
    }

    public void reset() {
        lastTime = System.currentTimeMillis();
    }

    public long getPassedTime() {
        return System.currentTimeMillis() - lastTime;
    }
}
