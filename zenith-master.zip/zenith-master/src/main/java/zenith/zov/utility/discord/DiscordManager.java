package zenith.zov.utility.discord;

import lombok.Getter;
import lombok.Setter;
import net.arikia.dev.drpc.DiscordEventHandlers;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordRichPresence;
import net.arikia.dev.drpc.DiscordUser;
import net.arikia.dev.drpc.callbacks.ReadyCallback;
import zenith.zov.Zenith;
import zenith.zov.utility.interfaces.IMinecraft;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Setter
@Getter
public class DiscordManager implements IMinecraft {
    private boolean running = true;
    private boolean initialized = false;
    private DiscordInfo info = new DiscordInfo("Unknown", "", "");
    private ScheduledExecutorService executor;

    public void init() {
        // Prevent multiple initializations
        if (initialized) {
            return;
        }
        
        try {
            
            DiscordEventHandlers handlers = new DiscordEventHandlers.Builder()
                .setReadyEventHandler(new ReadyCallback() {
                    @Override
                    public void apply(DiscordUser user) {
                        setInfo(new DiscordInfo(user.username, 
                            "https://cdn.discordapp.com/avatars/" + user.userId + "/" + user.avatar + ".png", 
                            user.userId));
                        updatePresence();
                    }
                })
                .setDisconnectedEventHandler((errorCode, message) -> {
                    this.running = false;
                })
                .setErroredEventHandler((errorCode, message) -> {
                    // Ignore errors
                })
                .build();

            DiscordRPC.discordInitialize("1396101952143757353", handlers, true);
            
            // Start callback executor
            executor = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "DiscordRPC-Callback");
                t.setDaemon(true);
                return t;
            });
            
            executor.scheduleAtFixedRate(() -> {
                try {
                    DiscordRPC.discordRunCallbacks();
                } catch (Exception e) {
                    // Ignore callback errors
                }
            }, 0, 2, TimeUnit.SECONDS);
            
            initialized = true;
            
        } catch (Exception e) {
            this.running = false;
            this.initialized = false;
        }
    }
    
    public void updatePresence() {
        if (!this.running || !initialized) {
            return;
        }
        
        try {
            zenith.zov.client.modules.impl.misc.DiscordRPCModule discordModule = 
                (zenith.zov.client.modules.impl.misc.DiscordRPCModule) Zenith.getInstance().getModuleManager().getModule("DiscordRPC");
            if (discordModule == null || !discordModule.isEnabled()) {
                return;
            }
            
            DiscordRichPresence.Builder builder = new DiscordRichPresence.Builder("")
                .setStartTimestamps(System.currentTimeMillis() / 1000)
                .setBigImage("https://s14.gifyu.com/images/bKm4m.jpg", "Zenith DLC");
            
            if (discordModule.isShowDetails()) {
                String details = discordModule.getStatus();
                
                // Add UID based on player name hash (consistent for each player)
                if (mc.player != null) {
                    String playerName = mc.player.getName().getString();
                    int uid = Math.abs(playerName.hashCode()) % 10000 + 1; // UID 1-10000
                    details += " | UID: " + uid;
                }
                
                builder.setDetails(details);
            }
            
            DiscordRPC.discordUpdatePresence(builder.build());
            
        } catch (Exception e) {
            // Ignore presence update errors
        }
    }

    public void stopRPC() {
        if (!this.running || !initialized) {
            return;
        }
        
        try {
            DiscordRPC.discordShutdown();
        } catch (Exception e) {
            // Ignore shutdown errors
        } finally {
            this.running = false;
            this.initialized = false;
            if (executor != null && !executor.isShutdown()) {
                try {
                    executor.shutdown();
                    if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                        executor.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    executor.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
    
    public void forceUpdatePresence() {
        updatePresence();
    }

    public record DiscordInfo(String userName, String avatarUrl, String userId) {}
}
