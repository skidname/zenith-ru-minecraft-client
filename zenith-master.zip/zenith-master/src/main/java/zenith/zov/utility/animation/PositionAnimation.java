package zenith.zov.utility.animation;

import net.minecraft.util.math.Vec3d;

public class PositionAnimation {
    private final float duration;
    private Vec3d startPos;
    private Vec3d targetPos;
    private Vec3d currentPos;
    private long startTime;
    private boolean animating;

    public PositionAnimation(float duration) {
        this.duration = duration;
        this.currentPos = Vec3d.ZERO;
        this.animating = false;
    }

    public void animate(Vec3d targetPos) {
        this.startPos = this.currentPos;
        this.targetPos = targetPos;
        this.startTime = System.currentTimeMillis();
        this.animating = true;
    }

    public void setInstant(Vec3d pos) {
        this.currentPos = pos;
        this.targetPos = pos;
        this.animating = false;
    }

    public Vec3d getCurrentPos() {
        if (!animating) {
            return currentPos;
        }

        long elapsed = System.currentTimeMillis() - startTime;
        float progress = Math.min(1.0f, elapsed / duration);

        if (progress >= 1.0f) {
            currentPos = targetPos;
            animating = false;
            return currentPos;
        }

        // Simple linear interpolation
        double x = startPos.x + (targetPos.x - startPos.x) * progress;
        double y = startPos.y + (targetPos.y - startPos.y) * progress;
        double z = startPos.z + (targetPos.z - startPos.z) * progress;

        currentPos = new Vec3d(x, y, z);
        return currentPos;
    }

    public boolean isAnimating() {
        return animating;
    }
}
