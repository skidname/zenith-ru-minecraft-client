package zenith.zov.utility.world;

import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.GolemEntity;

public class EntityUtils {
    
    public static boolean isHostile(Entity entity) {
        return entity instanceof MobEntity && !(entity instanceof AnimalEntity) && !(entity instanceof GolemEntity);
    }
    
    public static boolean isGolem(Entity entity) {
        return entity instanceof GolemEntity;
    }
    
    public static boolean isPassive(Entity entity) {
        return entity instanceof AnimalEntity;
    }
}
