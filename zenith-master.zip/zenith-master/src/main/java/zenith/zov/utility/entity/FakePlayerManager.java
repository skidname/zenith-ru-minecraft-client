package zenith.zov.utility.entity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import zenith.zov.utility.interfaces.IClient;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class FakePlayerManager implements IClient {
    
    private static final FakePlayerManager INSTANCE = new FakePlayerManager();
    private final ConcurrentMap<Integer, FakePlayerEntity> fakePlayers = new ConcurrentHashMap<>();
    private final List<FakePlayerEntity> sandevistanClones = new ArrayList<>();
    
    private FakePlayerManager() {}
    
    public static FakePlayerManager getInstance() {
        return INSTANCE;
    }
    
    /**
     * Creates a fake player entity for Sandevistan mode
     */
    public FakePlayerEntity createSandevistanClone(PlayerEntity originalEntity) {
        FakePlayerEntity fakePlayer = new FakePlayerEntity(originalEntity, "Sandevistan Clone", true);
        fakePlayer.spawnPlayer();
        sandevistanClones.add(fakePlayer);
        fakePlayers.put(fakePlayer.getId(), fakePlayer);
        return fakePlayer;
    }
    
    /**
     * Creates a regular fake player entity
     */
    public FakePlayerEntity createFakePlayer(PlayerEntity originalEntity, String name) {
        FakePlayerEntity fakePlayer = new FakePlayerEntity(originalEntity, name, false);
        fakePlayer.spawnPlayer();
        fakePlayers.put(fakePlayer.getId(), fakePlayer);
        return fakePlayer;
    }
    
    /**
     * Removes a fake player entity
     */
    public void removeFakePlayer(FakePlayerEntity fakePlayer) {
        fakePlayer.despawnPlayer();
        fakePlayers.remove(fakePlayer.getId());
        sandevistanClones.remove(fakePlayer);
    }
    
    /**
     * Removes all fake players
     */
    public void clearAllFakePlayers() {
        for (FakePlayerEntity fakePlayer : fakePlayers.values()) {
            fakePlayer.despawnPlayer();
        }
        fakePlayers.clear();
        sandevistanClones.clear();
    }
    
    /**
     * Removes expired Sandevistan clones
     */
    public void cleanupExpiredClones(long maxAge) {
        Iterator<FakePlayerEntity> iterator = sandevistanClones.iterator();
        while (iterator.hasNext()) {
            FakePlayerEntity clone = iterator.next();
            if (clone.isExpired(maxAge)) {
                removeFakePlayer(clone);
                iterator.remove();
            }
        }
    }
    
    /**
     * Removes clones that are too far from the player
     */
    public void cleanupDistantClones(double maxDistance) {
        if (mc.player == null) return;
        
        Iterator<FakePlayerEntity> iterator = sandevistanClones.iterator();
        while (iterator.hasNext()) {
            FakePlayerEntity clone = iterator.next();
            if (!clone.isInRange(maxDistance)) {
                removeFakePlayer(clone);
                iterator.remove();
            }
        }
    }
    
    /**
     * Updates all fake player positions
     */
    public void updatePositions() {
        for (FakePlayerEntity fakePlayer : fakePlayers.values()) {
            if (fakePlayer.getOriginalEntity() != null) {
                fakePlayer.updatePosition(fakePlayer.getOriginalEntity().getPos());
            }
        }
    }
    
    /**
     * Gets all fake players
     */
    public List<FakePlayerEntity> getAllFakePlayers() {
        return new ArrayList<>(fakePlayers.values());
    }
    
    /**
     * Gets all Sandevistan clones
     */
    public List<FakePlayerEntity> getSandevistanClones() {
        return new ArrayList<>(sandevistanClones);
    }
    
    /**
     * Gets a fake player by ID
     */
    public FakePlayerEntity getFakePlayer(int id) {
        return fakePlayers.get(id);
    }
    
    /**
     * Gets the closest fake player to a position
     */
    public FakePlayerEntity getClosestFakePlayer(Vec3d position) {
        FakePlayerEntity closest = null;
        double closestDistance = Double.MAX_VALUE;
        
        for (FakePlayerEntity fakePlayer : fakePlayers.values()) {
            double distance = fakePlayer.distanceTo(position);
            if (distance < closestDistance) {
                closestDistance = distance;
                closest = fakePlayer;
            }
        }
        
        return closest;
    }
    
    /**
     * Gets the number of active fake players
     */
    public int getFakePlayerCount() {
        return fakePlayers.size();
    }
    
    /**
     * Gets the number of Sandevistan clones
     */
    public int getSandevistanCloneCount() {
        return sandevistanClones.size();
    }
    
    /**
     * Checks if a fake player exists with the given ID
     */
    public boolean hasFakePlayer(int id) {
        return fakePlayers.containsKey(id);
    }
    
    /**
     * Performs cleanup operations
     */
    public void performCleanup(long maxAge, double maxDistance) {
        cleanupExpiredClones(maxAge);
        cleanupDistantClones(maxDistance);
        updatePositions();
    }
}
