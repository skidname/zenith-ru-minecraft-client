package zenith.zov.utility.interfaces;

import net.minecraft.client.util.Window;

public interface IWindow extends IMinecraft {

    Window mw = mc.getWindow();

}