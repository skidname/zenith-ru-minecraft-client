package zenith.zov.utility.render.display.shader;

import zenith.zov.utility.math.Timer;

public class ShaderTicker {
    private final Timer timer = new Timer();
    private long passedTime = 0;

    public ShaderTicker() {
        timer.reset();
    }

    public void reset() {
        passedTime = 0;
        timer.reset();
    }

    public void update(float speed) {
        passedTime += (long) (timer.getElapsedTime() * speed);
        timer.reset();
    }

    public long getPassedTime() {
        return passedTime;
    }
}
