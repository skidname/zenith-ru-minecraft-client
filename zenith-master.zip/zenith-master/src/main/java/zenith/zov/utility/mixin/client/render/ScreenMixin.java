package zenith.zov.utility.mixin.client.render;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Style;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import zenith.zov.Zenith;
import zenith.zov.base.comand.CommandManager;

import java.util.Objects;

@Mixin(Screen.class)
public class ScreenMixin {

}

