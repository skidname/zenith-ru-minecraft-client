package zenith.zov.utility.render.display.base;

import org.jetbrains.annotations.NotNull;

public record BorderRadius(float topLeftRadius, float topRightRadius, float bottomRightRadius, float bottomLeftRadius) {

    public static final BorderRadius ZERO = new BorderRadius(0f, 0f, 0f, 0f);

    /**
     * Creates BorderRadius instance with same radius for all corners.
     */
    public static BorderRadius all(float radius) {
        return new BorderRadius(radius, radius, radius, radius);
    }

    /**
     * Creates BorderRadius instance with radius only for top left corner.
     */
    public static BorderRadius topLeft(float radius) {
        return new BorderRadius(radius, 0f, 0f, 0f);
    }

    /**
     * Creates BorderRadius instance with radius only for top right corner.
     */
    public static BorderRadius topRight(float radius) {
        return new BorderRadius(0f, radius, 0f, 0f);
    }

    /**
     * Creates BorderRadius instance with radius only for bottom right corner.
     */
    public static BorderRadius bottomRight(float radius) {
        return new BorderRadius(0f, 0f, radius, 0f);
    }

    /**
     * Creates BorderRadius instance with radius only for bottom left corner.
     */
    public static BorderRadius bottomLeft(float radius) {
        return new BorderRadius(0f, 0f, 0f, radius);
    }

    /**
     * Creates BorderRadius instance with radius only for top edge.
     */
    public static BorderRadius top(float leftRadius, float rightRadius) {
        return new BorderRadius(leftRadius, rightRadius, 0f, 0f);
    }

    /**
     * Creates BorderRadius instance with radius only for bottom edge.
     */
    public static BorderRadius bottom(float leftRadius, float rightRadius) {
        return new BorderRadius(0f, 0f, rightRadius, leftRadius);
    }

    /**
     * Creates BorderRadius instance with radius only for left edge.
     */
    public static BorderRadius left(float topRadius, float bottomRadius) {
        return new BorderRadius(topRadius, 0f, 0f, bottomRadius);
    }

    /**
     * Creates BorderRadius instance with radius only for right edge.
     */
    public static BorderRadius right(float topRadius, float bottomRadius) {
        return new BorderRadius(0f, topRadius, bottomRadius, 0f);
    }

    @Override
    public @NotNull String toString() {
        return "BorderRadius{" +
                "topLeftRadius=" + topLeftRadius +
                ", topRightRadius=" + topRightRadius +
                ", bottomRightRadius=" + bottomRightRadius +
                ", bottomLeftRadius=" + bottomLeftRadius +
                '}';
    }
}
