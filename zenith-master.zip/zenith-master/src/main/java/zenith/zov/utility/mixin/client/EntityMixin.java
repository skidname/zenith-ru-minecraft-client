package zenith.zov.utility.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import zenith.zov.Zenith;
import zenith.zov.utility.interfaces.IMinecraft;
import zenith.zov.client.modules.impl.combat.HitBox;

@Mixin(Entity.class)
public class EntityMixin implements IMinecraft {

    @ModifyExpressionValue(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isControlledByPlayer()Z"))
    public boolean fixFalldistanceValue(boolean original) {
        if ((Object) this == mc.player) {
            return false;
        }

        return original;
    }

    @Redirect(method = "updateVelocity", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getYaw()F"))
    public float movementCorrection(Entity instance) {

        if (instance instanceof ClientPlayerEntity) { //HELLO PEOPLE WITH BIG MONITOR
            return Zenith.getInstance().getRotationManager().getCurrentRotation().getYaw();
        }

        return instance.getYaw();
    }
    @ModifyVariable(
            method = "getRotationVector(FF)Lnet/minecraft/util/math/Vec3d;",
            at = @At("HEAD"),
            ordinal = 0,
            argsOnly = true
    )
    private float modifyPitch(float pitch) {
        if ((Object) this instanceof ClientPlayerEntity) {
            return Zenith.getInstance().getRotationManager().getCurrentRotation().getPitch();
        }
        return pitch;
    }

    @ModifyVariable(
            method = "getRotationVector(FF)Lnet/minecraft/util/math/Vec3d;",
            at = @At("HEAD"),
            ordinal = 1,
            argsOnly = true
    )
    private float modifyYaw(float yaw) {
        if ((Object) this instanceof ClientPlayerEntity) {
            return Zenith.getInstance().getRotationManager().getCurrentRotation().getYaw();
        }
        return yaw;
    }

    @Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true)
    private void modifyBoundingBox(CallbackInfoReturnable<Box> cir) {
        if (HitBox.INSTANCE.isEnabled() && (Object) this instanceof LivingEntity living) {
            if (living != mc.player && !Zenith.getInstance().getFriendManager().isFriend(living.getName().getString())) {
                Box original = cir.getReturnValue();
                float xzExpand = HitBox.INSTANCE.getXzExpandSetting().getCurrent();
                float yExpand = HitBox.INSTANCE.getYExpandSetting().getCurrent();
                
                Box expanded = new Box(
                    original.minX - xzExpand / 2.0f, 
                    original.minY - yExpand / 2.0f,
                    original.minZ - xzExpand / 2.0f, 
                    original.maxX + xzExpand / 2.0f,
                    original.maxY + yExpand / 2.0f, 
                    original.maxZ + xzExpand / 2.0f
                );
                
                cir.setReturnValue(expanded);
            }
        }
    }

}
