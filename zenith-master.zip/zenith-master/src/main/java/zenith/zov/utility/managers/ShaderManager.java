package zenith.zov.utility.managers;

import lombok.Getter;
import zenith.zov.Zenith;
import zenith.zov.utility.math.TimerUtils;

@Getter
public class ShaderManager {

    private final ShaderTimer timer = new ShaderTimer();

    public ShaderManager() {
        // Subscribe to events if needed
    }

    public void onDisconnect() {
        timer.reset();
    }

    public void updateTime() {
        timer.update(1);
    }

    @Getter
    public static class ShaderTimer {
        private final TimerUtils timer = new TimerUtils();
        private long passedTime = 0;

        public ShaderTimer() {
            timer.reset();
        }

        public void reset() {
            passedTime = 0;
            timer.reset();
        }

        public void update(float speed) {
            passedTime += (long) (timer.getPassedTime() * speed);
            timer.reset();
        }
    }
}
