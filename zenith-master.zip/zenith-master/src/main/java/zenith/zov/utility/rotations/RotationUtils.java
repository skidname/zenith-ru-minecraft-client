package zenith.zov.utility.rotations;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import zenith.zov.utility.interfaces.IMinecraft;

public class RotationUtils implements IMinecraft {
    
    public static float[] getRotations(double x, double y, double z) {
        return getRotations(mc.player.getEyePos(), new Vec3d(x, y, z));
    }
    
    public static float[] getRotations(Vec3d from, Vec3d to) {
        double deltaX = to.x - from.x;
        double deltaY = to.y - from.y;
        double deltaZ = to.z - from.z;
        
        double distance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        
        float yaw = (float) (MathHelper.atan2(deltaZ, deltaX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) (-(MathHelper.atan2(deltaY, distance) * 180.0 / Math.PI));
        
        return new float[]{yaw, pitch};
    }
    
    public static float normalizeAngle(float angle) {
        while (angle > 180.0f) {
            angle -= 360.0f;
        }
        while (angle < -180.0f) {
            angle += 360.0f;
        }
        return angle;
    }
}
