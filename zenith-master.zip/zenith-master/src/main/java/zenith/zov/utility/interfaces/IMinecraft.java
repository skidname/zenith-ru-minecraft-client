package zenith.zov.utility.interfaces;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.util.Window;

public interface IMinecraft {
    MinecraftClient mc = MinecraftClient.getInstance();
}
