package zenith.zov.utility.entity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import zenith.zov.utility.interfaces.IClient;

import java.awt.*;

public class FakePlayerEntity implements IClient {
    private final PlayerEntity originalEntity;
    private final String name;
    private final boolean isClone;
    private Vec3d position;
    private int id;
    private boolean spawned = false;
    private long spawnTime;

    public FakePlayerEntity(PlayerEntity originalEntity, String name, boolean isClone) {
        this.originalEntity = originalEntity;
        this.name = name;
        this.isClone = isClone;
        this.position = originalEntity.getPos();
        this.id = originalEntity.getId() + 1000000; // Offset to avoid conflicts
        this.spawnTime = System.currentTimeMillis();
    }

    public void spawnPlayer() {
        if (spawned) return;
        
        // In a real implementation, this would spawn a fake player entity
        // For now, we'll just mark as spawned and track the position
        this.spawned = true;
        this.spawnTime = System.currentTimeMillis();
        
        // Update position to current entity position
        if (originalEntity != null) {
            this.position = originalEntity.getPos();
        }
    }

    public void despawnPlayer() {
        if (!spawned) return;
        
        // In a real implementation, this would despawn the fake player entity
        // For now, we'll just mark as despawned
        this.spawned = false;
        this.position = Vec3d.ZERO;
    }

    public void updatePosition(Vec3d newPosition) {
        this.position = newPosition;
    }

    public Vec3d getPos() {
        return position;
    }

    public int getId() {
        return id;
    }

    public boolean isClone() {
        return isClone;
    }

    public boolean isSpawned() {
        return spawned;
    }

    public long getSpawnTime() {
        return spawnTime;
    }

    public long getAge() {
        return System.currentTimeMillis() - spawnTime;
    }

    public double distanceTo(PlayerEntity other) {
        return position.distanceTo(other.getPos());
    }

    public double distanceTo(Vec3d pos) {
        return position.distanceTo(pos);
    }

    public Color cloneColor(float alpha) {
        // Return a color based on alpha value
        int alphaValue = (int) (alpha * 255);
        return new Color(255, 255, 255, Math.max(0, Math.min(255, alphaValue)));
    }

    public Color cloneColor(int time) {
        // Return a color based on time
        float alpha = Math.max(0.0f, Math.min(1.0f, time / 1000.0f));
        return cloneColor(alpha);
    }

    public Color getFadeColor(float maxAlpha) {
        // Get color that fades based on age
        long age = getAge();
        float alpha = Math.max(0.0f, Math.min(maxAlpha, 1.0f - (age / 3000.0f))); // Fade over 3 seconds
        return cloneColor(alpha);
    }

    public PlayerEntity getOriginalEntity() {
        return originalEntity;
    }

    public String getName() {
        return name;
    }

    public float getWidth() {
        return originalEntity != null ? originalEntity.getWidth() : 0.6f;
    }

    public float getHeight() {
        return originalEntity != null ? originalEntity.getHeight() : 1.8f;
    }

    public boolean isInRange(double maxDistance) {
        if (mc.player == null) return false;
        return distanceTo(mc.player) <= maxDistance;
    }

    public boolean isExpired(long maxAge) {
        return getAge() > maxAge;
    }
}
