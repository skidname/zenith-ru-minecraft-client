package zenith.zov.utility.other;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BooleanSettable {
    private boolean value;

    public BooleanSettable() {}
}
