package zenith.zov.base.events.impl.player;

import zenith.zov.base.events.callables.EventCancellable;

public class EventSprintUpdate  extends EventCancellable {
}
