package zenith.zov.base.comand.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import zenith.zov.Zenith;
import zenith.zov.base.comand.api.CommandAbstract;

import zenith.zov.utility.game.other.MessageUtil;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class ConfigCommand extends CommandAbstract {
    public ConfigCommand() {
        super("config");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {

        builder.then(literal("save").executes(context -> {
            boolean success = Zenith.getInstance().getConfigManager().saveConfig("confeg");
            if (success) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                    "§aConfiguration saved");
            } else {
                MessageUtil.displayMessage(MessageUtil.LogLevel.WARN,
                    "§cError saving configuration");
            }
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("load").executes(context -> {
            boolean success = Zenith.getInstance().getConfigManager().loadConfig("confeg");
            if (success) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                    "§aConfiguration loaded");
            } else {
                MessageUtil.displayMessage(MessageUtil.LogLevel.WARN,
                    "§cError loading configuration");
            }
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("help").executes(context -> {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Usage: §r.config <list/save/load/help>");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Commands:§r");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.config save §7- save configuration");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.config load §7- load configuration");
            return SINGLE_SUCCESS;
        }));
    }
}
