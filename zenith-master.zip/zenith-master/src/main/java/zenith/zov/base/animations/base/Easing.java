package zenith.zov.base.animations.base;

import lombok.Getter;
import lombok.Setter;
import zenith.zov.utility.math.MathUtil;

@SuppressWarnings("unused")
public interface Easing {

    // From Cockstar client
    Easing BAKEK = Easing.generate(0.45f, 1.45f, 0.49f, 1.15f);
    Easing BAKEK_SMALLER = Easing.generate(0.45f, 1.45f, 0.43f, 0.91f);
    Easing BAKEK_PAGES = Easing.generate(0.1f, 1.07f, 0.34f, 1.04f);
    Easing BAKEK_SIZE = Easing.generate(0.27f, 1.09f, 0.49f, 1.06f);
    Easing BAKEK_BACK = Easing.generate(0.62, -0.16, 0.8, 0.37);
    Easing BAKEK_MANY = Easing.generate(0.25, 1.07, 0.11, 1.1);

    Easing FIGMA_EASE_IN_OUT = Easing.generate(0.42, 0, 0.58, 1);

    Easing SMOOTH_STEP = (t, b, c, d) -> {
        float x = c * t / d + b;
        return (float) (-2 * Math.pow(x, 3) + (3 * Math.pow(x, 2)));
    };

    Easing BOTH_CUBIC = (t, b, c, d) -> {
        float x = c * t / d + b;
        return x < 0.5 ? 4 * x * x * x : (float) (1 - Math.pow(-2 * x + 2, 3) / 2);
    };

    /**
     * Simple linear tweening - no easing.
     */
    Easing LINEAR = (t, b, c, d) -> c * t / d + b;
    /**
     * Quadratic easing in - accelerating from zero velocity.
     */
    Easing QUAD_IN = (t, b, c, d) -> c * (t /= d) * t + b;

    ///////////// QUADRATIC EASING: t^2 ///////////////////
    /**
     * Quadratic easing out - decelerating to zero velocity.
     */
    Easing QUAD_OUT = (t, b, c, d) -> - c * (t /= d) * (t - 2) + b;
    /**
     * Quadratic easing in/out - acceleration until halfway, then deceleration
     */
    Easing QUAD_IN_OUT = (t, b, c, d) -> {
        if ((t /= d / 2) < 1) return c / 2 * t * t + b;
        return - c / 2 * ((-- t) * (t - 2) - 1) + b;
    };
    /**
     * Cubic easing in - accelerating from zero velocity.
     */
    Easing CUBIC_IN = (t, b, c, d) -> c * (t /= d) * t * t + b;


    ///////////// CUBIC EASING: t^3 ///////////////////////
    /**
     * Cubic easing out - decelerating to zero velocity.
     */
    Easing CUBIC_OUT = (t, b, c, d) -> c * ((t = t / d - 1) * t * t + 1) + b;
    /**
     * Cubic easing in/out - acceleration until halfway, then deceleration.
     */
    Easing CUBIC_IN_OUT = (t, b, c, d) -> {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t + b;
        return c / 2 * ((t -= 2) * t * t + 2) + b;
    };
    /**
     * Quartic easing in - accelerating from zero velocity.
     */
    Easing QUARTIC_IN = (t, b, c, d) -> c * (t /= d) * t * t * t + b;

    ///////////// QUARTIC EASING: t^4 /////////////////////
    /**
     * Quartic easing out - decelerating to zero velocity.
     */
    Easing QUARTIC_OUT = (t, b, c, d) -> - c * ((t = t / d - 1) * t * t * t - 1) + b;
    /**
     * Quartic easing in/out - acceleration until halfway, then deceleration.
     */
    Easing QUARTIC_IN_OUT = (t, b, c, d) -> {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t * t + b;
        return - c / 2 * ((t -= 2) * t * t * t - 2) + b;
    };
    /**
     * Quintic easing in - accelerating from zero velocity.
     */
    Easing QUINTIC_IN = (t, b, c, d) -> c * (t /= d) * t * t * t * t + b;

    ///////////// QUINTIC EASING: t^5  ////////////////////
    /**
     * Quintic easing out - decelerating to zero velocity.
     */
    Easing QUINTIC_OUT = (t, b, c, d) -> c * ((t = t / d - 1) * t * t * t * t + 1) + b;
    /**
     * Quintic easing in/out - acceleration until halfway, then deceleration.
     */
    Easing QUINTIC_IN_OUT = (t, b, c, d) -> {
        if ((t /= d / 2) < 1) return c / 2 * t * t * t * t * t + b;
        return c / 2 * ((t -= 2) * t * t * t * t + 2) + b;
    };
    /**
     * Sinusoidal easing in - accelerating from zero velocity.
     */
    Easing SINE_IN = (t, b, c, d) -> - c * (float) MathUtil.cos(t / d * (Math.PI / 2)) + c + b;


    ///////////// SINUSOIDAL EASING: sin(t) ///////////////
    /**
     * Sinusoidal easing out - decelerating to zero velocity.
     */
    Easing SINE_OUT = (t, b, c, d) -> c * (float) MathUtil.sin(t / d * (Math.PI / 2)) + b;
    /**
     * Sinusoidal easing in/out - accelerating until halfway, then decelerating.
     */
    Easing SINE_IN_OUT = (t, b, c, d) -> - c / 2 * ((float) MathUtil.cos(Math.PI * t / d) - 1) + b;
    /**
     * Exponential easing in - accelerating from zero velocity.
     */
    Easing EXPO_IN = (t, b, c, d) -> (t == 0) ? b : c * (float) Math.pow(2, 10 * (t / d - 1)) + b;

    ///////////// EXPONENTIAL EASING: 2^t /////////////////
    /**
     * Exponential easing out - decelerating to zero velocity.
     */
    Easing EXPO_OUT = (t, b, c, d) -> (t == d) ? b + c : c * (- (float) Math.pow(2, - 10 * t / d) + 1) + b;
    /**
     * Exponential easing in/out - accelerating until halfway, then decelerating.
     */
    Easing EXPO_IN_OUT = (t, b, c, d) -> {
        if (t == 0) return b;
        if (t == d) return b + c;
        if ((t /= d / 2) < 1) return c / 2 * (float) Math.pow(2, 10 * (t - 1)) + b;
        return c / 2 * (- (float) Math.pow(2, - 10 * -- t) + 2) + b;
    };
    /**
     * Circular easing in - accelerating from zero velocity.
     */
    Easing CIRC_IN = (t, b, c, d) -> - c * ((float) Math.sqrt(1 - (t /= d) * t) - 1) + b;


    /////////// CIRCULAR EASING: sqrt(1-t^2) //////////////
    /**
     * Circular easing out - decelerating to zero velocity.
     */
    Easing CIRC_OUT = (t, b, c, d) -> c * (float) Math.sqrt(1 - (t = t / d - 1) * t) + b;
    /**
     * Circular easing in/out - acceleration until halfway, then deceleration.
     */
    Easing CIRC_IN_OUT = (t, b, c, d) -> {
        if ((t /= d / 2) < 1) return - c / 2 * ((float) Math.sqrt(1 - t * t) - 1) + b;
        return c / 2 * ((float) Math.sqrt(1 - (t -= 2) * t) + 1) + b;
    };
    /**
     * An EasingIn instance using the default values.
     */
    Elastic ELASTIC_IN = new ElasticIn();

    /////////// ELASTIC EASING: exponentially decaying sine wave  //////////////
    /**
     * An ElasticOut instance using the default values.
     */
    Elastic ELASTIC_OUT = new ElasticOut();
    /**
     * An ElasticInOut instance using the default values.
     */
    Elastic ELASTIC_IN_OUT = new ElasticInOut();
    /**
     * An instance of BackIn using the default overshoot.
     */
    Back BACK_IN = new BackIn();
    /**
     * An instance of BackOut using the default overshoot.
     */
    Back BACK_OUT = new BackOut();
    /**
     * An instance of BackInOut using the default overshoot.
     */
    Back BACK_IN_OUT = new BackInOut();
    /**
     * Bounce easing out.
     */
    Easing BOUNCE_OUT = (t, b, c, d) -> {
        if ((t /= d) < (1 / 2.75f)) {
            return c * (7.5625f * t * t) + b;
        } else if (t < (2 / 2.75f)) {
            return c * (7.5625f * (t -= (1.5f / 2.75f)) * t + .75f) + b;
        } else if (t < (2.5f / 2.75f)) {
            return c * (7.5625f * (t -= (2.25f / 2.75f)) * t + .9375f) + b;
        } else {
            return c * (7.5625f * (t -= (2.625f / 2.75f)) * t + .984375f) + b;
        }
    };
    /**
     * Bounce easing in.
     */
    Easing BOUNCE_IN = (t, b, c, d) -> c - Easing.BOUNCE_OUT.ease(d - t, 0, c, d) + b;

    /////////// BACK EASING: overshooting cubic easing: (s+1)*t^3 - s*t^2  //////////////
    /**
     * Bounce easing in/out.
     */
    Easing BOUNCE_IN_OUT = (t, b, c, d) -> {
        if (t < d / 2) return Easing.BOUNCE_IN.ease(t * 2, 0, c, d) * .5f + b;
        return Easing.BOUNCE_OUT.ease(t * 2 - d, 0, c, d) * .5f + c * .5f + b;
    };


    static Easing generate(double x1, double y1, double x2, double y2) {
        return new Easing() {
            @Override
            public float ease(float t, float b, float c, float d) {
                if (d <= 0 || t <= 0) return b;
                if (t >= d) return b + c;

                float progress = t / d;
                float tBez = solveTBez((float) x1, (float) x2, progress);
                float y = bezierY(tBez, (float) y1, (float) y2);

                return b + c * y;
            }

            private float solveTBez(float x1, float x2, float progress) {
                float t = progress;
                final int MAX_ITERATIONS = 8;
                final float EPSILON = 1e-5f;

                for (int i = 0; i < MAX_ITERATIONS; i++) {
                    float x = bezierX(t, x1, x2);
                    float dx = bezierDX(t, x1, x2);

                    if (Math.abs(x - progress) < EPSILON) break;
                    if (Math.abs(dx) < 1e-6f) break;

                    t -= (x - progress) / dx;
                    t = Math.max(0, Math.min(1, t));
                }

                return t;
            }

            private float bezierX(float t, float x1, float x2) {
                return 3 * (1 - t) * (1 - t) * t * x1
                        + 3 * (1 - t) * t * t * x2
                        + t * t * t;
            }

            private float bezierDX(float t, float x1, float x2) {
                return 3 * ((1 - t) * (1 - 3 * t) * x1
                        + (2 * t - 3 * t * t) * x2)
                        + 3 * t * t;
            }

            private float bezierY(float t, float y1, float y2) {
                return 3 * (1 - t) * (1 - t) * t * y1
                        + 3 * (1 - t) * t * t * y2
                        + t * t * t;
            }
        };
    }

    /**
     * The basic function for easing.
     *
     * @param t the time (either frames or in seconds/milliseconds)
     * @param b the beginning value
     * @param c the value changed
     * @param d the duration time
     * @return the eased value
     */
    float ease(float t, float b, float c, float d);

    /**
     * A base class for elastic easings.
     */
    @Setter
    @Getter
    abstract class Elastic implements Easing {
        private float amplitude;
        private float period;

        /**
         * Creates a new Elastic easing with the specified settings.
         *
         * @param amplitude the amplitude for the elastic function
         * @param period    the period for the elastic function
         */
        public Elastic(float amplitude, float period) {
            this.amplitude = amplitude;
            this.period = period;
        }

        /**
         * Creates a new Elastic easing with default settings (-1f, 0f).
         */
        public Elastic() {
            this(- 1f, 0f);
        }

    }

    /**
     * An Elastic easing used for ElasticIn functions.
     */
    class ElasticIn extends Elastic {
        public ElasticIn(float amplitude, float period) {
            super(amplitude, period);
        }

        public ElasticIn() {
            super();
        }

        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0) return b;
            if ((t /= d) == 1) return b + c;
            if (p == 0) p = d * .3f;
            float s = 0;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4;
            } else s = p / (float) (2 * Math.PI) * (float) Math.asin(c / a);
            return - (a * (float) Math.pow(2, 10 * (t -= 1)) * (float) MathUtil.sin((t * d - s) * (2 * Math.PI) / p)) + b;
        }
    }

    /**
     * An Elastic easing used for ElasticOut functions.
     */
    class ElasticOut extends Elastic {
        public ElasticOut(float amplitude, float period) {
            super(amplitude, period);
        }

        public ElasticOut() {
            super();
        }

        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0) return b;
            if ((t /= d) == 1) return b + c;
            if (p == 0) p = d * .3f;
            float s = 0;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4;
            } else s = p / (float) (2 * Math.PI) * (float) Math.asin(c / a);
            return a * (float) Math.pow(2, - 10 * t) * (float) MathUtil.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
        }
    }

    /**
     * An Elastic easing used for ElasticInOut functions.
     */
    class ElasticInOut extends Elastic {
        public ElasticInOut(float amplitude, float period) {
            super(amplitude, period);
        }

        public ElasticInOut() {
            super();
        }

        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0) return b;
            if ((t /= d / 2) == 2) return b + c;
            if (p == 0) p = d * (.3f * 1.5f);
            float s = 0;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4f;
            } else s = p / (float) (2 * Math.PI) * (float) Math.asin(c / a);
            if (t < 1)
                return - .5f * (a * (float) Math.pow(2, 10 * (t -= 1)) * (float) MathUtil.sin((t * d - s) * (2 * Math.PI) / p)) + b;
            return a * (float) Math.pow(2, - 10 * (t -= 1)) * (float) MathUtil.sin((t * d - s) * (2 * Math.PI) / p) * .5f + c + b;
        }
    }

    /**
     * A base class for Back easings.
     */
    @Setter
    @Getter
    abstract class Back implements Easing {
        /**
         * The default overshoot is 10% (1.70158).
         */
        public static final float DEFAULT_OVERSHOOT = 1.70158f;

        private float overshoot;

        /**
         * Creates a new Back instance with the default overshoot (1.70158).
         */
        public Back() {
            this(DEFAULT_OVERSHOOT);
        }

        /**
         * Creates a new Back instance with the specified overshoot.
         *
         * @param overshoot the amount to overshoot by -- higher number
         *                  means more overshoot and an overshoot of 0 results in
         *                  cubic easing with no overshoot
         */
        public Back(float overshoot) {
            this.overshoot = overshoot;
        }

    }

    /////////// BOUNCE EASING: exponentially decaying parabolic bounce  //////////////

    /**
     * Back easing in - backtracking slightly, then reversing direction and moving to target.
     */
    class BackIn extends Back {
        public BackIn() {
            super();
        }

        public BackIn(float overshoot) {
            super(overshoot);
        }

        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            return c * (t /= d) * t * ((s + 1) * t - s) + b;
        }
    }

    /**
     * Back easing out - moving towards target, overshooting it slightly, then reversing and coming back to target.
     */
    class BackOut extends Back {
        public BackOut() {
            super();
        }

        public BackOut(float overshoot) {
            super(overshoot);
        }

        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            return c * ((t = t / d - 1) * t * ((s + 1) * t + s) + 1) + b;
        }
    }

    /**
     * Back easing in/out - backtracking slightly, then reversing direction and moving to target,
     * then overshooting target, reversing, and finally coming back to target.
     */
    class BackInOut extends Back {
        public BackInOut() {
            super();
        }

        public BackInOut(float overshoot) {
            super(overshoot);
        }

        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            if ((t /= d / 2) < 1) return c / 2 * (t * t * (((s *= 1.525F) + 1) * t - s)) + b;
            return c / 2 * ((t -= 2) * t * (((s *= 1.525F) + 1) * t + s) + 2) + b;
        }
    }
}