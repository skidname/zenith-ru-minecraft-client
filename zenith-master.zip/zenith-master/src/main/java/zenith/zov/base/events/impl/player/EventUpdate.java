package zenith.zov.base.events.impl.player;


import com.darkmagician6.eventapi.events.Event;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class EventUpdate implements Event {

    //jeto
    //This event fires every PLAYER tick when mc.player !=null and mc.world !=null
    //unlike EventTick event which fires every real Minecraft tick
}
