package zenith.zov.base.rotation.mods.api;


import zenith.zov.utility.interfaces.IClient;

public abstract class RotationMode  implements IClient {
}
