package zenith.zov.base.rotation.mods.config.api;

public abstract class RotationConfig {
    public abstract RotationModeType getType();
}
