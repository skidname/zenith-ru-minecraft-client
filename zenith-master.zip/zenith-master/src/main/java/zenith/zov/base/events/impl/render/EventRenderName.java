package zenith.zov.base.events.impl.render;


import zenith.zov.base.events.callables.EventCancellable;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public final class EventRenderName extends EventCancellable {

}