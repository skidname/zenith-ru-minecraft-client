package zenith.zov.base.events.impl.player;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import zenith.zov.base.events.callables.EventCancellable;

@Getter
@Setter
@AllArgsConstructor
public class EventRotate extends EventCancellable {
}
