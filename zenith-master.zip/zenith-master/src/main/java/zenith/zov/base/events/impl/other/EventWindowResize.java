package zenith.zov.base.events.impl.other;

import com.darkmagician6.eventapi.events.Event;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class EventWindowResize implements Event {

}
