package zenith.zov.base.rotation.mods.config.api;

public enum RotationModeType {
    INSTANT,
    INTERPOLATION,
    AI
}

