package zenith.zov.base.comand.impl;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NbtCompound;
import zenith.zov.base.comand.api.CommandAbstract;
import zenith.zov.utility.game.other.MessageUtil;
import zenith.zov.utility.interfaces.IClient;

import java.util.UUID;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class FakePlayerCommand extends CommandAbstract implements IClient {
    
    private boolean spawn = false;
    public static OtherClientPlayerEntity player = null;

    public FakePlayerCommand() {
        super("fakeplayer");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            spawn = !spawn;
            if (spawn) {
                if (mc.player == null || mc.world == null) return SINGLE_SUCCESS;
                
                // Create fake player entity
                player = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), "ZenithClient.cc"));
                player.copyPositionAndRotation(mc.player);
                player.setId(-673);
                player.copyFrom(mc.player);
                player.setHealth(20f);
                player.setAbsorptionAmount(16f);
                
                // Copy player data
                NbtCompound compoundTag = new NbtCompound();
                mc.player.writeCustomDataToNbt(compoundTag);
                player.readCustomDataFromNbt(compoundTag);
                
                // Add to world and tick
                mc.world.addEntity(player);
                player.tick();
                
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aSuccessfully spawned the fake player");
            } else {
                if (mc.player == null || mc.world == null || player == null) return SINGLE_SUCCESS;
                
                // Remove fake player
                mc.world.removeEntity(player.getId(), Entity.RemovalReason.DISCARDED);
                player = null;
                
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aSuccessfully removed the fake player");
            }

            return SINGLE_SUCCESS;
        });
    }
}
