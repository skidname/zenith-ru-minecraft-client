package zenith.zov.base.events.impl.other;


import com.darkmagician6.eventapi.events.Event;

public class EventTick implements Event {
}