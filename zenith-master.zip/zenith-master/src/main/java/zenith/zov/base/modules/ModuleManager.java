package zenith.zov.base.modules;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import org.lwjgl.glfw.GLFW;


import zenith.zov.base.events.impl.input.EventKey;
import zenith.zov.client.modules.api.Module;
import zenith.zov.client.modules.impl.combat.*;
import zenith.zov.client.modules.impl.crystal.*;
import zenith.zov.client.modules.impl.misc.*;
import zenith.zov.client.modules.impl.movement.*;
import zenith.zov.client.modules.impl.player.*;
import zenith.zov.client.modules.impl.render.*;
import zenith.zov.utility.interfaces.IMinecraft;


import java.util.*;

@Getter
public final class ModuleManager implements IMinecraft {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        init();
        EventManager.register(this);
    }

    private void init() {
        registerCrystal();
        registerCombat();
        registerMovement();
        registerRender();
        registerPlayer();
        registerMisc();
    }

    private void registerCrystal() {
        registerModule(AnchorMacro.INSTANCE);
        registerModule(AutoCrystal.INSTANCE);
        registerModule(AutoHitCrystal.INSTANCE);
        registerModule(CrystalOptimizer.INSTANCE);
        registerModule(SafeAnchor.INSTANCE);
        registerModule(new zenith.zov.client.modules.impl.crystal.AirAnchor());
    }

    private void registerCombat() {
        registerModule(AntiBot.INSTANCE);
        registerModule(Aura.INSTANCE);
        registerModule(AutoSwap.INSTANCE);
        registerModule(BackTrack.INSTANCE);
        registerModule(Criticals.INSTANCE);
        registerModule(HitBox.INSTANCE);
        registerModule(TriggerBot.INSTANCE);
        registerModule(AutoTotem.INSTANCE);
        registerModule(new zenith.zov.client.modules.impl.combat.MaceAura());
        registerModule(new zenith.zov.client.modules.impl.combat.StunMace());
    }

    private void registerMovement() {

        registerModule(AutoSprint.INSTANCE);
        registerModule(ElytraBooster.INSTANCE);
        registerModule(ElytraRecast.INSTANCE);
        registerModule(GuiWalk.INSTANCE);
        registerModule(NoSlow.INSTANCE);
        registerModule(AirStuck.INSTANCE);
        registerModule(Scaffold.INSTANCE);
        registerModule(new zenith.zov.client.modules.impl.movement.WindHop());
        registerModule(new zenith.zov.client.modules.impl.movement.AutoPearlCatch());
    }

    private void registerRender() {
        registerModule(Interface.INSTANCE);
        registerModule(AntiInvisible.INSTANCE);
        registerModule(Menu.INSTANCE);
        registerModule(NoRender.INSTANCE);
        registerModule(Predictions.INSTANCE);
        registerModule(BlockESP.INSTANCE);
        registerModule(SwingAnimation.INSTANCE);
        registerModule(Crosshair.INSTANCE);
        registerModule(ViewModel.INSTANCE);
        registerModule(WorldTweaks.INSTANCE);
        registerModule(EntityESP.INSTANCE);
        registerModule(HitBubbles.INSTANCE);
        registerModule(HitParticles.INSTANCE);
        registerModule(Shaders.INSTANCE);
        registerModule(ChunkFinder.INSTANCE);
    }

    private void registerPlayer() {
        registerModule(AutoTool.INSTANCE);
        registerModule(AutoArmor.INSTANCE);
        registerModule(Blink.INSTANCE);
        registerModule(NoDelay.INSTANCE);
        registerModule(FastBreak.INSTANCE);
    }

    private void registerMisc() {
        registerModule(ServerHelper.INSTANCE);
        registerModule(ElytraHelper.INSTANCE);
        registerModule(ItemScroller.INSTANCE);
        registerModule(ClickAction.INSTANCE);
        registerModule(FreeCam.INSTANCE);
        registerModule(CameraTweaks.INSTANCE);
        registerModule(AutoAuth.INSTANCE);
        registerModule(AutoDuels.INSTANCE);
        registerModule(AHHelper.INSTANCE);
        registerModule(AutoSbor.INSTANCE);
        registerModule(NoInteract.INSTANCE);
        registerModule(AutoAccept.INSTANCE);
        registerModule(AutoRespawn.INSTANCE);
        registerModule(NameProtect.INSTANCE);
        registerModule(ClanUpgrade.INSTANCE);
        registerModule(DiscordRPCModule.INSTANCE);
        registerModule(new zenith.zov.client.modules.impl.misc.ScoreboardChanger());
    }

    private void registerModule(Module module) {
        modules.add(module);
    }


    public Module getModule(String name) {
        return modules.stream()
                .filter(module -> module.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public Set<Module> getActiveModules() {
        Set<Module> active = new HashSet<>();
        for (Module module : modules) {
            if (module.isEnabled()) active.add(module);
        }
        return active;
    }


    @EventTarget
    public void onKey(EventKey event) {

        if (mc.currentScreen != null || event.getAction() != GLFW.GLFW_PRESS) return;

        for (Module module : modules) {
            if (module.getKeyCode() == event.getKeyCode()
                    && module.getKeyCode() != GLFW.GLFW_KEY_UNKNOWN) {
                module.toggle();
            }
        }
    }
}
