package zenith.zov.base.events.impl.player;



import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import zenith.zov.base.events.callables.EventCancellable;

@Getter
@Setter
@RequiredArgsConstructor
public class EventSlowWalking extends EventCancellable {



}